#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import sys
arguments = sys.argv[1:]
name = arguments[arguments.index('--crate-name') + 1] if '--crate-name' in arguments else ''
if name in {'penelope_stack_fixture', 'penelope_core', 'sha2', 'digest', 'cpufeatures',
            'block_buffer', 'crypto_common', 'generic_array', 'typenum', 'cfg_if', 'thiserror'}:
    output = Path(os.environ['PENELOPE_STACK_USAGE_DIR'])
    key = name + '-' + hashlib.sha256(json.dumps(arguments).encode()).hexdigest()[:12]
    (output / (key + '.invocation.json')).write_text(json.dumps(arguments, indent=2) + '\n')
    arguments.extend(['-C', 'codegen-units=1', '-C',
                      'llvm-args=-stack-usage-file=' + str(output / (key + '.su'))])
# Replace the wrapper so Cargo's inherited jobserver descriptors remain open.
os.execv(arguments[0], arguments)
