import subprocess,json,hashlib,platform,datetime,tarfile,io,os,shutil,statistics
from pathlib import Path
root=Path.cwd()
out=root/'target/identifier-application-confirmation';out.mkdir(exist_ok=False)
def command(*args,**kwargs): return subprocess.check_output(args,text=True,**kwargs).strip()
meta={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revisions':{label:command('git','rev-parse',ref) for label,ref in [('before','46c0ab1'),('after','719cc07')]},'toolchain':command('rustc','+1.99.0','-Vv'),'kernel':platform.platform(),'cpu':next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'affinity':[0],'process_pairs_per_identifier_size':4,'within_process_rounds':40,'warmups_per_work_size':100,'scope':'one-step in-memory linear saga, short and long identifiers; no I/O or durability','sources':{},'binaries':{},'locks':{},'build_environment':{name:os.environ.get(name) for name in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']}}
for label,revision in meta['revisions'].items():
 snapshot=out/label;snapshot.mkdir()
 archive=subprocess.check_output(['git','archive',revision])
 with tarfile.open(fileobj=io.BytesIO(archive)) as files: files.extractall(snapshot,filter='data')
 source=snapshot/'crates/penelope-executor/benches/application_overhead.rs'
 meta['sources'][label]=hashlib.sha256(source.read_bytes()).hexdigest()
 meta['locks'][label]=hashlib.sha256((snapshot/'Cargo.lock').read_bytes()).hexdigest()
 with (out/f'build-{label}.stderr.log').open('w') as errors:
  built=subprocess.run(['cargo','+1.99.0','bench','-p','penelope-executor','--bench','application_overhead','--no-run','--locked','--message-format=json','--target-dir',str(snapshot/'target')],cwd=snapshot,text=True,stdout=subprocess.PIPE,stderr=errors,check=True)
 (out/f'build-{label}.jsonl').write_text(built.stdout)
 binary=next(row['executable'] for line in built.stdout.splitlines() if (row:=json.loads(line)).get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='application_overhead' and row.get('executable'))
 shutil.copy2(binary,out/f'binary-{label}')
 meta['binaries'][label]=hashlib.sha256((out/f'binary-{label}').read_bytes()).hexdigest()
 shutil.rmtree(snapshot)
 print(f'Built {label}',flush=True)
assert meta['sources']['before']==meta['sources']['after']
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for pair in range(4):
 for mode in (['short','long'] if pair%2==0 else ['long','short']):
  for label in (['before','after'] if pair%2==0 else ['after','before']):
   arguments=['--long-identifiers'] if mode=='long' else []
   result=subprocess.check_output(['taskset','-c','0',str(out/f'binary-{label}'),*arguments],text=True)
   records=[json.loads(line) for line in result.splitlines()]
   assert len(records)==160
   for work in [0,64,4096,65536]:
    group=[r for r in records if r['work']==work]
    assert len(group)==40 and {r['round'] for r in group}==set(range(40))
    assert all(r['direct_ns']>0 and r['penelope_ns']>0 and r['long_identifiers']==(mode=='long') for r in group)
   (out/f'{pair}-{mode}-{label}.jsonl').write_text(result)
  print(f'Completed pair {pair+1}/4 {mode}',flush=True)
meta['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
summary={}
for mode in ['short','long']:
 summary[mode]={}
 for label in ['before','after']:
  rows=[json.loads(line) for path in sorted(out.glob(f'*-{mode}-{label}.jsonl')) for line in path.read_text().splitlines()]
  assert len(rows)==640
  summary[mode][label]={}
  for work in [0,64,4096,65536]:
   g=[r for r in rows if r['work']==work]
   summary[mode][label][str(work)]={'pairs':len(g),'direct_ns':statistics.median(r['direct_ns']/r['iterations'] for r in g),'penelope_ns':statistics.median(r['penelope_ns']/r['iterations'] for r in g),'paired_added_ns':statistics.median((r['penelope_ns']-r['direct_ns'])/r['iterations'] for r in g),'paired_overhead_percent':statistics.median((r['penelope_ns']/r['direct_ns']-1)*100 for r in g),'paired_overhead_range':[min((r['penelope_ns']/r['direct_ns']-1)*100 for r in g),max((r['penelope_ns']/r['direct_ns']-1)*100 for r in g)]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
