import importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location('comparison', Path.cwd()/'scripts/benchmark-decision-comparison.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
# Only extend benchmark registration; build/measurement/validation are unchanged.
module.BENCHMARKS['penelope-domain'] = ['identifier_decode']
module.main()
