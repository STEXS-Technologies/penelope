import json,os,subprocess
from pathlib import Path
root=Path.cwd()
for version in ['1.99.0','1.85.0']:
 log=Path('target')/f'encoding-worker-exit-stress-{version}.log'
 with log.open('w') as output:
  built=subprocess.run(['cargo',f'+{version}','test','-p','penelope-process-runtime','--test','runtime','--all-features','--locked','--no-run','--message-format=json'],text=True,stdout=subprocess.PIPE,stderr=output,check=True)
  binary=next(row['executable'] for line in built.stdout.splitlines() if (row:=json.loads(line)).get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='runtime' and row.get('executable'))
  for repeat in range(50):
   for case in ['launch_contracts::sealed_worker_survives_replacement_of_its_source_file','fragmented_completion_survives_exit_and_truncated_completion_faults']:
    output.write(f'iteration {repeat+1}: {case}\n');output.flush()
    subprocess.run([binary,'--exact',case],stdout=output,stderr=output,check=True)
 print(f'{version}: 50 sealed replacements and 50 fragmented/truncated tests passed',flush=True)
