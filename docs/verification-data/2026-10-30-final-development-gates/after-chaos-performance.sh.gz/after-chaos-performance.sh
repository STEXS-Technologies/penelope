#!/usr/bin/env bash
set -u
while [[ ! -f target/qualification-logs/chaos-recorded.exit ]]; do
  if ! kill -0 3756482 2>/dev/null; then
    printf 'Chaos process stopped without a recorded result; refusing benchmarks\n' >&2
    exit 125
  fi
  sleep 10
done
if [[ "$(cat target/qualification-logs/chaos-recorded.exit)" != 0 ]]; then
  printf 'Chaos campaign failed; refusing qualification benchmarks\n' >&2
  exit 125
fi
set -e
python3 scripts/benchmark-decision-comparison.py target/decision-final-qualified \
  --before edcc5b423e4919f51e4aa2cb820d9de68a684145 --after 50fec4ee9dd58733199d48ba36f7075c056e06ea \
  --cpu 0 --parallel-cpus 0,1,2,3 --runs 20 --perf
python3 scripts/benchmark-decision-comparison.py target/parallel-final-self-control \
  --before edcc5b423e4919f51e4aa2cb820d9de68a684145 --after edcc5b423e4919f51e4aa2cb820d9de68a684145 \
  --cpu 0 --parallel-cpus 0,1,2,3 --benchmark parallel_linear_saga --runs 20 --perf
python3 scripts/summarize-decision-perf.py target/decision-final-qualified > target/decision-final-qualified/parallel-summary.json
python3 scripts/summarize-decision-perf.py target/parallel-final-self-control > target/parallel-final-self-control/summary.json
python3 scripts/benchmark-worker-dispatch.py target/worker-dispatch-sealed-qualified \
  --data-parent target/qualification-temp --cpu 0 --runs 3 --samples 64
printf '0\n' > target/qualification-logs/after-chaos-performance.exit
