#!/usr/bin/env bash
set +e
./scripts/run_pure_chaos_drill.sh
result=$?
printf '%s\n' "$result" > target/qualification-logs/chaos-recorded.exit.tmp
mv target/qualification-logs/chaos-recorded.exit.tmp target/qualification-logs/chaos-recorded.exit
exit "$result"
