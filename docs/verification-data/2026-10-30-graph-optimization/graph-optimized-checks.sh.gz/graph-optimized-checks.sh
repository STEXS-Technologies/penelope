#!/usr/bin/env bash
set -e
run_check() {
  label="$1"
  shift
  printf 'Running %s\n' "$label"
  "$@" > "target/qualification-logs/graph-optimized-$label.log" 2>&1
}
run_check fmt cargo fmt --all -- --check
run_check stable cargo test --workspace --all-targets --all-features --locked --exclude penelope-fuzz
run_check msrv cargo +1.85.0 test --workspace --all-targets --all-features --locked --exclude penelope-fuzz
run_check doctests cargo test --workspace --doc --all-features --locked --exclude penelope-fuzz
run_check clippy cargo clippy --workspace --all-targets --all-features --locked --exclude penelope-fuzz -- -D warnings
run_check rustdoc env RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --all-features --locked --exclude penelope-fuzz
run_check riscv cargo check -p penelope-core --no-default-features --target riscv32imafc-unknown-none-elf --locked
run_check riscv-serde cargo check -p penelope-core --features serde --target riscv32imafc-unknown-none-elf --locked
run_check layers ./scripts/check-layer-boundaries.sh
run_check layers-negative ./scripts/test-layer-boundaries.sh
run_check chaos-runners ./scripts/test-chaos-runners.sh
run_check python python3 -m unittest discover -s scripts/tests
run_check action-pins ./scripts/check-action-pins.sh
run_check audit cargo audit
run_check deny cargo deny check
run_check packages ./scripts/publish-crates.sh
run_check coverage ./scripts/run_coverage_json.sh
run_check coverage-ratchet ./scripts/check_coverage_ratchet.sh
run_check secrets ./scripts/check-no-secrets.sh
run_check whitespace git diff --check


run_check upstream python3 scripts/run-statechronicle-conformance.py /home/ac/projects/statechronicle
printf '0\n' > target/qualification-logs/graph-optimized-checks.exit
