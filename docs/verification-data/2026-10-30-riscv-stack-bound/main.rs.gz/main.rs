#![no_std]
#![no_main]
#[path="fixture.rs"]
mod fixture;
