from pathlib import Path
import subprocess,os,shutil,json,hashlib
source=Path('crates/penelope-ports/src/implementation.rs');candidate=source.read_bytes();base='245da19ea8d8e7f11b50c7ef7f7d9983293830b7'
meta={'baseline':base,'candidate_parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler':subprocess.check_output(['rustc','-Vv'],text=True),'variants':{}}
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':''}
try:
 for variant in ['baseline','candidate']:
  content=subprocess.check_output(['git','show',base+':'+str(source)]) if variant=='baseline' else candidate
  source.write_bytes(content);bins={}
  for package,benches in [('penelope-ports',['atomic_validation','atomic_validation_allocations'])]:
   args=['cargo','build','-p',package,'--release','--message-format=json']
   for bench in benches:args+=['--bench',bench]
   p=subprocess.run(args,env=env,text=True,capture_output=True)
   Path(f'target/atomic-validation-long-build-{variant}-{package}.log').write_text(p.stdout+p.stderr);p.check_returncode()
   for item in map(json.loads,p.stdout.splitlines()):
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item['target']['name'] in benches:
     name=item['target']['name'];binary=Path(item['executable']);destination=Path('target/atomic-validation-long-'+variant+'-'+name)
     shutil.copyfile(binary,destination);destination.chmod(0o755)
     bins[name]={'path':str(destination),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
  assert len(bins)==2
  meta['variants'][variant]={'source_sha256':hashlib.sha256(content).hexdigest(),'binaries':bins}
finally:source.write_bytes(candidate)
meta['fixture_sha256']={path:hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in ['crates/penelope-ports/benches/atomic_validation.rs','crates/penelope-ports/benches/atomic_validation_allocations.rs','crates/penelope-ports/tests/support/atomic_validation_fixture.rs','crates/penelope-sqlite/benches/claim_history.rs']}
Path('target/atomic-validation-long-build.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Built two matching fixtures per variant')
