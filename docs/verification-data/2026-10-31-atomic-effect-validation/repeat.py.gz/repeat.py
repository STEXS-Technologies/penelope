from pathlib import Path
import subprocess,json,hashlib
name='validation_preserves_all_effect_coordinates_and_error_precedence';rows=[]
for compiler,directory in [('stable',Path('target/debug/deps')),('1.85.0',Path('target/worker-audit-msrv/debug/deps'))]:
 candidates=sorted((p for p in directory.glob('atomic_validation_parity-*') if p.is_file() and p.stat().st_mode&0o111),key=lambda p:p.stat().st_mtime,reverse=True)
 binary=next(p for p in candidates if name in subprocess.check_output([str(p),'--list'],text=True));digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 for repeat in range(25):
  p=subprocess.run([str(binary),'--exact',name,'--test-threads=1'],text=True,capture_output=True,timeout=30)
  rows.append(dict(compiler=compiler,repeat=repeat,binary_sha256=digest,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  Path('target/atomic-validation-repeated.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert p.returncode==0 and 'test result: ok. 1 passed; 0 failed;' in p.stdout
print('Passed 50 isolated processes / 500,000 mixed short/long generated cases plus 500 directed coordinate cases')
