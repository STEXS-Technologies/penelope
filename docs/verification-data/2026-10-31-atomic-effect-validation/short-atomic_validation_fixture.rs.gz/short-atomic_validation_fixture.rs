use penelope_domain::*;
use penelope_ports::*;
pub fn commit(actions: usize) -> AtomicProcessCommit {
    let scope = ProcessScope::new(
        "tnt_bench".parse().unwrap(),
        "prc_bench".parse().unwrap(),
        "def_bench".parse().unwrap(),
        "dfv_one".parse().unwrap(),
        ContentDigest([1; 32]),
    );
    let input = ProcessInput::new(
        scope.tenant_id.clone(),
        scope.process_id.clone(),
        "inp_start".parse().unwrap(),
        ProcessInputKind::CanonicalEvent,
        ContentDigest([2; 32]),
    );
    let outcome = ProcessOutcome::new(
        scope.clone(),
        0,
        ProcessOutcomeFact::new(
            "out_start".parse().unwrap(),
            CausationId::Input(input.input_id.clone()),
            OutcomeActor::System,
            LogicalTime(1),
            ProcessOutcomeKind::Started,
            ContentDigest([3; 32]),
        ),
    );
    AtomicProcessCommit {
        expected_sequence: 0,
        input: Some(input),
        canonical_source_event_id: None,
        outcomes: vec![outcome],
        actions: (0..actions)
            .map(|index| {
                ProcessAction::new(
                    scope.clone(),
                    format!("act_{index:03}").parse().unwrap(),
                    format!("stp_{index:03}").parse().unwrap(),
                    0,
                    ProcessActionKind::ExternalEffect,
                    ContentDigest([4; 32]),
                )
            })
            .collect(),
    }
}
