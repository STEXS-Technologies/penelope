//! Stable timer inbox input identity and canonical payload construction.
use penelope_domain::{CanonicalWireBytes, ContentDigest, ProcessInput, ProcessInputKind};
use penelope_ports::{PortError, TimerLease};

/// Stable timer inbox input and durable payload. Delivery attempt, lease token
/// and current time are deliberately excluded so redelivery is immutable.
pub(super) fn timer_input(lease: &TimerLease) -> Result<(ProcessInput, Vec<u8>), PortError> {
    let bytes = lease
        .timer
        .canonical_wire_bytes()
        .map_err(|_invalid| PortError::Invariant)?;
    let digest = {
        let effect_key = lease.timer.action.canonical_effect_key_bytes();
        let action_id = lease.timer.action.action_id.as_str().as_bytes();
        let prefix = b"penelope.timer-input.v1\0";
        let capacity = prefix
            .len()
            .saturating_add(effect_key.len())
            .saturating_add(action_id.len());
        let mut key = Vec::with_capacity(capacity);
        key.extend_from_slice(prefix);
        key.extend_from_slice(&effect_key);
        key.extend_from_slice(action_id);
        ContentDigest::sha256(&key)
    };
    let identity = timer_input_id(digest)?;
    let action = &lease.timer.action;
    let input = ProcessInput::new(
        action.tenant_id.clone(),
        action.process_id.clone(),
        identity
            .try_into()
            .map_err(|_invalid| PortError::Invariant)?,
        ProcessInputKind::TimerFired,
        ContentDigest::sha256(&bytes),
    );
    Ok((input, bytes))
}

/// Format the fixed ASCII identity without a formatting call per digest byte.
// Preserve slice iteration supported by the Rust 1.85 MSRV.
#[allow(clippy::chunks_exact_to_as_chunks)]
pub(super) fn timer_input_id(digest: ContentDigest) -> Result<String, PortError> {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut encoded = [0_u8; 74];
    let (prefix, body) = encoded.split_at_mut(10);
    prefix.copy_from_slice(b"inp_timer_");
    for (byte, pair) in digest.0.into_iter().zip(body.chunks_exact_mut(2)) {
        let high = HEX
            .get(usize::from(byte >> 4))
            .copied()
            .ok_or(PortError::Invariant)?;
        let low = HEX
            .get(usize::from(byte & 15))
            .copied()
            .ok_or(PortError::Invariant)?;
        pair.copy_from_slice(&[high, low]);
    }
    String::from_utf8(encoded.to_vec()).map_err(|_invalid| PortError::Invariant)
}
