//! Exhaustive byte values and patterned digests retain formatter identity bytes.
#[path = "../../penelope-ports/benches/support/outcome_log_allocator.rs"]
mod allocator;
#[path = "../src/timer_input.rs"]
#[allow(dead_code)]
mod implementation;
use penelope_domain::ContentDigest;
use std::fmt::Write as _;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut digests: Vec<_> = (0_u8..=255).map(|byte| ContentDigest([byte; 32])).collect();
    let mut ascending = [0_u8; 32];
    for (slot, value) in ascending.iter_mut().zip(0_u8..32) {
        *slot = value;
    }
    digests.extend([
        ContentDigest(ascending),
        ContentDigest(ascending.map(|value| u8::MAX.saturating_sub(value))),
        ContentDigest(ascending.map(|value| if value & 1 == 0 { 0 } else { 255 })),
    ]);
    let mut cases = 0_u16;
    for digest in digests {
        let mut expected = String::from("inp_timer_");
        for byte in digest.0 {
            write!(expected, "{byte:02x}")?;
        }
        let (encoded, allocations, reallocations, requested_bytes) =
            allocator::measure(|| implementation::timer_input_id(digest));
        if encoded? != expected || (allocations, reallocations, requested_bytes) != (1, 0, 74) {
            return Err(
                format!("timer hex compatibility/allocation failure at case {cases}").into(),
            );
        }
        cases = cases.checked_add(1).ok_or("case overflow")?;
    }
    if cases != 259 {
        return Err("timer hex corpus size changed".into());
    }
    println!(
        "timer_hex_cases=259 all_byte_values=true leading_zeros=true byte_order=true allocations=1 reallocations=0 requested_bytes=74"
    );
    Ok(())
}
