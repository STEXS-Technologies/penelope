//! Replay-only scope comparison; noncanonical scope JSON uses the core decoder.
use penelope_core::task::{runtime::TaskPortError, *};
use serde::Deserialize;
use serde_json::value::RawValue;

// Keep these wire fields/types aligned with TaskRecord. Its exhaustive literal
// below forces field additions to be reviewed, and differential tests cover the
// accepted JSON forms, including duplicate and unknown field rejection.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct BorrowedRecord<'json> {
    version: u16,
    #[serde(borrow)]
    scope: &'json RawValue,
    sequence: TaskSequence,
    generation: TaskGeneration,
    tick: TaskTick,
    event: TaskExecutionEvent,
}

pub(crate) fn encode_scope(scope: TaskScope, buffer: &mut [u8]) -> Result<usize, TaskPortError> {
    let capacity = buffer.len();
    let mut remaining = buffer;
    serde_json::to_writer(&mut remaining, &scope).map_err(|_invalid| TaskPortError::Corrupt)?;
    capacity
        .checked_sub(remaining.len())
        .ok_or(TaskPortError::Corrupt)
}

pub(crate) fn decode(
    bytes: &[u8],
    checksum: &[u8],
    scope: TaskScope,
    sequence: TaskSequence,
    scope_json: &[u8],
) -> Result<TaskRecord, TaskPortError> {
    if Digest::of(bytes).0.as_slice() != checksum {
        return Err(TaskPortError::Corrupt);
    }
    let parsed: BorrowedRecord<'_> =
        serde_json::from_slice(bytes).map_err(|_invalid| TaskPortError::Corrupt)?;
    if parsed.scope.get().as_bytes() != scope_json {
        let stored: TaskScope =
            serde_json::from_str(parsed.scope.get()).map_err(|_invalid| TaskPortError::Corrupt)?;
        if stored != scope {
            return Err(TaskPortError::Corrupt);
        }
    }
    let record = TaskRecord {
        version: parsed.version,
        scope,
        sequence: parsed.sequence,
        generation: parsed.generation,
        tick: parsed.tick,
        event: parsed.event,
    };
    if record.sequence != sequence || record.version != 1 {
        return Err(TaskPortError::Corrupt);
    }
    Ok(record)
}

#[cfg(test)]
#[path = "task_decode_tests.rs"]
mod tests;
