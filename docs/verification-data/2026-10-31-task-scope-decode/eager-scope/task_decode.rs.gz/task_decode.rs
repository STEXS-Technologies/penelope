//! Replay-only canonical scope comparison with the original JSON fallback.
use penelope_core::task::{runtime::TaskPortError, *};
use serde::Deserialize;
use std::io::Write as _;

const HEADER: &[u8] = b"{\"version\":1,\"scope\":";
// These wire fields/types match TaskRecord. The exhaustive construction below
// forces field additions to be reviewed; differential tests check JSON forms.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ScopedRecord {
    version: u16,
    #[serde(rename = "scope")]
    _scope: (),
    sequence: TaskSequence,
    generation: TaskGeneration,
    tick: TaskTick,
    event: TaskExecutionEvent,
}

pub(crate) fn encode_scope(scope: TaskScope, buffer: &mut [u8]) -> Result<usize, TaskPortError> {
    let capacity = buffer.len();
    let mut remaining = buffer;
    serde_json::to_writer(&mut remaining, &scope).map_err(|_invalid| TaskPortError::Corrupt)?;
    capacity
        .checked_sub(remaining.len())
        .ok_or(TaskPortError::Corrupt)
}

pub(crate) fn decode(
    bytes: &[u8],
    checksum: &[u8],
    scope: TaskScope,
    sequence: TaskSequence,
    scope_json: &[u8],
    buffer: &mut [u8],
) -> Result<TaskRecord, TaskPortError> {
    if Digest::of(bytes).0.as_slice() != checksum {
        return Err(TaskPortError::Corrupt);
    }
    // Match the exact serialized scope, not a checksum or a partial identity.
    // Only that known JSON object is replaced. All remaining syntax, fields,
    // duplicates and types still pass through the strict record deserializer.
    let canonical = bytes
        .strip_prefix(HEADER)
        .and_then(|rest| rest.strip_prefix(scope_json))
        .and_then(|tail| {
            HEADER
                .len()
                .checked_add(4)
                .and_then(|length| length.checked_add(tail.len()))
                .filter(|length| *length <= buffer.len())
                .map(|length| (tail, length))
        });
    let record = if let Some((tail, length)) = canonical {
        let mut writer = &mut *buffer;
        writer
            .write_all(HEADER)
            .and_then(|()| writer.write_all(b"null"))
            .and_then(|()| writer.write_all(tail))
            .map_err(|_invalid| TaskPortError::Corrupt)?;
        let shortened = buffer.get(..length).ok_or(TaskPortError::Corrupt)?;
        let parsed: ScopedRecord =
            serde_json::from_slice(shortened).map_err(|_invalid| TaskPortError::Corrupt)?;
        TaskRecord {
            version: parsed.version,
            scope,
            sequence: parsed.sequence,
            generation: parsed.generation,
            tick: parsed.tick,
            event: parsed.event,
        }
    } else {
        // Includes reordered/escaped keys, pretty scopes, sequence-form JSON
        // and records too large for the fixed scratch buffer.
        serde_json::from_slice(bytes).map_err(|_invalid| TaskPortError::Corrupt)?
    };
    if record.scope != scope || record.sequence != sequence || record.version != 1 {
        return Err(TaskPortError::Corrupt);
    }
    Ok(record)
}

#[cfg(test)]
#[path = "task_decode_tests.rs"]
mod tests;
