from pathlib import Path
import subprocess,os,json,platform,time,re,random,statistics
meta=json.loads(Path('target/effect-order-build.json').read_text());cpu=min(os.sched_getaffinity(0))
profiles=[('short-step',False,False),('short-payload',False,True),('long-step',True,False),('long-payload',True,True)]
meta.update(cpu=cpu,kernel=platform.platform(),cpu_model=next(l.strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),pairs=20,profiles=profiles,order='alternating AB/BA; profile order short-step, short-payload, long-step, long-payload; allocations then cpu per profile, then history per variant',background='no own builds, tests or graph jobs during timing')
Path('target/effect-order-metadata.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
base_env={k:v for k,v in os.environ.items() if k not in ['PENELOPE_BENCH_LONG_IDS','PENELOPE_BENCH_VARY_PAYLOAD']}
base_env['TMPDIR']=str(Path('target/qualification-temp').resolve())
for pair in range(20):
 for variant in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  requests=[]
  for profile,long,payload in profiles:
   env=base_env.copy()
   if long:env['PENELOPE_BENCH_LONG_IDS']='1'
   if payload:env['PENELOPE_BENCH_VARY_PAYLOAD']='1'
   requests += [(profile,'allocations','atomic_validation_allocations',env),(profile,'cpu','atomic_validation',env)]
  requests += [('short-step','history','claim_history',base_env)]
  for profile,kind,name,env in requests:
   binary=meta['variants'][variant]['binaries'][name];started=time.time_ns()
   p=subprocess.run(['taskset','-c',str(cpu),binary['path']],env=env,text=True,capture_output=True,timeout=60,check=True)
   rows.append(dict(pair=pair,variant=variant,profile=profile,kind=kind,cpu=cpu,binary_sha256=binary['sha256'],started_unix_ns=started,stdout=p.stdout,stderr=p.stderr))
   Path('target/effect-order-processes.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('completed pair',pair,flush=True)
values={}
for row in rows:
 if row['kind']=='cpu':
  for line in row['stdout'].splitlines():
   m=re.fullmatch(r'actions=(0|1|16|128) iterations=(\d+) elapsed_ns=(\d+)',line);assert m
   values[f'cpu/{row["profile"]}/{m[1]}',row['pair'],row['variant']]=int(m[3])/int(m[2])
 elif row['kind']=='allocations':
  for line in row['stdout'].splitlines():
   m=re.fullmatch(r'actions=(0|1|16|128) allocations=(\d+) reallocations=(\d+) deallocations=(\d+) requested_bytes=(\d+)',line);assert m
   count=8 if row['profile'].startswith('long') else 0
   assert list(map(int,m.groups()[1:]))==[count,0,count,count*128]
 else:
  for d in map(json.loads,row['stdout'].splitlines()):
   assert d['schema_version']==5 and d['retained_rows']==1024 and d['next_token']==(1 if d['timers'] else 1025)
   for metric,count in [('open',1),('commit',8),('idle',1000)]+([('schedule',1024)] if d['timers'] else [('seed_claim',8),('ack',1024)]):
    values[f'history/{str(d["timers"]).lower()}/{metric}',row['pair'],row['variant']]=d[metric+'_ns']/count
summary={}
for metric in sorted({key[0] for key in values}):
 ratios=[values[metric,i,'candidate']/values[metric,i,'baseline'] for i in range(20)];rng=random.Random(42)
 boot=sorted(statistics.mean(rng.choices(ratios,k=20)) for _ in range(10000))
 summary[metric]={'mean_paired_change_pct':100*(statistics.mean(ratios)-1),'bootstrap95_pct':[100*(boot[i]-1) for i in [250,9749]],'mean_ns_per_call':{v:statistics.mean(values[metric,i,v] for i in range(20)) for v in ['baseline','candidate']}}
 print(metric,summary[metric],flush=True)
assert len(summary)==25
Path('target/effect-order-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
