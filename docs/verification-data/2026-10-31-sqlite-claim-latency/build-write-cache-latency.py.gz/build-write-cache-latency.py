from pathlib import Path
import subprocess,os,shutil,json,hashlib
source=Path('crates/penelope-sqlite/src/schema.rs');candidate=source.read_bytes()
baseline='5966fe2b32b3b5ac53c3ed049294e20e5ab25618'
metadata={'baseline_source':baseline,'candidate_source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler':subprocess.check_output(['rustc','-Vv'],text=True),'variants':{}}
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':''}
try:
 for variant in ['baseline','candidate']:
  content=subprocess.check_output(['git','show',baseline+':'+str(source)]) if variant=='baseline' else candidate
  source.write_bytes(content)
  p=subprocess.run(['cargo','build','-p','penelope-sqlite','--bench','claim_history','--bench','lease_batch','--release','--message-format=json'],env=env,text=True,capture_output=True)
  Path('target/write-cache-latency-build-'+variant+'.log').write_text(p.stdout+p.stderr);p.check_returncode()
  binaries={}
  for item in map(json.loads,p.stdout.splitlines()):
   if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('target',{}).get('name') in ['claim_history','lease_batch']:
    kind='history' if item['target']['name']=='claim_history' else 'batch'
    path=Path(item['executable']);destination=Path('target/write-cache-latency-'+variant+'-'+kind)
    shutil.copyfile(path,destination);destination.chmod(0o755)
    binaries[kind]={'path':str(destination),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  assert set(binaries)=={'history','batch'}
  metadata['variants'][variant]={'schema_sha256':hashlib.sha256(content).hexdigest(),'binaries':binaries}
finally:
 source.write_bytes(candidate)
metadata['benchmark_sha256']={name:hashlib.sha256(Path('crates/penelope-sqlite/benches/'+name+'.rs').read_bytes()).hexdigest() for name in ['claim_history','lease_batch']}
Path('target/write-cache-latency-build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Built baseline and candidate history/batch benchmarks')
