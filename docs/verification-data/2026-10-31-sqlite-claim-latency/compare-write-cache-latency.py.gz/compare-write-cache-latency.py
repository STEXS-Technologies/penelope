from pathlib import Path
import subprocess,os,json,hashlib,time,platform,re,random,statistics
cpu=min(os.sched_getaffinity(0));rows=[]
metadata=json.loads(Path('target/write-cache-latency-build.json').read_text())
metadata.update(cpu=cpu,kernel=platform.platform(),cpu_model=next(l.strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),pairs=20,order='alternating AB/BA; batch then history per variant',own_background_jobs='no builds, tests, or graph jobs during campaign')
Path('target/write-cache-latency-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
env={**os.environ,'TMPDIR':str(Path('target/qualification-temp').resolve())}
for pair in range(20):
 for variant in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  for kind in ['batch','history']:
   binary=metadata['variants'][variant]['binaries'][kind]
   started=time.time_ns()
   p=subprocess.run(['taskset','-c',str(cpu),binary['path']],env=env,text=True,capture_output=True,check=True,timeout=60)
   rows.append(dict(pair=pair,variant=variant,kind=kind,cpu=cpu,started_unix_ns=started,binary_sha256=binary['sha256'],stdout=p.stdout,stderr=p.stderr))
   Path('target/write-cache-latency-processes.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('completed pair',pair,flush=True)
values={}
for row in rows:
 if row['kind']=='batch':
  for line in row['stdout'].splitlines():
   match=re.fullmatch(r'timers=(false|true) batch=(1|16) iterations=400 elapsed_ns=(\d+)',line);assert match,line
   key=f'batch/{match[1]}/{match[2]}'
   values[key,row['pair'],row['variant']]=int(match[3])/400
 else:
  for data in map(json.loads,row['stdout'].splitlines()):
   assert data['schema_version']==5
   assert data['retained_rows']==1024 and data['idle_calls']==1000 and data['warmup_calls']==100
   assert data['next_token']==(1 if data['timers'] else 1025)
   timers=str(data['timers']).lower()
   for metric,count in [('open',1),('commit',8),('idle',1000)]+([('schedule',1024)] if data['timers'] else [('seed_claim',8),('ack',1024)]):
    values[f'history/{timers}/{metric}',row['pair'],row['variant']]=data[metric+'_ns']/count
summary={}
for metric in sorted({key[0] for key in values}):
 ratios=[values[metric,i,'candidate']/values[metric,i,'baseline'] for i in range(20)]
 rng=random.Random(42)
 boot=sorted(statistics.mean(rng.choices(ratios,k=20)) for _ in range(10000))
 summary[metric]={'mean_paired_change_pct':100*(statistics.mean(ratios)-1),'bootstrap95_pct':[100*(boot[i]-1) for i in [250,9749]],'mean_ns_per_call':{v:statistics.mean(values[metric,i,v] for i in range(20)) for v in ['baseline','candidate']}}
 print(metric,summary[metric],flush=True)
assert len(summary)==13
Path('target/write-cache-latency-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
