from pathlib import Path
import subprocess,os,json,hashlib
names=['worker::panic_tests::operation_panic_payload_destructor_cannot_strand_accepted_work','worker::panic_tests::notification_panic_payload_destructor_cannot_strand_accepted_work']
rows=[]
env={**os.environ,'TMPDIR':str(Path('target/qualification-temp').resolve())}
for compiler,directory in [('stable',Path('target/debug/deps')),('1.85.0',Path('target/worker-audit-msrv/debug/deps'))]:
 candidates=sorted((p for p in directory.glob('penelope_sqlite-*') if p.is_file() and p.stat().st_mode&0o111),key=lambda p:p.stat().st_mtime,reverse=True)
 binary=next(p for p in candidates if all(name in subprocess.check_output([str(p),'--list'],text=True) for name in names))
 digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 for repeat in range(25):
  for name in names:
   result=subprocess.run([str(binary),'--exact',name,'--test-threads=1'],env=env,text=True,capture_output=True,timeout=30)
   rows.append(dict(compiler=compiler,repeat=repeat,case=name,binary=str(binary),binary_sha256=digest,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
   Path('target/worker-payload-repeated.json').write_text(json.dumps(rows,indent=2)+'\n')
   assert result.returncode==0 and 'test result: ok. 1 passed; 0 failed;' in result.stdout
print('Passed 100 isolated processes / 400 operation-or-wake × cancellation × admission scenarios')
