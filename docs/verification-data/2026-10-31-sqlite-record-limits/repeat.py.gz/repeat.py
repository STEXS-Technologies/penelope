from pathlib import Path
import subprocess,os,json,hashlib
name='record_limits::raising_record_limit_preserves_commit_retry_replay_and_reopen'
rows=[]; env={**os.environ,'TMPDIR':str(Path('target/qualification-temp').resolve())}
for compiler,directory in [('stable',Path('target/debug/deps')),('1.85.0',Path('target/worker-audit-msrv/debug/deps'))]:
 candidates=sorted((p for p in directory.glob('process-*') if p.is_file() and p.stat().st_mode&0o111),key=lambda p:p.stat().st_mtime,reverse=True)
 binary=next(p for p in candidates if name in subprocess.check_output([str(p),'--list'],text=True))
 digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 for repeat in range(25):
  result=subprocess.run([str(binary),'--exact',name,'--nocapture','--test-threads=1'],env=env,text=True,capture_output=True,timeout=30)
  rows.append(dict(compiler=compiler,repeat=repeat,binary=str(binary),binary_sha256=digest,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
  Path('target/record-limits-repeated.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert result.returncode==0 and 'test result: ok. 1 passed; 0 failed;' in result.stdout
print('Passed 50 isolated processes / 250 limit configurations with commit, retry, replay, acknowledge and reopen')
