#!/usr/bin/env bash
set -eu
while [[ ! -f target/qualification-logs/versioned-checks.exit ]]; do
  if ! kill -0 1840983 2>/dev/null; then
    printf 'Versioned checks stopped without success; refusing measurements\n' >&2
    exit 125
  fi
  sleep 5
done
[[ "$(cat target/qualification-logs/versioned-checks.exit)" == 0 ]]
python3 scripts/benchmark-decision-comparison.py target/decision-0.3.0-qualified --before edcc5b423e4919f51e4aa2cb820d9de68a684145 --after 16e3e1e3e3c7038aea4f3708cb9cc519fedaf664 --cpu 0 --parallel-cpus 0,1,2,3 --runs 20 --perf
python3 scripts/summarize-decision-perf.py target/decision-0.3.0-qualified --benchmark graph_saga > target/decision-0.3.0-qualified/graph-summary.json
python3 scripts/summarize-decision-perf.py target/decision-0.3.0-qualified > target/decision-0.3.0-qualified/parallel-summary.json
python3 scripts/benchmark-worker-dispatch.py target/worker-dispatch-0.3.0-qualified --data-parent target/qualification-temp --cpu 0 --runs 3 --samples 64
python3 scripts/bound-portable-task-stack.py target/riscv-stack-0.3.0-qualified
printf '0\n' > target/qualification-logs/versioned-measurements.exit
