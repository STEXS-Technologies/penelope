### Added

- Typed saga/task bindings, verified application output and independent effect
  evidence, committed dispatch acceptance, and stable task-result inbox relay.
  `TaskEffectResult` extends input categories; existing serialized categories and
  saga event/action formats retain their existing encoding.

- Optional Linux static single-process worker runtime with sealed executable
  identity, bounded IPC, seccomp restrictions, kernel CPU limits and durable
  generation fencing for the documented single-host deployment profile.

- Shared allocation-free task supervision through `TaskControl` and explicit
  caller-owned `TaskWorkspace`, with the existing hosted supervisor preserved.
- Optional SQLite task history/blob storage, persistent generation reservations
  and two-phase fencing, terminal-history retirement and maintenance operations.
- Optional SQLite atomic process commits, deduplicated inbox/source events,
  durable outbox and timer claims, lease renewal and fenced acknowledgements.
- Bounded worker isolation for async SQLite process ports, with explicit queue
  exhaustion and ambiguous cancellation semantics.
- Adapter tests for transaction-boundary process death, competing connections,
  lost acknowledgements, corruption, migration and stale leases.

### Compatibility

- The 0.3.0 release adds `ProcessInputKind::TaskEffectResult` and five
  `ProcessAuthorizationOperation` variants (`Dispatch`, `DriveTask`,
  `ReconcileEffect`, `DeliverTimer`, `RelayTaskResult`). Consumers with exhaustive
  matches must handle these variants when upgrading. Existing variant names,
  numeric discriminants and saga/task v1 record encodings are preserved.
- `penelope_executor::task::SupervisorError` remains available, including variant
  imports, exhaustive matches and error conversions, through a re-export of the
  shared core controller error.

### Changed

- Hosted task advance initializes its two dispatch buffers only for an actual
  start/restart via the shared controller's lazy `TaskDispatchWorkspace` provider.
- Hosted task advance supplies two dispatch buffers and polling supplies one
  proposal buffer to the same core controller. Operation-specific portable calls
  avoid borrowing unused buffers while preserving full-workspace admission.
- Portable workspace validation requires poll capacity for both checkpoint and
  completion proposals, including when checkpoint limits exceed output limits.

- Infrastructure dependency checks allow `rusqlite` only in the dedicated
  SQLite adapter; core, ports, executor and the facade remain independent.

### Qualification

- Full three-iteration public-boundary campaign: 48 runs of 100,000 inputs,
  plus real adapter crash/concurrency suites and stable/MSRV verification.
- Recorded SQLite, worker, hosted-memory and RISC-V stack evidence. The final
  performance review explicitly accepts a measured graph-saga median regression
  of 2.95–3.10% (28.53–29.90 ns per benchmark operation) across the two reference
  campaigns; timing parity
  and universal latency bounds are not claimed. See
  [the qualification report](docs/verification-2026-10-30.md).

### Security

- Linux worker startup executes only the sealed CLOEXEC image descriptor through
  `execveat`. Ordinary `execve`, other executable descriptors and descriptor
  rebinding remain forbidden after startup. Real worker probes catch attempts
  to re-execute or load another executable under the retained seccomp filter.
