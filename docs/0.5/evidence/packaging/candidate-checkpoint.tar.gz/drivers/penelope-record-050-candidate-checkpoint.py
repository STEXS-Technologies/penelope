import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');folder=root/'docs/0.5/evidence/packaging';source='9a5a1dbef9cbb1cf5453f403264ffcb82e303cbf';members={}
def add(name,path):
 members[name]=Path(path).read_bytes()
for p in sorted(Path('/tmp/penelope-050-candidate-checks').iterdir()):
 if p.is_file():add('initial/'+p.name,p)
for name in ['lock-identities.json','doc-links.json','package-identities.json','package-checks.log','conformance.log','library-tests.log','library-msrv-tests.log','workspace-tests.log','workspace-msrv-tests.log']:
 prefix='/tmp/penelope-050-candidate-'
 actual='/tmp/penelope-050-candidate-lock-identities.json' if name=='lock-identities.json' else prefix+name
 add('checkpoint/'+name,actual)
for path in ['/tmp/penelope-check-050-candidate.py','/tmp/penelope-record-050-candidate-checkpoint.py']:
 add('drivers/'+Path(path).name,path)
for p in sorted(Path('/home/ac/projects/penelope/target/candidate-package-checks/package').glob('*.crate')):add('archives/'+p.name,p)
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source],cwd=root,text=True).splitlines()
for name in paths:
 if name=='Cargo.toml' or name=='Cargo.lock' or (name.endswith(('Cargo.toml','Cargo.lock')) and name.startswith(('crates/','ci/','fuzz/','scripts/conformance/'))) or name in ['scripts/publish-crates.sh','scripts/check-package-includes.py','scripts/run-statechronicle-conformance.py','docs/0.5/README.md','docs/RELEASE.md','CHANGELOG.md']:
  members['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=root)
for p in sorted(Path('/tmp/penelope-050-public-gates').iterdir()):
 if p.is_file():add('public/'+p.name,p)
add('drivers/penelope-050-check-public-gates.py','/tmp/penelope-050-check-public-gates.py')
for prefix,location in [('extracted','/tmp/penelope-050-packaged-workspace'),('coverage','/tmp/penelope-050-coverage')]:
 for p in sorted(Path(location).iterdir()):
  if p.is_file():add(prefix+'/'+p.name,p)
for name in ['penelope-050-test-packaged-workspace.py','penelope-050-run-coverage.py']:
 add('drivers/'+name,'/tmp/'+name)
add('ci/be774e6.json','/tmp/penelope-050-ci-be774e6.json')
archive=folder/'candidate-checkpoint.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw))
hashes={name:hashlib.sha256(raw).hexdigest() for name,raw in members.items()}
with tarfile.open(archive) as tar:
 assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar}==hashes
checks=json.loads(members['initial/checks.json']);checks.extend([
 {'label':'pinned-conformance','args':['python3','scripts/run-statechronicle-conformance.py','/home/ac/projects/.statechronicle-penelope-050'],'exit_code':0,'selected_tests':7,'pinned_upstream':'ae3d94bc22c7835eaa3fdcd766e3c117929c12bb'},
 {'label':'package-verification','args':['./scripts/publish-crates.sh'],'exit_code':0,'mode':'default dry-run, no publication','archives':10}])
for version,name in [('1.100.0','library-tests.log'),('1.89.0','library-msrv-tests.log')]:
 checks.append({'label':'library-tests-'+version,'args':['cargo','+'+version,'test','--workspace','--all-targets','--all-features','--locked','--exclude','penelope-fuzz'],'exit_code':0,'reported_harness_summaries':sum(l.startswith('test result:') for l in members['checkpoint/'+name].decode().splitlines()),'scope':'Library tests and debug benchmark smoke runs; not release performance or doctests.'})
checks.extend(json.loads(members['public/checks.json']))
checks.extend(json.loads(members['extracted/checks.json']))
checks.extend(json.loads(members['coverage/checks.json']))
coverage=json.loads(members['coverage/coverage.json'])
coverage_files=[f for d in coverage['data'] for f in d['files']]
assert all(f['filename'].startswith(str(root)+'/') for f in coverage_files)
ci=json.loads(members['ci/be774e6.json'])
assert ci['headSha']=='be774e678e7d982b337bf3925b4f88632c90103b' and ci['status']=='completed' and ci['conclusion']=='success'
assert len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
manifest={'source_commit':source,'scope':'Versioned 0.5 development checkpoint: metadata, compatibility, migration, pinned conformance, source and extracted-archive library tests, public/portable gates and fresh full workspace coverage. Not completed release qualification.','checks':checks,'external_lock_identities':'All external name/version/source/checksum identities unchanged in the six active lockfiles; frozen baseline locks and corpora untouched.','retained_unsuccessful_attempts':[{'label':'initial-conformance','exit_code':2,'reason':'The supplied sibling checkout had advanced past the explicitly pinned upstream; corrected using an isolated pinned worktree.'},{'label':'workspace-tests-without-fuzz-exclusion','versions':['1.100.0','1.89.0'],'exit_code':143,'reason':'Missing --exclude penelope-fuzz launched an unbounded target; owned processes deliberately stopped. Correct documented library commands rerun. Separate chaos rehearsal unaffected.'}],'public_gate_checkout':'feabc53: only docs/evidence differ from the source commit; Rust source, manifests, locks, CI and scripts match', 'coverage':{'checkout_commits':'feabc53 through be774e6; only docs/evidence differ from 9a5a1db in source/manifests/locks/CI/scripts','totals':[d['totals']['lines'] for d in coverage['data']],'reported_source_files':len(coverage_files),'all_files_in_candidate_checkout':True,'ratchet':members['coverage/ratchet.stdout'].decode(),'full_json':'coverage/coverage.json'},'extracted_workspace':{'code_commit':source,'versions':'All ten library packages 0.5.0','lock':'Same normalized lock used with --locked on both compilers; no new external identity, version or checksum. Only arbitrary, jobserver and libfuzzer-sys removed.','excluded_tests':'No library test is skipped. Checkout-only architecture tests run separately in the compatibility harness.','scope':'All-target/all-feature library tests and debug benchmark smokes on both compilers, not release performance or doctests.'},'ci':{'source_commit':ci['headSha'],'url':ci['url'],'status':ci['status'],'conclusion':ci['conclusion'],'jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']]},'open':'Full immutable-source chaos campaign, versioned comparative performance dispositions and final release audit remain open. No tag or publication.','archive':{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_count':len(members),'members_sha256':hashes}}
(folder/'candidate-checkpoint.json').write_text(json.dumps(manifest,indent=2)+'\n');print('verified',len(members),'archive members')
