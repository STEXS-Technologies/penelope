# Changelog

All notable changes to Penelope are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and
this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

The 0.5 API and candidate package versions are prepared on the development
branch. Final [release qualification](docs/0.5/README.md) remains open; no 0.5
release is published.

### Added

- Portable typed application machines with guarded transitions, explicit
  rejection, bounded staged intents and consuming prepared publication. Optional
  single-path hierarchy adds parent fallback and ordered exit/action/entry hooks.
- Independent `penelope.machine.v1` metadata and canonical payload preparation,
  plus authorized SQLite admission, atomic CAS, duplicate/conflict checks,
  snapshots, recovery and leased outbox delivery with persisted uncertainty.
- Source-bound native task and linear/graph saga admission. Read-only receipt
  verification preserves original execution authority; uncertain delivery never
  implies permission to restart work. The canonical tutorial covers recovery,
  verified real-worker results and progression back into a machine and saga.
- Shared prepared-decision inspection for machine, saga and task lifecycles,
  canonical facade namespaces, and a machine adapter over the existing timeline
  replay, correction and effect-finality engine. Existing imports and saga/task/
  timeline wire formats remain supported.

### Changed

- Raise the workspace minimum Rust version to 1.89 for patched SQLite; pin the
  development toolchain and verification scripts to Rust 1.100.0.
- Advance SQLite to schema 9, retaining legacy task/process data and machine
  acceptance evidence. Unknown original receivers fail closed. Older adapters
  refuse the upgraded schema; rollback requires a separate consistent backup.
- Share bounded intent admission, wire cursors, SQLite worker delivery and native
  receipt verification while retaining each engine's authority and error rules.
  Remove unused internal dependencies and workspace metadata.
- Add a lazy validated timeline input-position hint after eviction, preserving
  integrity checks, ancestry/override precedence and the original scan fallback.
- Shorten setup documentation and provide one canonical machine/task/saga tutorial.
  Make packaged test and benchmark includes self-contained without fixture copies.

### Security

- Upgrade bundled SQLite through `rusqlite` 0.41.1 / `libsqlite3-sys` 0.39.1
  to address RUSTSEC-2026-0459; upgrade `rustix` to 1.1.6 for
  RUSTSEC-2026-0486. Conformance uses the same patched dependencies.

## [0.4.0] - 2026-11-02

Penelope adds rewindable computation alongside the saga orchestration and
recoverable task execution available in 0.3.0. Applications can reconcile local
predictions with admitted state or input corrections, replay on isolated scratch,
and publish validated results. Existing saga/task v1 formats and recovery
semantics remain unchanged.

### Added

- Optional `penelope-timeline` crate for bounded replay, candidate validation
  and staged effect intents, with a default `no_std` profile and fixed buffers
  that require no heap allocation.
- Independent timeline scopes, logical steps, branches and revisions, correction
  planning, and the versioned `penelope.timeline.v1` binary metadata codec.
- Fixed-capacity immutable input and full-snapshot history with byte limits,
  branch ancestry, pinned replay, explicit eviction and branch materialization.
- Atomic state/head/intent publication through an exclusive owner or optional
  hosted shared lock, with stale-candidate fencing and non-reused branch IDs.
- Separately authorized effect finality and idempotent durable-admission
  contracts for handing off finalized intents.
- Owned-state input application, scoped correction cleanup, closure validators
  and captured input/snapshot adapters, with a runnable quickstart.
- Integer simulation and optimistic invoice examples, including SQLite handoff
  across lost admission/delivery acknowledgements, plus client prediction tests
  covering delayed snapshots, unacknowledged inputs and continued prediction.

### Security

- Timeline scope, revision, authority ordering and finalized-prefix checks
  refuse stale or incompatible corrections before publication.
- Correction authentication, snapshot completeness, deterministic computation
  and effect authorization remain explicit application responsibilities.
  Replay does not reverse already-issued external effects.

### Changed

- The facade exposes rewindable computation as `penelope::timeline` through the
  optional `timeline` feature; existing users do not acquire that dependency
  by default.
- Release verification covers all ten library packages, with timeline portable
  checks, examples, property/fuzz campaigns and scoped performance measurements.

## [0.3.0] - 2026-10-31

### Added

- Optional `penelope-sqlite` adapter for durable task histories and blobs,
  generation authority, atomic process commits, inbox deduplication, and leased
  outbox/timer delivery. Includes scoped quotas and pending-input discovery.
- Optional `penelope-process-runtime` adapter for protected Linux workers, with
  sealed executable identity, bounded IPC, resource restrictions and durable
  generation fencing for the documented single-host deployment profile.
- Typed saga/task composition and bounded services for committed dispatch,
  verified results, independent effect reconciliation, task-result relay and
  durable timer delivery.
- Shared allocation-free task supervision through `TaskControl` and caller-owned
  `TaskWorkspace`, alongside the existing hosted supervisor.
- Integration examples and deployment documentation for the new adapters and
  services, with crash, concurrency, corruption and recovery verification.

### Changed

- Reduce allocations and repeated work in identifier encoding/decoding,
  linear/graph definition validation, saga completion and hosted task dispatch.
  Performance remains workload-dependent; scoped measurements and regressions
  are documented in the performance reports.
- Add `ProcessInputKind::TaskEffectResult` and five
  `ProcessAuthorizationOperation` variants: `Dispatch`, `DriveTask`,
  `ReconcileEffect`, `DeliverTimer` and `RelayTaskResult`. Downstream exhaustive
  matches must handle the new variants. Existing saga/task v1 encodings remain
  compatible.
- Re-export the shared controller error as the existing hosted
  `penelope_executor::task::SupervisorError`.

## [0.2.0] - 2026-10-11

Penelope now provides recoverable task execution alongside deterministic saga
orchestration. Applications can declare recovery permissions, persist valid
checkpoints and reconcile ambiguous effects through runtime-independent APIs.
The existing saga engine remains independently useful, with its v1 history
representations and execution guarantees preserved.

### Added

- Recoverable task definitions with explicit restart-from-input,
  restart-from-checkpoint, reconcile-before-restart and never-restart policies.
- Checkpoint-aware execution with immutable input and result records, committed
  recovery boundaries and application-authorized checkpoint migration.
- Task supervision with generation fencing, typed fault observations, bounded
  recovery attempts, deadlines, restart delays and execution/resource budgets.
- Independently versioned task history and deterministic reconstruction without
  rerunning computation or repeating external effects during replay.
- Backend-neutral synchronous journal and runtime contracts, plus a bridge to
  existing saga effect execution.
- Optional StateChronicle verification evidence bound to the exact task scope,
  generation and checkpoint identity.
- An allocation-free `no_std` task core, optional portable Serde support,
  distinct identity/time newtypes and caller-owned bounded execution buffers.
- Recoverable computation examples and deployment contracts covering journal
  durability, runtime enforcement, checkpoint schemas and external-effect evidence.
- Recovery validation through process termination against filesystem and
  transactional SQLite test journals, concurrent supervisor stress, property
  testing and sanitizer-instrumented fuzz targets.

### Security

- Task scope, definition, generation, sequence and monotonic time are checked
  before execution history advances; stale or cross-scope results fail closed.
- Input commits precede execution, and checkpoints/results commit before
  acknowledgement. Ambiguous persistence outcomes require reconstruction.
- Live generations retain capacity for a fault or completion; rejected resource
  proposals fence execution before recovery proceeds.
- Corrupt checkpoints, incompatible schemas and unknown effects cannot become
  unsupported claims of completion or authorize blind retries.
- Runtime isolation, CPU enforcement, storage authenticity and the correctness
  of computation and physical side effects remain explicit application contracts.

### Changed

- The facade exposes both saga orchestration and recoverable task execution
  while preserving existing linear/graph decisions, retries, compensation and
  reconciliation semantics.
- Task definition fingerprints bind recovery permissions and resource budgets
  to execution scope, and strict task wire decoding rejects malformed records.
- The workspace supports Rust 1.85 and uses Rust 1.99 for development, with
  hosted adapters separated from the portable task core.
- Release verification checks all seven library packages; tag releases use the
  matching dated changelog entry as their GitHub release notes.

## [0.1.0] - 2026-09-15

Initial release of Penelope, a foundation for reliable sagas and long-running
asynchronous workflows. It provides deterministic decisions and recovery
contracts while leaving storage, messaging, scheduling, and service adapters
to the consuming application.

### Added

- Deterministic linear and graph saga orchestration with ordered replay after
  restart.
- Append-only outcome-log contracts that reject gaps, duplicates, reordering,
  and cross-process records.
- Reliable retry handling with bounded attempts, backoff, jitter, deadlines,
  and durable timer decisions.
- LIFO compensation, cancellation, unknown-outcome escalation, and manual
  review flows for exceptional or ambiguous work.
- Reconciliation contracts that distinguish committed, not-committed, and
  unknown external outcomes without blind retries.
- Typed ports for persistence, inbox/outbox delivery, leases, timers, external
  effects, authorization, quotas, diagnostics, and review queues.
- StateChronicle integration boundary for idempotent commands and verified
  committed-event correlation.
- Developer-facing constructors, facade exports, examples, documentation,
  and release verification for building reliable async systems.

### Security

- Tenant, process, definition, action, effect, and resource scopes are checked
  before decisions advance.
- Stale, duplicate, forged, or cross-scope results fail closed.
- Ambiguous external effects escalate for reconciliation or operator review
  instead of being treated as failures.
