import pathlib,json,hashlib,tarfile,io,subprocess,re,tomllib
P=pathlib.Path;r=P('/home/ac/projects/.penelope-050-candidate');source='cefa55faffe837fe30625205dd8236e9c242fb36';folder=r/'docs/0.5/evidence/packaging';members={}
def add(n,p):members[n]=P(p).read_bytes()
for prefix,where in [('candidate','/tmp/penelope-050-qpsg-candidate-checks'),('public','/tmp/penelope-050-qpsg-public-gates'),('extracted','/tmp/penelope-050-qpsg-packaged-workspace'),('coverage','/tmp/penelope-050-qpsg-coverage')]:
 for p in P(where).iterdir():
  if p.is_file():add(prefix+'/'+p.name,p)
for n,p in [('library-stable.log','/tmp/penelope-050-qpsg-adoption-stable.log'),('library-msrv.log','/tmp/penelope-050-qpsg-adoption-msrv.log'),('package-checks.log','/tmp/penelope-050-qpsg-candidate-package-checks.log'),('package-identities.json','/tmp/penelope-050-qpsg-package-identities.json'),('invariant-revalidation.json','/tmp/penelope-050-qpsg-invariant-revalidation.json'),('query-order-review.json','/tmp/penelope-050-qpsg-query-order-review.json'),('graph-update.log','/tmp/penelope-050-qpsg-adoption-graph.log'),('ci.json','/tmp/penelope-050-qpsg-ci-cefa55f.json')]:add('checkpoint/'+n,p)
for name in ['penelope-check-050-qpsg-candidate.py','penelope-050-qpsg-check-public-gates.py','penelope-050-qpsg-test-packaged-workspace.py','penelope-050-qpsg-run-coverage.py','penelope-record-050-qpsg-checkpoint.py']:add('drivers/'+name,'/tmp/'+name)
checks=[]
for prefix in ['candidate','public','extracted','coverage']:
 c=json.loads(members[prefix+'/checks.json']);assert all(x['exit_code']==0 for x in c);checks.extend({'group':prefix,**x} for x in c)
assert len(json.loads(members['extracted/checks.json']))==4
ci=json.loads(members['checkpoint/ci.json']);assert ci['headSha']==source and ci['status']=='completed' and ci['conclusion']=='success';assert len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
counts={}
for label,key in [('library-stable','checkpoint/library-stable.log'),('library-msrv','checkpoint/library-msrv.log'),('extracted-stable','extracted/tests-1.100.0.stdout'),('extracted-msrv','extracted/tests-1.89.0.stdout')]:
 a=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',members[key].decode());assert len(a)==95 and all(int(x[1])==0 and int(x[2])==0 for x in a);assert sum(int(x[0]) for x in a)==694;counts[label]={'successful_harness_summaries':len(a),'reported_passes':sum(int(x[0]) for x in a),'ignored':0}
archives=sorted(P('/home/ac/projects/penelope/target/qpsg-candidate-package-checks/package').glob('*.crate'));assert len(archives)==10
for p in archives:add('archives/'+p.name,p)
for p in json.loads(members['checkpoint/package-identities.json']):assert p['vcs']['git']['sha1']==source and not p['vcs']['git'].get('dirty',False)
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source],cwd=r,text=True).splitlines();source_ids={}
for p in paths:
 if p.startswith(('crates/','ci/','fuzz/','scripts/','.github/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
  raw=subprocess.check_output(['git','show',source+':'+p],cwd=r);source_ids[p]=hashlib.sha256(raw).hexdigest()
  if p.endswith(('Cargo.toml','Cargo.lock')) or p in ['crates/penelope-sqlite/src/schema.rs','scripts/publish-crates.sh','scripts/check-package-includes.py']:members['source/'+p]=raw
members['source/runtime-build-identities.json']=(json.dumps(source_ids,indent=2)+'\n').encode()
subprocess.run(['git','diff',source,'--exit-code','--','Cargo.toml','Cargo.lock','crates','ci','fuzz','scripts','.github','rust-toolchain.toml'],cwd=r,check=True,capture_output=True)
cov=json.loads(members['coverage/coverage.json']);files=[f['filename'] for x in cov['data'] for f in x['files']];assert len(files)==72 and all(f.startswith(str(r)+'/') for f in files)
lock=json.loads(members['extracted/external-lock-diff.json']);assert lock['added']==[];assert {p[0] for p in lock['removed']}=={'arbitrary','jobserver','libfuzzer-sys'}
a=folder/'qpsg-candidate-checkpoint.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,raw in sorted(members.items()):i=tarfile.TarInfo(n);i.size=len(raw);i.mtime=0;t.addfile(i,io.BytesIO(raw))
hashes={n:hashlib.sha256(raw).hexdigest() for n,raw in members.items()}
with tarfile.open(a) as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
manifest={'source_commit':source,'scope':'Post-QPSG actual versioned0.5 source checkpoint. Source/package tests, compatibility, upgrade, conformance, portable/public gates, coverage and seven CI jobs pass within stated scope. Full chaos and performance/release acceptance remain open.','checks':checks,'test_observations':counts,'library_test_command':['cargo','+VERSION','test','--workspace','--all-targets','--all-features','--locked','--exclude','penelope-fuzz'],'library_scope':'Full library/integration tests and debug benchmark smokes, not release timing or doctests. Public gates separately include stable doctests. Harness totals are reported observations, not unique tests across profiles.','package_scope':'All ten clean0.5 archives identify this source. Cargo verification/include checks and extracted offline workspace all-target/all-feature tests pass on both compilers. Every Penelope dependency comes from extracted archives. No checkout-only test is skipped: six architecture checks run in compatibility harness.','lock_scope':'No runtime/build input except schema.rs changed since prior9a5 checkpoint. Extracted lock removes only fuzz-only arbitrary/jobserver/libfuzzer-sys and adds no external name/version/source/checksum. Both extracted test runs use the same normalized --locked file.','coverage':{'totals':[x['totals']['lines'] for x in cov['data']],'reported_source_files':len(files),'all_files_in_candidate':True,'ratchet':members['coverage/ratchet.stdout'].decode(),'full_json_member':'coverage/coverage.json','assessment':'Passes narrowly; lower than previous94.0976%, not evidence of improved aggregate coverage or complete branches. SQLite configuration error conversion is unexercised on supported bundled SQLite.'},'invariants':json.loads(members['checkpoint/invariant-revalidation.json']),'ci':{'source_commit':ci['headSha'],'url':ci['url'],'conclusion':ci['conclusion'],'jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']]},'bounded_selection_review':json.loads(members['checkpoint/query-order-review.json']),'conformance_upstream':'ae3d94bc22c7835eaa3fdcd766e3c117929c12bb','performance_scope':'Longer isolated QPSG studies precede adoption and preserve all findings. Expression matches adopted source apart from explanatory comment; no universal performance/latency or statistical-equivalence claim.','open':'Three-round10k-property/100k-fuzz immutablecefa55f campaign, all retained performance dispositions and final release/artifact audit. Earlier campaigns retain their old source scopes. No tag or publication.','archive':{'file':a.name,'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'member_count':len(members),'members_sha256':hashes}}
(folder/'qpsg-candidate-checkpoint.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Verified',len(members),'archive members')
