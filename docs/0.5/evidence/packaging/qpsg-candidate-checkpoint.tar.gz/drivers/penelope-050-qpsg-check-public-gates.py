import json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-qpsg-public-gates');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/candidate-metadata-checks'}
checks=[]
def run(label,args,version='1.100.0',extra=None):
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=root,env={**env,'RUSTUP_TOOLCHAIN':version,**(extra or {})},capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(label+'.'+suffix)).write_text(text)
 checks.append({'label':label,'args':args,'toolchain':version,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
for v in ['1.100.0','1.89.0']:
 for binary,feature in [('first-machine',None),('flat',None),('nested',None),('decisions',None),('timeline','timeline'),('durable','durable')]:
  args=['cargo','run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin',binary,'--locked']
  if feature:args+=['--features',feature]
  run(binary+'-'+v,args,v)
 for package,features in [('penelope-core',None),('penelope-core','serde'),('penelope-timeline',None),('penelope-timeline','alloc')]:
  args=['cargo','check','-p',package,'--no-default-features','--target','riscv32imafc-unknown-none-elf','--locked']
  if features:args+=['--features',features]
  run('portable-'+package+'-'+str(features)+'-'+v,args,v)
run('doctests',['cargo','test','--workspace','--doc','--all-features','--locked','--exclude','penelope-fuzz'])
run('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--exclude','penelope-fuzz','--','-D','warnings'])
run('compat-clippy',['cargo','clippy','--manifest-path','ci/compat-0.4/Cargo.toml','--all-targets','--all-features','--locked','--','-D','warnings'])
run('docs',['cargo','doc','--workspace','--no-deps','--all-features','--locked','--exclude','penelope-fuzz'],extra={'RUSTDOCFLAGS':'-D warnings'})
run('diff',['git','diff','--check'])
print('completed',flush=True)
