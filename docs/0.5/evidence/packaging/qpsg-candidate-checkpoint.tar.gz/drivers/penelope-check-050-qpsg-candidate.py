import subprocess,os,json,time,tomllib,hashlib
from pathlib import Path
repo=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-qpsg-candidate-checks');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTUP_TOOLCHAIN':'1.100.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/candidate-metadata-checks'}
checks=[]
def run(label,args,toolchain='1.100.0'):
 print(label,flush=True);began=time.monotonic();r=subprocess.run(args,cwd=repo,env={**env,'RUSTUP_TOOLCHAIN':toolchain},capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'toolchain':toolchain,'exit_code':r.returncode,'seconds':time.monotonic()-began});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode();return r
for label,manifest in [('workspace','Cargo.toml'),('compat','ci/compat-0.4/Cargo.toml'),('consumer','ci/machine-consumer/Cargo.toml'),('saga','ci/saga-parity/Cargo.toml'),('upgrade','ci/sqlite-upgrade/Cargo.toml')]:
 r=run('metadata-'+label,['cargo','metadata','--manifest-path',manifest,'--all-features','--locked','--format-version','1'])
 data=json.loads(r.stdout);selected=[p for p in data['packages'] if p['name'] in {d.name for d in (repo/'crates').iterdir()}]
 assert selected and all(p['version']=='0.5.0' and Path(p['manifest_path']).is_relative_to(repo) for p in selected)
 if label=='workspace':assert len(selected)==10
for label,args in [('publish-order',['python3','scripts/publish-order.py']),('fmt',['cargo','fmt','--all','--','--check']),('compat-fmt',['cargo','fmt','--manifest-path','ci/compat-0.4/Cargo.toml','--all','--','--check']),('layers',['./scripts/check-layer-boundaries.sh']),('pins',['./scripts/check-action-pins.sh']),('wire',['python3','scripts/verify-machine-wire-fixtures.py'])]:run(label,args)
for version in ['1.100.0','1.89.0']:
 run('parity-'+version,['./scripts/check-saga-machine-parity.sh'],version)
 run('upgrade-'+version,['python3','scripts/check-sqlite-upgrade.py'],version)
 run('compat-tests-'+version,['cargo','test','--manifest-path','ci/compat-0.4/Cargo.toml','--all-features','--locked'],version)
run('conformance',['python3','scripts/run-statechronicle-conformance.py','/home/ac/projects/.statechronicle-penelope-050'])
run('diff',['git','diff','--check'])
print('completed',flush=True)
