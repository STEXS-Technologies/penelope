import subprocess,os,json,hashlib,time,tomllib
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-packaged-workspace-tests');out.mkdir(exist_ok=False)
initial=Path('/tmp/penelope-packaged-workspace-qualification');unpacked=root/'target/package-stabilization-unpacked'
archives=json.loads((initial/'archives.json').read_text())
for p in archives:
 a=root/'target/package-stabilization-check/package'/p['archive'];assert hashlib.sha256(a.read_bytes()).hexdigest()==p['sha256']
original=tomllib.loads((initial/'Cargo.lock').read_text())
original_external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in original['package'] if p.get('source')}
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/package-stabilization-tests')}
checks=[]
commands=[('lock-normalization',['cargo','+1.100.0','metadata','--offline','--format-version','1']),('metadata',['cargo','+1.100.0','metadata','--locked','--format-version','1'])]
commands += [('tests-'+v,['cargo','+'+v,'test','--workspace','--all-targets','--all-features','--locked']) for v in ['1.100.0','1.89.0']]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
 if label=='lock-normalization':
  lock=(unpacked/'Cargo.lock').read_bytes();(out/'Cargo.lock').write_bytes(lock)
  data=tomllib.loads(lock.decode());external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in data['package'] if p.get('source')}
  assert external<=original_external,external-original_external
  (out/'external-lock-diff.json').write_text(json.dumps({'added':sorted(external-original_external),'removed':sorted(original_external-external)},indent=2)+'\n')
 if label=='metadata':
  data=json.loads(r.stdout);selected=[p for p in data['packages'] if p['name'].startswith('penelope')]
  assert len(selected)==10 and all(Path(p['manifest_path']).is_relative_to(unpacked) for p in selected)
assert (out/'Cargo.lock').read_bytes()==(unpacked/'Cargo.lock').read_bytes()
print('completed',flush=True)
