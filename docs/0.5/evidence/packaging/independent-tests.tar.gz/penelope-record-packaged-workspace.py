import json,tarfile,hashlib,subprocess,re
from pathlib import Path
root=Path('/home/ac/projects/penelope');raw=Path('/tmp/penelope-packaged-workspace-final');out=root/'docs/0.5/evidence/packaging'
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==4 and all(c['exit_code']==0 for c in checks)
required=['live_capacity_preserves_reserved_retries_and_reuses_fenced_slots','commit_revalidates_duplicate_conflict_and_stale_after_preflight_snapshot','full_history_refuses_new_events_but_preserves_exact_retries_and_rows']
totals={}
for version in ['1.100.0','1.89.0']:
 text=(raw/('tests-'+version+'.stdout')).read_text()
 for name in required:assert re.search(r'test [^\n]*'+name+r' \.\.\. ok',text),name
 summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 assert summaries and all(failed=='0' for _,failed,_ in summaries)
 totals[version]={'harness_summaries':len(summaries),'passed':sum(int(p) for p,_,_ in summaries),'ignored':sum(int(i) for _,_,i in summaries)}
files={}
for directory in ['penelope-packaged-workspace-qualification','penelope-packaged-workspace-tests','penelope-packaged-workspace-final']:
 for p in (Path('/tmp')/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to('/tmp'))]=p
for name in ['penelope-package-stabilization-check.log','penelope-package-stabilization-check-final.log','penelope-package-stabilization-order.txt','penelope-qualify-packaged-workspace-initial.py','penelope-test-packaged-workspace.py','penelope-test-packaged-workspace-final.py','penelope-packaged-workspace-qualification.log','penelope-packaged-workspace-tests.log','penelope-packaged-workspace-final.log','penelope-repository-gates-root-before.lock','penelope-repository-gates-compat-before.lock','penelope-repository-gates-root-lock.log','penelope-repository-gates-root-lock-final.log','penelope-repository-gates-stable.log','penelope-repository-gates-msrv.log','penelope-repository-gates-clippy.log','penelope-repository-gates-graph.log','penelope-record-packaged-workspace.py']:
 files[name]=Path('/tmp')/name
for p in (root/'target/package-stabilization-check/package').glob('*.crate'):files['final-archives/'+p.name]=p
for name in ['.github/workflows/ci.yml','.github/workflows/release.yml','ci/compat-0.4/Cargo.toml','ci/compat-0.4/Cargo.lock','ci/compat-0.4/tests/architecture.rs','crates/penelope-executor/Cargo.toml','Cargo.lock']:
 files['final-source/'+name]=root/name
archive=out/'independent-tests.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(hashes)
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Ten development archives, library verification and extracted workspace all-target/all-feature tests on Rust1.100/1.89. Versions remain0.4.0; not final0.5 qualification, publication or doctest evidence.','checks':checks,'harness_totals':totals,'source_resolution':'Cargo metadata verifies all ten Penelope packages resolve inside the extracted archive workspace, with patch.crates-io entries for each extracted package.','lock_normalization':json.loads((raw/'external-lock-diff.json').read_text()),'repository_gates':'All six architecture checks moved byte-identically from executor tests to existing CI compatibility harness; stable/MSRV and release workflows run them explicitly. Executor no longer has direct syn dev dependency. Root external versions/checksums unchanged.','initial_failures':'Direct reuse of root lock in reduced workspace first refused --locked; offline normalization removes only three fuzz-only dependencies. Initial all-target archive tests then expose two checkout-dependent architecture failures. Those failures and original archives retained.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':hashes,'open':'Performance disposition, running full chaos and exact versioned final candidate qualification remain open.'}
(out/'independent-tests.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(hashes),'totals':totals,'bytes':archive.stat().st_size},indent=2))
