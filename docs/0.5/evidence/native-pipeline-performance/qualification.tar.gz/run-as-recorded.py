import collections,csv,hashlib,json,math,os,platform,subprocess,time
from pathlib import Path
root=Path.cwd();out=Path('/tmp/penelope-native-pipeline-qualification');out.mkdir(exist_ok=False)
data=root/'target/native-pipeline-data';data.mkdir(exist_ok=True)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','TMPDIR':str(data)}
checks=[]
def run(label,args,allowed=0,**kw):
 start=time.time();p=subprocess.run(args,env=env,text=True,capture_output=True,**kw)
 (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr)
 checks.append({'label':label,'args':args,'exit_code':p.returncode,'expected_exit':allowed,'seconds':time.time()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 assert p.returncode==allowed,(label,p.returncode,p.stderr[-1000:]);print(label,'passed',flush=True);return p.stdout,p.stderr
worker=root/'crates/penelope-process-runtime/tests/fixtures/worker.c';good=out/'worker';bad=out/'wrong-worker';badsrc=out/'wrong-worker.c'
text=worker.read_text();assert text.count('u64 sum=0;')==1;badsrc.write_text(text.replace('u64 sum=0;','u64 sum=1;'))
for name,source,binary in [('good',worker,good),('wrong',badsrc,bad)]:
 run('compile-'+name,['cc','-nostdlib','-static','-fno-builtin','-fno-stack-protector','-fno-pie','-no-pie','-o',str(binary),str(source)])
env['PENELOPE_PIPELINE_WORKER']=str(good)
phases=['begin','bootstrap_restored','initial_committed','recovered','native_admitted','lost_ack_recovered','native_setup','dispatch_return','durable_completed','result_verified','result_committed','saga_admitted']
required=['committed=256 revision=1','overflow_rejected=true revision_unchanged=true','restored=256 retained_intents=1 duplicate=AlreadyCommitted','provenance_verified=true source_revision=1','reopened=true task_recovered=true attempt=2 stale_ack_refused=true','task_admitted=true generation=0 source_acknowledged=true','task_result_verified=true amount=1','result_committed=true state=257 revision=2','saga_admitted=true native_actions=1 source_acknowledged=true']
def validate(stdout,samples,warmup):
 lines=stdout.splitlines();counts=collections.Counter(lines)
 for line in required: assert counts[line]==samples+warmup,(line,counts[line])
 rows=list(csv.reader(line for line in lines if line.startswith('native_pipeline_')))
 spans=collections.defaultdict(list);totals={};summaries={}
 for row in rows:
  if row[0]=='native_pipeline_sample':
   _,index,phase,nanos,warm=row;index=int(index);nanos=int(nanos)
   assert 0<=index<samples+warmup and phase in phases and nanos>0 and warm==str(index<warmup).lower()
   spans[index].append((phase,nanos))
  elif row[0]=='native_pipeline_total':
   _,index,offset,total,warm=row;index=int(index);assert index not in totals and warm==str(index<warmup).lower();totals[index]=(int(offset),int(total))
  elif row[0]=='native_pipeline_summary':
   _,phase,count,p50,p95,p99=row;assert phase not in summaries and int(count)==samples;summaries[phase]=[int(p50),int(p95),int(p99)]
  else:assert False,row
 assert set(spans)==set(totals)==set(range(samples+warmup));assert set(summaries)==set(phases)
 for i,values in spans.items():
  assert [phase for phase,_ in values]==phases
  offset,total=totals[i];assert offset>=0 and offset+sum(n for _,n in values)==total
 for j,phase in enumerate(phases):
  values=sorted(spans[i][j][1] for i in range(warmup,samples+warmup))
  assert summaries[phase]==[values[math.ceil(samples*p/100)-1] for p in [50,95,99]]
 return {'summaries':summaries,'total_ns':[totals[i][1] for i in range(warmup,samples+warmup)],'warmup':warmup,'samples':samples}
manifest='ci/machine-consumer/Cargo.toml';metadata={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],text=True),'platform':platform.platform(),'cpu':4,'data_parent':str(data),'filesystem':json.loads(subprocess.check_output(['findmnt','-J','-T',str(data)],text=True)),'worker_sha256':hashlib.sha256(good.read_bytes()).hexdigest(),'wrong_worker_sha256':hashlib.sha256(bad.read_bytes()).hexdigest(),'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['ci/machine-consumer/Cargo.toml','ci/machine-consumer/Cargo.lock','ci/machine-consumer/durable.rs','ci/machine-consumer/workflow.rs','ci/machine-consumer/native_pipeline.rs','crates/penelope/examples/support/counter.rs','crates/penelope/examples/support/counter_codec.rs','crates/penelope-process-runtime/tests/fixtures/worker.c']},'binaries':{},'rustc':{},'cc':run('cc-version',['cc','--version'])[0]}
results={}
for toolchain,count in [('1.100.0',3),('1.89.0',1)]:
 metadata['rustc'][toolchain]=run('rustc-'+toolchain,['rustc','+'+toolchain,'-vV'])[0]
 build=run('build-'+toolchain,['cargo','+'+toolchain,'bench','--manifest-path',manifest,'--locked','--features','protected','--bench','native_pipeline','--no-run','--message-format=json'])[0]
 artifacts=[e for line in build.splitlines() if (e:=json.loads(line)).get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='native_pipeline' and e.get('executable')];assert len(artifacts)==1 and not artifacts[0]['profile']['debug_assertions']
 binary=artifacts[0]['executable'];metadata['binaries'][toolchain]=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
 for i in range(count):
  label=f'release-{toolchain}-{i+1}'
  stdout,_=run(label,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e}','-o',str(out/(label+'.resources.json')),'taskset','-c','4',binary]);results[label]=validate(stdout,101,8)
 env['PENELOPE_PIPELINE_WORKER']=str(bad)
 stdout,stderr=run('wrong-result-benchmark-'+toolchain,['taskset','-c','4',binary],allowed=1)
 assert 'task result schema or meaning differs; no result event admitted' in stderr
 assert 'result_committed=true' not in stdout and 'native_pipeline_summary' not in stdout
 env['PENELOPE_PIPELINE_WORKER']=str(good)
 stdout,_=run('debug-'+toolchain,['cargo','+'+toolchain,'test','--manifest-path',manifest,'--locked','--features','protected','--bench','native_pipeline']);validate(stdout,3,1)
 for profile,features,args in [('admission','durable',[]),('protected','protected',[str(good)])]:
  stdout,_=run(profile+'-'+toolchain,['cargo','+'+toolchain,'run','--manifest-path',manifest,'--locked','--features',features,'--bin','durable','--',*args])
  assert 'saga_admitted=true native_actions=1 source_acknowledged=true' in stdout
  if profile=='protected':assert all(line in stdout.splitlines() for line in required)
 stdout,stderr=run('wrong-result-consumer-'+toolchain,['cargo','+'+toolchain,'run','--manifest-path',manifest,'--locked','--features','protected','--bin','durable','--',str(bad)],allowed=1)
 assert 'task result schema or meaning differs; no result event admitted' in stderr and 'result_committed=true' not in stdout
run('clippy',['cargo','clippy','--manifest-path',manifest,'--locked','--all-targets','--all-features','--','-D','warnings'])
run('consumer-format',['cargo','fmt','--manifest-path',manifest,'--','--check'])
run('workspace-format',['cargo','fmt','--all','--','--check'])
run('diff',['git','diff','--check'])
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print('All phase identities, timestamps, sums, ranks, output counts and negative cases verified',flush=True)
