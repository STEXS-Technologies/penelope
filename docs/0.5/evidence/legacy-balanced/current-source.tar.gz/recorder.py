"""Retain current-source paired performance evidence without granting exceptions."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/ac/projects/penelope')
BASE = ROOT / 'docs/0.5/evidence'
SOURCE = '7ab93d2cbb426f1e058fb7abc76c42c3f8582178'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def retain(raw, destination, extras):
    files = {str(p.relative_to(raw)): p for p in raw.rglob('*') if p.is_file()}
    files.update(extras)
    files['recorder.py'] = Path(__file__)
    hashes = {name: sha(path) for name, path in files.items()}
    with tarfile.open(destination, 'w:gz') as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
    with tarfile.open(destination) as archive:
        assert {m.name: hashlib.sha256(archive.extractfile(m).read()).hexdigest()
                for m in archive if m.isfile()} == hashes
    return {'file': destination.name, 'sha256': sha(destination), 'members_sha256': hashes}


raw = Path('/tmp/penelope-050-sqlite-post-qpsg-candidate')
sqlite = read(raw / 'summary.json')
assert sqlite['pairs'] == 31 and sqlite['revisions']['after'] == SOURCE
assert sqlite['revisions']['before'] == '42ec187c9adfc7403b06215f405f2575f53c35c2'
assert len(sqlite['metrics']) == 41
binary_hashes = {}
for label in ('before', 'after'):
    reports = sorted(raw.glob('pair-*-' + label))
    assert len(reports) == 31
    for directory in reports:
        meta = read(directory / 'metadata.json')
        assert meta['revision'] == sqlite['revisions'][label] and meta['tracked_diff'] == ''
        report = read(directory / 'run-1.json')
        assert report['journal_mode'] == 'WAL' and report['synchronous'] == 'FULL'
        assert [case['records'] for case in report['tasks']] == [16, 128, 512]
    binary_hashes[label] = sha(raw / 'binaries' / label)
    assert read(raw / ('source-' + label + '.json'))
flags = [row for row in sqlite['metrics'] if row['review_flag']]
sqlite_archive = retain(raw, BASE / 'sqlite-balanced/post-qpsg-current.tar.gz', {
    'drivers/comparison.py': BASE / 'sqlite-balanced/post-qpsg-candidate.py',
    'drivers/benchmark-durable-store.py': ROOT / 'scripts/benchmark-durable-store.py',
    'drivers/summarize.py': BASE / 'sqlite-balanced/summarize-post-qpsg.py',
})
sqlite_record = {
    'scope': 'Fresh current-source post-QPSG paired SQLite comparison against original 0.4. This is performance evidence, not a performance exception or release acceptance.',
    'measured_at_utc': read(raw / 'pair-01-after/metadata.json')['measured_at'],
    'revisions': sqlite['revisions'], 'pairs': 31, 'warmup_pairs_excluded': 1,
    'measured_processes': 62, 'metrics': sqlite['metrics'], 'review_flags': flags,
    'binary_sha256': binary_hashes,
    'summary': 'Earlier warm-replay and exact-retry regressions are not observed above their thresholds in this current-source run. All historical findings remain retained. New/sustained flags remain open for small-history reopen and append-tail latency.',
    'conditions': read(raw / 'comparison.json'),
    'limits': sqlite['limits'] + [
        'There are only ten replay observations per process; sixteen-record append has fourteen observations, so its nearest-rank p95 is the maximum. Run medians do not establish a rare-tail guarantee.',
        'No concurrent qualification or benchmark was launched during these measured processes; this remains a shared host with uncontrolled frequency, OS cache and external activity.',
        'The preflight rejects tracked candidate changes. All per-run tracked diffs are empty; post-run git-content and resolved-build-content inventories include symlink targets.',
        'The previous 16 SQLite flags are not erased or accepted. A later unflagged run is a scoped observation, not a waiver of the two remaining flags or a proof of equivalence.',
        'Full immutable-source chaos was deliberately not run at the user\'s request. This timing comparison does not close that gate.',
    ],
    'archive': sqlite_archive,
}
(BASE / 'sqlite-balanced/post-qpsg-current.json').write_text(json.dumps(sqlite_record, indent=2) + '\n')

raw = Path('/tmp/penelope-pre-pr-legacy-comparison')
legacy = read(raw / 'summary.json')
metadata = read(raw / 'metadata.json')
assert legacy['pairs'] == 31 and legacy['records'] == 496 and legacy['source_fixtures_identical']
assert legacy['revisions'] == sqlite['revisions']
assert len(metadata['benchmarks']) == 8 and metadata['timeline_samples'] == '1000'
for label, binaries in metadata['binaries'].items():
    for name, digest in binaries.items():
        assert sha(raw / 'binaries' / label / name) == digest
# Every ring_* timed closure belongs to the fixture's handwritten Ring substrate.
controls = {row['operation'] for row in legacy['rows'] if row['operation'].startswith('ring_')}
legacy_flags = [row for row in legacy['rows'] if row['review_flag']]
legacy_archive = retain(raw, BASE / 'legacy-balanced/current-source.tar.gz', {
    'drivers/comparison.py': Path('/tmp/penelope-pre-pr-legacy-original-driver.py'),
    'drivers/summarize.py': Path('/tmp/penelope-pre-pr-legacy-summarize.py'),
    'drivers/summarize-decision-perf.py': ROOT / 'scripts/summarize-decision-perf.py',
    'driver.log': Path('/tmp/penelope-pre-pr-legacy-comparison.log'),
})
legacy_record = {
    'scope': 'Eight unchanged legacy workloads freshly compared at current source versus original 0.4. All observations and flags retained; no performance exception is accepted.',
    'revisions': legacy['revisions'], 'pairs': 31, 'records': 496,
    'benchmarks': metadata['benchmarks'], 'metrics': len(legacy['rows']),
    'timeline_samples_per_profile_per_process': 1000,
    'review_flags': [{k: v for k, v in row.items() if k not in ('before', 'after')}
                     for row in legacy_flags],
    'flag_counts': {
        'total': len(legacy_flags),
        'library': sum(row['operation'] not in controls for row in legacy_flags),
        'handwritten_controls': sum(row['operation'] in controls for row in legacy_flags),
    },
    'control_profile_role': 'All ring_* profiles are handwritten fixture substrate operations, including capture, append, replay, restore and promotion; none is subtracted from a library result.',
    'conditions': 'Pure process workloads pinned to CPU4 or parallel CPUs4–7; package checks pinned to CPUs8–9 and coverage to CPUs10–11 may overlap. Shared host frequency, caches, memory bandwidth and external activity are uncontrolled. No isolation or causal attribution claim.',
    'limits': [legacy['policy'],
               'Saga/task/DTO measurements are loop means, not individual-call percentiles.',
               'Handwritten Ring control flags remain visible and are never subtracted from library results.',
               'The complete per-profile rows and all raw processes, fixtures, locks and sixteen measured binaries are archived.',
               'All historical findings retain their original scope. No source or linker hint was changed to improve timing.'],
    'archive': legacy_archive,
}
(BASE / 'legacy-balanced/current-source.json').write_text(json.dumps(legacy_record, indent=2) + '\n')

decisions = []
for family, rows in (('sqlite', flags), ('legacy', legacy_flags)):
    for row in rows:
        control = family == 'legacy' and row['operation'] in controls
        decisions.append({'family': family,
                          'profile': {key: row[key] for key in ('benchmark', 'operation', 'state_words', 'steps', 'metric') if key in row},
                          'median_before': row['median_before'], 'median_after': row['median_after'],
                          'median_delta_percent': row['median_delta_percent'],
                          'paired_threshold_exceedances': row['paired_threshold_exceedances'],
                          'disposition': 'retained fixture control; no library performance claim' if control else 'open review blocker; neither fixed nor explicitly accepted',
                          'acceptance_granted': False})
record = {'source_commit': SOURCE, 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Performance disposition inventory for current-source review. Produces a concrete list of remaining decisions; does not grant review approval.',
          'comparisons': {'sqlite': '../sqlite-balanced/post-qpsg-current.json', 'legacy': '../legacy-balanced/current-source.json'},
          'decisions': decisions,
          'open_library_flags': sum(not ('control' in row['disposition']) for row in decisions),
          'historical_findings': 'Preserved in the versioned candidate and diagnostic manifests. Earlier severe SQLite replay/retry flags do not recur in the current run; they are not deleted or silently accepted.',
          'merge_recommendation': 'Hold merge under plan §13.2 while library performance blockers lack a fix or explicit evidence-backed acceptance. Full chaos remains a separate incomplete qualification gate; the user excluded its execution, not its status.',
          'pr_opened': False}
(BASE / 'qualification/current-performance-review.json').write_text(json.dumps(record, indent=2) + '\n')
print('Retained SQLite', len(flags), 'flags; legacy', len(legacy_flags), 'flags;', record['open_library_flags'], 'library review decisions remain')
