from pathlib import Path
import json,gzip,hashlib,tarfile,subprocess,runpy
root=Path('/home/ac/projects/penelope')
raw=Path('/tmp/penelope-timeline-current-paired')
out=root/'docs/0.5/evidence/legacy-balanced'
summary=runpy.run_path(str(out/'summarize.py'))['summarize'](raw)
assert summary['pairs']==31 and summary['records']==62
(raw/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
flags=[{k:v for k,v in r.items() if k not in ['before','after']} for r in summary['rows'] if r['review_flag']]
files={str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
files['driver.py']=root/'scripts/benchmark-decision-comparison.py'
files['summarize.py']=out/'summarize.py'
files['summarize-decision-perf.py']=root/'scripts/summarize-decision-perf.py'
files['record.py']=Path(__file__)
files['driver.log']=Path('/tmp/penelope-timeline-current-paired.log')
archive=out/'timeline-current.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name)
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(hashes)
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
m={'scope':'31 alternating same-workload legacy timeline pairs; development checkpoint, no equivalence or performance acceptance claim','revisions':summary['revisions'],'pairs':31,'records':62,'profiles':len(summary['rows'])//3,'samples_per_profile_per_process':1000,'review_flags':flags,'conditions':'Serial measurement on CPU4; live chaos root separately observed on CPUs8-15; shared host applications, frequency, cache and memory bandwidth uncontrolled. Copies and code inspection occurred while campaign ran; no observations removed. One warmup pair excluded by existing driver policy.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':hashes,'open':'Historical flags remain retained. Current findings need diagnosis and explicit disposition; exact final candidate qualification remains open.'}
(out/'timeline-current.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'profiles':m['profiles'],'flags':flags,'members':len(hashes)},indent=2))
