import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/penelope')
raw=Path('/tmp/penelope-pre-pr-owned-serializer-measure')
meta=json.loads((raw/'metadata.json').read_text());summary=json.loads((raw/'summary.json').read_text())
assert meta['rounds']==31 and summary['medians_ns']['probe']>summary['medians_ns']['candidate']
probe=Path('/home/ac/projects/.penelope-pre-pr-owned-serializer-probe')
(raw/'probe.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','crates'],cwd=probe))
files={str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
for name in ['owned-serializer-measure.py','owned-serializer-stable.log','owned-serializer-msrv.log','owned-serializer-build.jsonl','owned-serializer-build.stderr']:
 p=Path('/tmp/penelope-pre-pr-'+name);assert p.is_file();files['checks/'+name]=p
files['recorder.py']=Path(__file__)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={n:sha(p) for n,p in files.items()}
dest=root/'docs/0.5/evidence/legacy-balanced/owned-serializer-rejected.tar.gz'
with tarfile.open(dest,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(dest) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
record={'scope':'Isolated owning JSON serializer probe against original 0.4 and unchanged 7ab candidate; rejected and not integrated. No performance acceptance granted.','metadata':meta,'medians_ns':summary['medians_ns'],'disposition':'Rejected: frozen DTO workload did not improve. Stable/MSRV domain and ports tests passed, including golden wire format and one-allocation checks; passing correctness does not justify a slower implementation.','archive':{'file':dest.name,'sha256':sha(dest),'members_sha256':hashes}}
(root/'docs/0.5/evidence/legacy-balanced/owned-serializer-rejected.json').write_text(json.dumps(record,indent=2)+'\n')
print('Rejected serializer experiment retained with verified archive')
