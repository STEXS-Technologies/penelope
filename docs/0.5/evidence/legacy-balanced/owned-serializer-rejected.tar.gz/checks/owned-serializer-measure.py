import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
# Queue behind the currently live timeline timing process to avoid competing
# benchmarks. Pin its exact process start identity rather than a stale log flag.
live=[]
for p in Path('/proc').glob('[0-9]*'):
 try:
  if b'/tmp/penelope-pre-pr-lineage-borrow-measure.py' in p.joinpath('cmdline').read_bytes().split(b'\0'):
   live.append((p,p.joinpath('stat').read_text().rsplit(')',1)[1].split()[19]))
 except OSError:pass
assert len(live)<=1
for p,start in live:
 print('Waiting for live timeline process',p.name,flush=True)
 while True:
  try:
   if p.joinpath('stat').read_text().rsplit(')',1)[1].split()[19]!=start:break
  except OSError:break
  time.sleep(1)
root=Path('/home/ac/projects/.penelope-pre-pr-owned-serializer-probe')
out=Path('/tmp/penelope-pre-pr-owned-serializer-measure');out.mkdir(exist_ok=False)
build=Path('/tmp/penelope-pre-pr-owned-serializer-build.jsonl')
arts=[e['executable'] for line in build.read_text().splitlines() if (e:=json.loads(line)).get('reason')=='compiler-artifact' and e['target']['name']=='contract_throughput' and e.get('executable')];assert len(arts)==1
bins={'original':Path('/tmp/penelope-pre-pr-legacy-comparison/binaries/before/contract_throughput'),'candidate':Path('/tmp/penelope-pre-pr-legacy-comparison/binaries/after/contract_throughput'),'probe':Path(arts[0])}
for label,path in bins.items():shutil.copy2(path,out/(label+'.bin'))
source=root/'crates/penelope-domain/src/implementation.rs';before=hashlib.sha256(source.read_bytes()).hexdigest()
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=root))
(out/'metadata.json').write_text(json.dumps({'base':'7ab93d2cbb426f1e058fb7abc76c42c3f8582178','source_sha256':before,'binary_sha256':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in bins.items()},'rounds':31,'warmups':1,'cpu':4,'scope':'Isolated owning serializer trial; capacity, Serde format, fixture and production hints unchanged.'},indent=2)+'\n')
labels=list(bins)
for i in range(32):
 for label in labels[i%3:]+labels[:i%3]:
  name=('warmup' if i==0 else f'round-{i:02d}')+'-'+label
  r=subprocess.run(['taskset','-c','4',str(out/(label+'.bin'))],capture_output=True,text=True)
  (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);r.check_returncode()
 print('Completed triple',i,flush=True)
assert before==hashlib.sha256(source.read_bytes()).hexdigest()
