import hashlib,importlib.util,json,os,shutil,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/tmp/penelope-encoding-layout-controls');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{4,5,6,7})
spec=importlib.util.spec_from_file_location('bench',root/'scripts/benchmark-decision-comparison.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
original=json.loads(Path('/tmp/penelope-encoding-edge-diagnostic/metadata.json').read_text())['variants']['candidate']['binary']
entries=[json.loads(l) for l in Path('/tmp/penelope-encoding-layout-build.jsonl').read_text().splitlines()]
shifted=next(e['executable'] for e in entries if e.get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='contract_throughput' and e.get('executable'))
binaries={};metadata={'purpose':'Compare original link layout with two explicit .text placements on unchanged source. Diagnostic linker flags only; no production setting or acceptance.','rounds':15,'variants':{},'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],text=True)}
def capture(label,source):
 dest=out/label.ljust(24,'_');shutil.copy2(source,dest);binaries[label]=str(dest)
 sections=subprocess.check_output(['readelf','-SW',dest],text=True);segments=subprocess.check_output(['readelf','-lW',dest],text=True);symbols=subprocess.check_output(['nm','-S','--demangle',dest],text=True)
 for suffix,text in [('sections.txt',sections),('segments.txt',segments),('symbols.txt',symbols)]: (out/(label+'-'+suffix)).write_text(text)
 textpath=out/(label+'.text.bin');subprocess.run(['objcopy','--dump-section','.text='+str(textpath),dest],check=True)
 metadata['variants'][label]={'binary_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'text_sha256':hashlib.sha256(textpath.read_bytes()).hexdigest(),'text_bytes':textpath.stat().st_size,'canonical_symbol':next(l for l in symbols.splitlines() if 'canonical_wire_bytes' in l)}
 subprocess.run(['taskset','-c','4',dest],stdout=subprocess.DEVNULL,check=True)
capture('original',original);capture('text-19360',shifted)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/encoding-layout-diagnostic')}
args=['cargo','+1.100.0','rustc','--locked','-p','penelope-ports','--bench','contract_throughput','--profile','bench','--message-format=json','--','-C','link-arg=-Wl,--section-start=.text=0x19340']
p=subprocess.run(args,env=env,text=True,capture_output=True);(out/'control-build.jsonl').write_text(p.stdout);(out/'control-build.stderr').write_text(p.stderr);p.check_returncode()
entries=[json.loads(l) for l in p.stdout.splitlines()];base=next(e['executable'] for e in entries if e.get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='contract_throughput' and e.get('executable'))
capture('text-19340',base)
metadata['control_build_args']=args
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
for round in range(1,16):
 labels=list(binaries);labels=labels[round%3:]+labels[:round%3]
 for label in labels:
  counter=out/f'round-{round}-{label}.perf.jsonl'
  p=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(counter),'--','taskset','-c','4',binaries[label]],capture_output=True,text=True)
  (out/f'round-{round}-{label}.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'observations':bench.observations(p.stdout)},indent=2)+'\n');p.check_returncode()
 print('Completed layout-control round',round,flush=True)
