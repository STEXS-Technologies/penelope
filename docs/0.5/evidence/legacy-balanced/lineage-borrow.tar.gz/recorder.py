import hashlib,json,tarfile
from pathlib import Path
root=Path('/home/ac/projects/penelope');raw=Path('/tmp/penelope-pre-pr-lineage-borrow-measure')
meta=json.loads((raw/'metadata.json').read_text());summary=json.loads((raw/'summary.json').read_text());assert meta['rounds']==summary['rounds']==31
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,digest in meta['binaries_sha256'].items():assert sha(raw/(label+'.bin'))==digest
assert sha(root/'crates/penelope-timeline/src/history.rs')==meta['probe_history_sha256']
files={str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
for name in ['lineage-borrow-measure.py','lineage-borrow-continue.py','lineage-borrow.patch']:
 p=Path('/tmp/penelope-pre-pr-'+name);assert p.is_file();files['drivers/'+name]=p
files['summarize.py']=Path('/tmp/penelope-summarize-lineage-borrow.py');files['recorder.py']=Path(__file__)
for label in ['before','after','probe']:files['codegen/'+label+'-resolve-input.asm']=Path('/tmp/penelope-pre-pr-timeline-diagnostic/'+label+'-resolve-input.asm')
hashes={n:sha(p) for n,p in files.items()};dest=root/'docs/0.5/evidence/legacy-balanced/lineage-borrow.tar.gz'
with tarfile.open(dest,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(dest) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
flags=[{k:v for k,v in r.items() if k!='samples'} for r in summary['rows'] if any(r['review_flags'].values())]
selected=[{k:v for k,v in r.items() if k!='samples'} for r in summary['rows'] if r['operation'] in ('history_collect_root','history_read_all_inherited') and r['state_words']==1 and r['steps'] in (1,8,32,128) and r['metric']=='p50_ns']
record={'scope':'Base 7ab93d2 plus retained timeline borrowing patch; original 0.4/current candidate/probe rotating triples. No acceptance or source equivalence claim.','metadata':meta,'metrics':len(summary['rows']),'profiles':640,'flags':summary['flags'],'review_rows':flags,'selected_profiles':selected,'disposition':'Integrate borrowing: inherited read p50 improves 18.42–30.69% over candidate across selected horizons; no inherited-read threshold flags remain versus original. Seven other library p50 flags versus original remain open. All controls retained without subtraction.','mechanism':'Return borrowed Lineage and inspect borrowed optional overrides; copy exact matched input/anchor only. No changes to lookup ordering, validation, admission, allocation, layout or public API. Measured State1 resolve_input shrinks from 1358 to 1091 bytes and has no memcpy calls.','limits':['31 rotating triples, 1000 observations per profile; run-level medians, not pooled call percentiles.','Shared host; unrelated compiler/tests on other pinned cores overlap some rounds. Frequency, shared resources and OS activity uncontrolled.','Exact rational threshold comparisons preserve strict >5% / >10%; exact 5% is not flagged. No historical source finding erased.','Initial 12-round summaries retained; final 31-round result has more residual flags than initial slice. No equivalence or performance acceptance granted.'],'archive':{'file':dest.name,'sha256':sha(dest),'members_sha256':hashes}}
(root/'docs/0.5/evidence/legacy-balanced/lineage-borrow.json').write_text(json.dumps(record,indent=2)+'\n')
print('31-round timeline result retained; seven noninherited median findings remain open')
