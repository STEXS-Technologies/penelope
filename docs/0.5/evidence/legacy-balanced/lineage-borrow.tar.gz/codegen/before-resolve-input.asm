
/tmp/penelope-pre-pr-legacy-comparison/binaries/before/timeline_operations:     file format elf64-x86-64


Disassembly of section .text:

0000000000058ad0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input>:
   58ad0:	55                   	push   %rbp
   58ad1:	41 57                	push   %r15
   58ad3:	41 56                	push   %r14
   58ad5:	41 55                	push   %r13
   58ad7:	41 54                	push   %r12
   58ad9:	53                   	push   %rbx
   58ada:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
   58ae1:	48 8b ae 38 1f 02 00 	mov    0x21f38(%rsi),%rbp
   58ae8:	48 39 e9             	cmp    %rbp,%rcx
   58aeb:	76 5a                	jbe    58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58aed:	4c 8b 36             	mov    (%rsi),%r14
   58af0:	4c 8b a6 c8 01 00 00 	mov    0x1c8(%rsi),%r12
   58af7:	49 83 fe 02          	cmp    $0x2,%r14
   58afb:	0f 95 c0             	setne  %al
   58afe:	4c 8d 8e e8 01 00 00 	lea    0x1e8(%rsi),%r9
   58b05:	4c 8b be e8 01 00 00 	mov    0x1e8(%rsi),%r15
   58b0c:	4c 8b 96 b0 03 00 00 	mov    0x3b0(%rsi),%r10
   58b13:	49 39 d4             	cmp    %rdx,%r12
   58b16:	41 0f 94 c0          	sete   %r8b
   58b1a:	4c 89 f3             	mov    %r14,%rbx
   58b1d:	49 89 f5             	mov    %rsi,%r13
   58b20:	44 84 c0             	test   %r8b,%al
   58b23:	75 19                	jne    58b3e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x6e>
   58b25:	49 83 ff 02          	cmp    $0x2,%r15
   58b29:	0f 95 c0             	setne  %al
   58b2c:	49 39 d2             	cmp    %rdx,%r10
   58b2f:	41 0f 94 c0          	sete   %r8b
   58b33:	4c 89 fb             	mov    %r15,%rbx
   58b36:	4d 89 cd             	mov    %r9,%r13
   58b39:	44 84 c0             	test   %r8b,%al
   58b3c:	74 09                	je     58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58b3e:	49 3b 8d d8 01 00 00 	cmp    0x1d8(%r13),%rcx
   58b45:	76 17                	jbe    58b5e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x8e>
   58b47:	66 c7 07 01 03       	movw   $0x301,(%rdi)
   58b4c:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
   58b53:	5b                   	pop    %rbx
   58b54:	41 5c                	pop    %r12
   58b56:	41 5d                	pop    %r13
   58b58:	41 5e                	pop    %r14
   58b5a:	41 5f                	pop    %r15
   58b5c:	5d                   	pop    %rbp
   58b5d:	c3                   	ret
   58b5e:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
   58b63:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   58b68:	48 f7 d5             	not    %rbp
   58b6b:	48 01 cd             	add    %rcx,%rbp
   58b6e:	48 69 c5 f0 00 00 00 	imul   $0xf0,%rbp,%rax
   58b75:	4c 8d 1c 06          	lea    (%rsi,%rax,1),%r11
   58b79:	49 81 c3 b8 3e 00 00 	add    $0x3eb8,%r11
   58b80:	49 8b 45 08          	mov    0x8(%r13),%rax
   58b84:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   58b89:	49 8b 45 10          	mov    0x10(%r13),%rax
   58b8d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   58b92:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
   58b99:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   58b9e:	4d 8b 85 d0 01 00 00 	mov    0x1d0(%r13),%r8
   58ba5:	48 81 fd ff 01 00 00 	cmp    $0x1ff,%rbp
   58bac:	77 36                	ja     58be4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x114>
   58bae:	41 0f b6 83 e8 00 00 	movzbl 0xe8(%r11),%eax
   58bb5:	00 
   58bb6:	3c 02                	cmp    $0x2,%al
   58bb8:	74 2a                	je     58be4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x114>
   58bba:	4d 89 c2             	mov    %r8,%r10
   58bbd:	4d 8b 83 c8 00 00 00 	mov    0xc8(%r11),%r8
   58bc4:	49 31 c8             	xor    %rcx,%r8
   58bc7:	4d 8b 8b c0 00 00 00 	mov    0xc0(%r11),%r9
   58bce:	49 31 d1             	xor    %rdx,%r9
   58bd1:	4d 09 c1             	or     %r8,%r9
   58bd4:	41 0f 94 c0          	sete   %r8b
   58bd8:	41 84 c0             	test   %al,%r8b
   58bdb:	4d 89 d0             	mov    %r10,%r8
   58bde:	0f 85 8c 02 00 00    	jne    58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x3a0>
   58be4:	48 85 db             	test   %rbx,%rbx
   58be7:	0f 94 c0             	sete   %al
   58bea:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
   58bef:	4c 39 c1             	cmp    %r8,%rcx
   58bf2:	41 0f 97 c0          	seta   %r8b
   58bf6:	41 08 c0             	or     %al,%r8b
   58bf9:	41 80 f8 01          	cmp    $0x1,%r8b
   58bfd:	0f 85 86 00 00 00    	jne    58c89 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b9>
   58c03:	4c 8d 86 b8 3e 00 00 	lea    0x3eb8(%rsi),%r8
   58c0a:	31 c0                	xor    %eax,%eax
   58c0c:	eb 17                	jmp    58c25 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x155>
   58c0e:	66 90                	xchg   %ax,%ax
   58c10:	48 05 20 fe ff ff    	add    $0xfffffffffffffe20,%rax
   58c16:	49 81 c0 e0 01 00 00 	add    $0x1e0,%r8
   58c1d:	48 3d 00 20 fe ff    	cmp    $0xfffffffffffe2000,%rax
   58c23:	74 64                	je     58c89 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b9>
   58c25:	45 0f b6 88 e8 00 00 	movzbl 0xe8(%r8),%r9d
   58c2c:	00 
   58c2d:	41 80 f9 02          	cmp    $0x2,%r9b
   58c31:	74 1d                	je     58c50 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x180>
   58c33:	49 39 88 c8 00 00 00 	cmp    %rcx,0xc8(%r8)
   58c3a:	75 14                	jne    58c50 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x180>
   58c3c:	49 39 90 c0 00 00 00 	cmp    %rdx,0xc0(%r8)
   58c43:	41 0f 94 c2          	sete   %r10b
   58c47:	45 84 ca             	test   %r9b,%r10b
   58c4a:	0f 85 1d 02 00 00    	jne    58e6d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x39d>
   58c50:	45 0f b6 88 d8 01 00 	movzbl 0x1d8(%r8),%r9d
   58c57:	00 
   58c58:	41 80 f9 02          	cmp    $0x2,%r9b
   58c5c:	74 b2                	je     58c10 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x140>
   58c5e:	49 39 88 b8 01 00 00 	cmp    %rcx,0x1b8(%r8)
   58c65:	75 a9                	jne    58c10 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x140>
   58c67:	49 39 90 b0 01 00 00 	cmp    %rdx,0x1b0(%r8)
   58c6e:	41 0f 94 c2          	sete   %r10b
   58c72:	45 84 ca             	test   %r9b,%r10b
   58c75:	74 99                	je     58c10 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x140>
   58c77:	49 89 f3             	mov    %rsi,%r11
   58c7a:	49 29 c3             	sub    %rax,%r11
   58c7d:	49 81 c3 a8 3f 00 00 	add    $0x3fa8,%r11
   58c84:	e9 e7 01 00 00       	jmp    58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x3a0>
   58c89:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
   58c8e:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   58c93:	48 89 3c 24          	mov    %rdi,(%rsp)
   58c97:	49 8d 75 18          	lea    0x18(%r13),%rsi
   58c9b:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   58ca0:	ba c8 00 00 00       	mov    $0xc8,%edx
   58ca5:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   58caa:	ff 15 20 c7 06 00    	call   *0x6c720(%rip)        # c53d0 <memcpy@GLIBC_2.14>
   58cb0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   58cb5:	48 83 7c 24 48 01    	cmpq   $0x1,0x48(%rsp)
   58cbb:	75 52                	jne    58d0f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x23f>
   58cbd:	48 39 44 24 40       	cmp    %rax,0x40(%rsp)
   58cc2:	75 4b                	jne    58d0f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x23f>
   58cc4:	49 8b 9d e8 00 00 00 	mov    0xe8(%r13),%rbx
   58ccb:	4c 8d bc 24 20 01 00 	lea    0x120(%rsp),%r15
   58cd2:	00 
   58cd3:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   58cd8:	ba c8 00 00 00       	mov    $0xc8,%edx
   58cdd:	4c 89 ff             	mov    %r15,%rdi
   58ce0:	49 89 c6             	mov    %rax,%r14
   58ce3:	ff 15 e7 c6 06 00    	call   *0x6c6e7(%rip)        # c53d0 <memcpy@GLIBC_2.14>
   58ce9:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
   58cf0:	00 
   58cf1:	48 89 9c 24 f0 01 00 	mov    %rbx,0x1f0(%rsp)
   58cf8:	00 
   58cf9:	48 8b 3c 24          	mov    (%rsp),%rdi
   58cfd:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   58d02:	4c 89 fa             	mov    %r15,%rdx
   58d05:	e8 c6 ed ff ff       	call   57ad0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::exact_input>
   58d0a:	e9 3d fe ff ff       	jmp    58b4c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58d0f:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
   58d14:	76 0e                	jbe    58d24 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x254>
   58d16:	48 8b 04 24          	mov    (%rsp),%rax
   58d1a:	66 c7 00 01 03       	movw   $0x301,(%rax)
   58d1f:	e9 28 fe ff ff       	jmp    58b4c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58d24:	48 83 fb 01          	cmp    $0x1,%rbx
   58d28:	48 8b 3c 24          	mov    (%rsp),%rdi
   58d2c:	0f 85 15 fe ff ff    	jne    58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58d32:	41 83 fe 02          	cmp    $0x2,%r14d
   58d36:	0f 95 c1             	setne  %cl
   58d39:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   58d3e:	4d 39 c4             	cmp    %r8,%r12
   58d41:	0f 94 c2             	sete   %dl
   58d44:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   58d49:	49 89 f5             	mov    %rsi,%r13
   58d4c:	84 d1                	test   %dl,%cl
   58d4e:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   58d53:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   58d58:	75 1e                	jne    58d78 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2a8>
   58d5a:	49 83 ff 02          	cmp    $0x2,%r15
   58d5e:	0f 95 c1             	setne  %cl
   58d61:	4c 39 c2             	cmp    %r8,%rdx
   58d64:	0f 94 c2             	sete   %dl
   58d67:	20 ca                	and    %cl,%dl
   58d69:	4d 89 fe             	mov    %r15,%r14
   58d6c:	4d 89 cd             	mov    %r9,%r13
   58d6f:	80 fa 01             	cmp    $0x1,%dl
   58d72:	0f 85 cf fd ff ff    	jne    58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58d78:	49 3b 85 d8 01 00 00 	cmp    0x1d8(%r13),%rax
   58d7f:	0f 87 c2 fd ff ff    	ja     58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58d85:	4d 8b 65 10          	mov    0x10(%r13),%r12
   58d89:	4d 8b bd e0 00 00 00 	mov    0xe0(%r13),%r15
   58d90:	49 8b 9d d0 01 00 00 	mov    0x1d0(%r13),%rbx
   58d97:	48 81 fd ff 01 00 00 	cmp    $0x1ff,%rbp
   58d9e:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
   58da3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
   58da8:	77 2f                	ja     58dd9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x309>
   58daa:	41 0f b6 8b e8 00 00 	movzbl 0xe8(%r11),%ecx
   58db1:	00 
   58db2:	80 f9 02             	cmp    $0x2,%cl
   58db5:	74 22                	je     58dd9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x309>
   58db7:	49 8b 93 c8 00 00 00 	mov    0xc8(%r11),%rdx
   58dbe:	48 31 c2             	xor    %rax,%rdx
   58dc1:	4d 8b 83 c0 00 00 00 	mov    0xc0(%r11),%r8
   58dc8:	4d 31 c8             	xor    %r9,%r8
   58dcb:	49 09 d0             	or     %rdx,%r8
   58dce:	0f 94 c2             	sete   %dl
   58dd1:	84 ca                	test   %cl,%dl
   58dd3:	0f 85 97 00 00 00    	jne    58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x3a0>
   58dd9:	4d 85 f6             	test   %r14,%r14
   58ddc:	0f 94 c1             	sete   %cl
   58ddf:	48 39 d8             	cmp    %rbx,%rax
   58de2:	0f 97 c2             	seta   %dl
   58de5:	08 ca                	or     %cl,%dl
   58de7:	80 fa 01             	cmp    $0x1,%dl
   58dea:	0f 85 24 01 00 00    	jne    58f14 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x444>
   58df0:	4c 8d 9e b8 3e 00 00 	lea    0x3eb8(%rsi),%r11
   58df7:	31 c9                	xor    %ecx,%ecx
   58df9:	eb 1b                	jmp    58e16 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x346>
   58dfb:	48 81 c1 20 fe ff ff 	add    $0xfffffffffffffe20,%rcx
   58e02:	49 81 c3 e0 01 00 00 	add    $0x1e0,%r11
   58e09:	48 81 f9 00 20 fe ff 	cmp    $0xfffffffffffe2000,%rcx
   58e10:	0f 84 fe 00 00 00    	je     58f14 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x444>
   58e16:	41 0f b6 93 e8 00 00 	movzbl 0xe8(%r11),%edx
   58e1d:	00 
   58e1e:	80 fa 02             	cmp    $0x2,%dl
   58e21:	74 19                	je     58e3c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x36c>
   58e23:	49 39 83 c8 00 00 00 	cmp    %rax,0xc8(%r11)
   58e2a:	75 10                	jne    58e3c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x36c>
   58e2c:	4d 39 8b c0 00 00 00 	cmp    %r9,0xc0(%r11)
   58e33:	41 0f 94 c0          	sete   %r8b
   58e37:	41 84 d0             	test   %dl,%r8b
   58e3a:	75 34                	jne    58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x3a0>
   58e3c:	41 0f b6 93 d8 01 00 	movzbl 0x1d8(%r11),%edx
   58e43:	00 
   58e44:	80 fa 02             	cmp    $0x2,%dl
   58e47:	74 b2                	je     58dfb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x32b>
   58e49:	49 39 83 b8 01 00 00 	cmp    %rax,0x1b8(%r11)
   58e50:	75 a9                	jne    58dfb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x32b>
   58e52:	4d 39 8b b0 01 00 00 	cmp    %r9,0x1b0(%r11)
   58e59:	41 0f 94 c0          	sete   %r8b
   58e5d:	41 84 d0             	test   %dl,%r8b
   58e60:	74 99                	je     58dfb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x32b>
   58e62:	49 89 f3             	mov    %rsi,%r11
   58e65:	49 29 cb             	sub    %rcx,%r11
   58e68:	e9 10 fe ff ff       	jmp    58c7d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1ad>
   58e6d:	4d 89 c3             	mov    %r8,%r11
   58e70:	48 8b 8e 50 1f 02 00 	mov    0x21f50(%rsi),%rcx
   58e77:	f3 41 0f 6f 83 a0 00 	movdqu 0xa0(%r11),%xmm0
   58e7e:	00 00 
   58e80:	f3 41 0f 6f 8b b0 00 	movdqu 0xb0(%r11),%xmm1
   58e87:	00 00 
   58e89:	66 0f 7f 4c 24 60    	movdqa %xmm1,0x60(%rsp)
   58e8f:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
   58e95:	b0 05                	mov    $0x5,%al
   58e97:	48 83 f9 08          	cmp    $0x8,%rcx
   58e9b:	72 6b                	jb     58f08 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x438>
   58e9d:	49 8d b3 d8 00 00 00 	lea    0xd8(%r11),%rsi
   58ea4:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   58eab:	00 
   58eac:	48 89 fb             	mov    %rdi,%rbx
   58eaf:	48 89 c7             	mov    %rax,%rdi
   58eb2:	4d 89 de             	mov    %r11,%r14
   58eb5:	ff 15 25 c5 06 00    	call   *0x6c525(%rip)        # c53e0 <_DYNAMIC+0x2a0>
   58ebb:	48 89 df             	mov    %rbx,%rdi
   58ebe:	f3 0f 6f 84 24 20 01 	movdqu 0x120(%rsp),%xmm0
   58ec5:	00 00 
   58ec7:	f3 0f 6f 8c 24 30 01 	movdqu 0x130(%rsp),%xmm1
   58ece:	00 00 
   58ed0:	66 0f 74 4c 24 60    	pcmpeqb 0x60(%rsp),%xmm1
   58ed6:	66 0f 74 44 24 50    	pcmpeqb 0x50(%rsp),%xmm0
   58edc:	66 0f db c1          	pand   %xmm1,%xmm0
   58ee0:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   58ee4:	b0 0d                	mov    $0xd,%al
   58ee6:	81 f9 ff ff 00 00    	cmp    $0xffff,%ecx
   58eec:	75 1a                	jne    58f08 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x438>
   58eee:	4c 89 f2             	mov    %r14,%rdx
   58ef1:	49 83 be e0 00 00 00 	cmpq   $0x8,0xe0(%r14)
   58ef8:	08 
   58ef9:	75 0d                	jne    58f08 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x438>
   58efb:	48 89 57 08          	mov    %rdx,0x8(%rdi)
   58eff:	31 c0                	xor    %eax,%eax
   58f01:	88 07                	mov    %al,(%rdi)
   58f03:	e9 44 fc ff ff       	jmp    58b4c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58f08:	88 47 01             	mov    %al,0x1(%rdi)
   58f0b:	b0 01                	mov    $0x1,%al
   58f0d:	88 07                	mov    %al,(%rdi)
   58f0f:	e9 38 fc ff ff       	jmp    58b4c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58f14:	49 8d 75 18          	lea    0x18(%r13),%rsi
   58f18:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   58f1d:	ba c8 00 00 00       	mov    $0xc8,%edx
   58f22:	ff 15 a8 c4 06 00    	call   *0x6c4a8(%rip)        # c53d0 <memcpy@GLIBC_2.14>
   58f28:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   58f2d:	49 83 fc 01          	cmp    $0x1,%r12
   58f31:	75 09                	jne    58f3c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x46c>
   58f33:	49 39 c7             	cmp    %rax,%r15
   58f36:	0f 84 88 fd ff ff    	je     58cc4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1f4>
   58f3c:	48 39 d8             	cmp    %rbx,%rax
   58f3f:	0f 87 d1 fd ff ff    	ja     58d16 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x246>
   58f45:	41 f6 c6 01          	test   $0x1,%r14b
   58f49:	48 8b 3c 24          	mov    (%rsp),%rdi
   58f4d:	e9 f5 fb ff ff       	jmp    58b47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
