
/tmp/penelope-pre-pr-legacy-comparison/binaries/after/timeline_operations:     file format elf64-x86-64


Disassembly of section .text:

0000000000058c80 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input>:
   58c80:	55                   	push   %rbp
   58c81:	41 57                	push   %r15
   58c83:	41 56                	push   %r14
   58c85:	41 55                	push   %r13
   58c87:	41 54                	push   %r12
   58c89:	53                   	push   %rbx
   58c8a:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
   58c91:	48 8b ae 38 1f 02 00 	mov    0x21f38(%rsi),%rbp
   58c98:	48 39 e9             	cmp    %rbp,%rcx
   58c9b:	76 5a                	jbe    58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58c9d:	4c 8b 1e             	mov    (%rsi),%r11
   58ca0:	4c 8b a6 c8 01 00 00 	mov    0x1c8(%rsi),%r12
   58ca7:	49 83 fb 02          	cmp    $0x2,%r11
   58cab:	0f 95 c0             	setne  %al
   58cae:	4c 8d 8e e8 01 00 00 	lea    0x1e8(%rsi),%r9
   58cb5:	4c 8b be e8 01 00 00 	mov    0x1e8(%rsi),%r15
   58cbc:	4c 8b 96 b0 03 00 00 	mov    0x3b0(%rsi),%r10
   58cc3:	49 39 d4             	cmp    %rdx,%r12
   58cc6:	41 0f 94 c0          	sete   %r8b
   58cca:	4c 89 db             	mov    %r11,%rbx
   58ccd:	49 89 f5             	mov    %rsi,%r13
   58cd0:	44 84 c0             	test   %r8b,%al
   58cd3:	75 19                	jne    58cee <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x6e>
   58cd5:	49 83 ff 02          	cmp    $0x2,%r15
   58cd9:	0f 95 c0             	setne  %al
   58cdc:	49 39 d2             	cmp    %rdx,%r10
   58cdf:	41 0f 94 c0          	sete   %r8b
   58ce3:	4c 89 fb             	mov    %r15,%rbx
   58ce6:	4d 89 cd             	mov    %r9,%r13
   58ce9:	44 84 c0             	test   %r8b,%al
   58cec:	74 09                	je     58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58cee:	49 3b 8d d8 01 00 00 	cmp    0x1d8(%r13),%rcx
   58cf5:	76 17                	jbe    58d0e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x8e>
   58cf7:	66 c7 07 01 03       	movw   $0x301,(%rdi)
   58cfc:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
   58d03:	5b                   	pop    %rbx
   58d04:	41 5c                	pop    %r12
   58d06:	41 5d                	pop    %r13
   58d08:	41 5e                	pop    %r14
   58d0a:	41 5f                	pop    %r15
   58d0c:	5d                   	pop    %rbp
   58d0d:	c3                   	ret
   58d0e:	49 89 ee             	mov    %rbp,%r14
   58d11:	49 f7 d6             	not    %r14
   58d14:	49 01 ce             	add    %rcx,%r14
   58d17:	49 69 c6 f0 00 00 00 	imul   $0xf0,%r14,%rax
   58d1e:	4c 8d 04 06          	lea    (%rsi,%rax,1),%r8
   58d22:	49 81 c0 b8 3e 00 00 	add    $0x3eb8,%r8
   58d29:	49 8b 45 08          	mov    0x8(%r13),%rax
   58d2d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   58d32:	49 8b 45 10          	mov    0x10(%r13),%rax
   58d36:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   58d3b:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
   58d42:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   58d47:	49 8b 85 d0 01 00 00 	mov    0x1d0(%r13),%rax
   58d4e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   58d53:	49 81 fe ff 01 00 00 	cmp    $0x1ff,%r14
   58d5a:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   58d5f:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
   58d64:	77 36                	ja     58d9c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x11c>
   58d66:	41 0f b6 80 e8 00 00 	movzbl 0xe8(%r8),%eax
   58d6d:	00 
   58d6e:	3c 02                	cmp    $0x2,%al
   58d70:	74 2a                	je     58d9c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x11c>
   58d72:	4d 89 c2             	mov    %r8,%r10
   58d75:	4d 8b 80 c8 00 00 00 	mov    0xc8(%r8),%r8
   58d7c:	49 31 c8             	xor    %rcx,%r8
   58d7f:	4d 8b 8a c0 00 00 00 	mov    0xc0(%r10),%r9
   58d86:	49 31 d1             	xor    %rdx,%r9
   58d89:	4d 09 c1             	or     %r8,%r9
   58d8c:	41 0f 94 c0          	sete   %r8b
   58d90:	41 84 c0             	test   %al,%r8b
   58d93:	4d 89 d0             	mov    %r10,%r8
   58d96:	0f 85 08 01 00 00    	jne    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   58d9c:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
   58da1:	8d 41 ff             	lea    -0x1(%rcx),%eax
   58da4:	25 ff 01 00 00       	and    $0x1ff,%eax
   58da9:	48 69 c0 f0 00 00 00 	imul   $0xf0,%rax,%rax
   58db0:	4c 8d 0c 06          	lea    (%rsi,%rax,1),%r9
   58db4:	49 81 c1 b8 3e 00 00 	add    $0x3eb8,%r9
   58dbb:	48 85 ed             	test   %rbp,%rbp
   58dbe:	74 3a                	je     58dfa <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x17a>
   58dc0:	41 0f b6 81 e8 00 00 	movzbl 0xe8(%r9),%eax
   58dc7:	00 
   58dc8:	3c 02                	cmp    $0x2,%al
   58dca:	74 2e                	je     58dfa <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x17a>
   58dcc:	4d 8b 81 c8 00 00 00 	mov    0xc8(%r9),%r8
   58dd3:	49 31 c8             	xor    %rcx,%r8
   58dd6:	4d 89 ca             	mov    %r9,%r10
   58dd9:	4d 8b 89 c0 00 00 00 	mov    0xc0(%r9),%r9
   58de0:	49 31 d1             	xor    %rdx,%r9
   58de3:	4d 09 c1             	or     %r8,%r9
   58de6:	4d 89 d1             	mov    %r10,%r9
   58de9:	41 0f 94 c0          	sete   %r8b
   58ded:	41 84 c0             	test   %al,%r8b
   58df0:	74 08                	je     58dfa <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x17a>
   58df2:	4d 89 c8             	mov    %r9,%r8
   58df5:	e9 aa 00 00 00       	jmp    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   58dfa:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   58dff:	48 85 db             	test   %rbx,%rbx
   58e02:	0f 94 c0             	sete   %al
   58e05:	48 3b 4c 24 28       	cmp    0x28(%rsp),%rcx
   58e0a:	41 0f 97 c0          	seta   %r8b
   58e0e:	41 08 c0             	or     %al,%r8b
   58e11:	41 80 f8 01          	cmp    $0x1,%r8b
   58e15:	0f 85 2d 01 00 00    	jne    58f48 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2c8>
   58e1b:	4c 8d 86 b8 3e 00 00 	lea    0x3eb8(%rsi),%r8
   58e22:	31 c0                	xor    %eax,%eax
   58e24:	eb 23                	jmp    58e49 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1c9>
   58e26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   58e2d:	00 00 00 
   58e30:	48 05 20 fe ff ff    	add    $0xfffffffffffffe20,%rax
   58e36:	49 81 c0 e0 01 00 00 	add    $0x1e0,%r8
   58e3d:	48 3d 00 20 fe ff    	cmp    $0xfffffffffffe2000,%rax
   58e43:	0f 84 ff 00 00 00    	je     58f48 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2c8>
   58e49:	45 0f b6 88 e8 00 00 	movzbl 0xe8(%r8),%r9d
   58e50:	00 
   58e51:	41 80 f9 02          	cmp    $0x2,%r9b
   58e55:	74 19                	je     58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1f0>
   58e57:	49 39 88 c8 00 00 00 	cmp    %rcx,0xc8(%r8)
   58e5e:	75 10                	jne    58e70 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1f0>
   58e60:	49 39 90 c0 00 00 00 	cmp    %rdx,0xc0(%r8)
   58e67:	41 0f 94 c2          	sete   %r10b
   58e6b:	45 84 ca             	test   %r9b,%r10b
   58e6e:	75 34                	jne    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   58e70:	45 0f b6 88 d8 01 00 	movzbl 0x1d8(%r8),%r9d
   58e77:	00 
   58e78:	41 80 f9 02          	cmp    $0x2,%r9b
   58e7c:	74 b2                	je     58e30 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b0>
   58e7e:	49 39 88 b8 01 00 00 	cmp    %rcx,0x1b8(%r8)
   58e85:	75 a9                	jne    58e30 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b0>
   58e87:	49 39 90 b0 01 00 00 	cmp    %rdx,0x1b0(%r8)
   58e8e:	41 0f 94 c2          	sete   %r10b
   58e92:	45 84 ca             	test   %r9b,%r10b
   58e95:	74 99                	je     58e30 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b0>
   58e97:	49 89 f0             	mov    %rsi,%r8
   58e9a:	49 29 c0             	sub    %rax,%r8
   58e9d:	49 81 c0 a8 3f 00 00 	add    $0x3fa8,%r8
   58ea4:	48 8b 8e 50 1f 02 00 	mov    0x21f50(%rsi),%rcx
   58eab:	f3 41 0f 6f 80 a0 00 	movdqu 0xa0(%r8),%xmm0
   58eb2:	00 00 
   58eb4:	f3 41 0f 6f 88 b0 00 	movdqu 0xb0(%r8),%xmm1
   58ebb:	00 00 
   58ebd:	66 0f 7f 4c 24 70    	movdqa %xmm1,0x70(%rsp)
   58ec3:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   58ec9:	b0 05                	mov    $0x5,%al
   58ecb:	48 83 f9 08          	cmp    $0x8,%rcx
   58ecf:	0f 82 f9 00 00 00    	jb     58fce <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x34e>
   58ed5:	49 8d b0 d8 00 00 00 	lea    0xd8(%r8),%rsi
   58edc:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   58ee3:	00 
   58ee4:	48 89 fb             	mov    %rdi,%rbx
   58ee7:	48 89 c7             	mov    %rax,%rdi
   58eea:	4d 89 c6             	mov    %r8,%r14
   58eed:	ff 15 ed c8 06 00    	call   *0x6c8ed(%rip)        # c57e0 <_DYNAMIC+0x2a0>
   58ef3:	48 89 df             	mov    %rbx,%rdi
   58ef6:	f3 0f 6f 84 24 30 01 	movdqu 0x130(%rsp),%xmm0
   58efd:	00 00 
   58eff:	f3 0f 6f 8c 24 40 01 	movdqu 0x140(%rsp),%xmm1
   58f06:	00 00 
   58f08:	66 0f 74 4c 24 70    	pcmpeqb 0x70(%rsp),%xmm1
   58f0e:	66 0f 74 44 24 60    	pcmpeqb 0x60(%rsp),%xmm0
   58f14:	66 0f db c1          	pand   %xmm1,%xmm0
   58f18:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   58f1c:	b0 0d                	mov    $0xd,%al
   58f1e:	81 f9 ff ff 00 00    	cmp    $0xffff,%ecx
   58f24:	0f 85 a4 00 00 00    	jne    58fce <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x34e>
   58f2a:	4c 89 f2             	mov    %r14,%rdx
   58f2d:	49 83 be e0 00 00 00 	cmpq   $0x8,0xe0(%r14)
   58f34:	08 
   58f35:	0f 85 93 00 00 00    	jne    58fce <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x34e>
   58f3b:	48 89 57 08          	mov    %rdx,0x8(%rdi)
   58f3f:	31 c0                	xor    %eax,%eax
   58f41:	88 07                	mov    %al,(%rdi)
   58f43:	e9 b4 fd ff ff       	jmp    58cfc <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58f48:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
   58f4d:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   58f52:	48 89 3c 24          	mov    %rdi,(%rsp)
   58f56:	49 8d 75 18          	lea    0x18(%r13),%rsi
   58f5a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   58f5f:	ba c8 00 00 00       	mov    $0xc8,%edx
   58f64:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   58f69:	ff 15 61 c8 06 00    	call   *0x6c861(%rip)        # c57d0 <memcpy@GLIBC_2.14>
   58f6f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   58f74:	48 83 7c 24 58 01    	cmpq   $0x1,0x58(%rsp)
   58f7a:	75 5e                	jne    58fda <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x35a>
   58f7c:	48 39 44 24 50       	cmp    %rax,0x50(%rsp)
   58f81:	75 57                	jne    58fda <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x35a>
   58f83:	49 8b 9d e8 00 00 00 	mov    0xe8(%r13),%rbx
   58f8a:	4c 8d bc 24 30 01 00 	lea    0x130(%rsp),%r15
   58f91:	00 
   58f92:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   58f97:	ba c8 00 00 00       	mov    $0xc8,%edx
   58f9c:	4c 89 ff             	mov    %r15,%rdi
   58f9f:	49 89 c6             	mov    %rax,%r14
   58fa2:	ff 15 28 c8 06 00    	call   *0x6c828(%rip)        # c57d0 <memcpy@GLIBC_2.14>
   58fa8:	4c 89 b4 24 f8 01 00 	mov    %r14,0x1f8(%rsp)
   58faf:	00 
   58fb0:	48 89 9c 24 00 02 00 	mov    %rbx,0x200(%rsp)
   58fb7:	00 
   58fb8:	48 8b 3c 24          	mov    (%rsp),%rdi
   58fbc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   58fc1:	4c 89 fa             	mov    %r15,%rdx
   58fc4:	e8 97 ec ff ff       	call   57c60 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::exact_input>
   58fc9:	e9 2e fd ff ff       	jmp    58cfc <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58fce:	88 47 01             	mov    %al,0x1(%rdi)
   58fd1:	b0 01                	mov    $0x1,%al
   58fd3:	88 07                	mov    %al,(%rdi)
   58fd5:	e9 22 fd ff ff       	jmp    58cfc <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58fda:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
   58fdf:	76 0e                	jbe    58fef <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x36f>
   58fe1:	48 8b 04 24          	mov    (%rsp),%rax
   58fe5:	66 c7 00 01 03       	movw   $0x301,(%rax)
   58fea:	e9 0d fd ff ff       	jmp    58cfc <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x7c>
   58fef:	48 83 fb 01          	cmp    $0x1,%rbx
   58ff3:	48 8b 3c 24          	mov    (%rsp),%rdi
   58ff7:	0f 85 fa fc ff ff    	jne    58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   58ffd:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   59002:	41 83 f9 02          	cmp    $0x2,%r9d
   59006:	0f 95 c1             	setne  %cl
   59009:	4c 8b 5c 24 48       	mov    0x48(%rsp),%r11
   5900e:	4d 39 dc             	cmp    %r11,%r12
   59011:	0f 94 c2             	sete   %dl
   59014:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   59019:	49 89 f5             	mov    %rsi,%r13
   5901c:	84 d1                	test   %dl,%cl
   5901e:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
   59023:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   59028:	75 1e                	jne    59048 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x3c8>
   5902a:	49 83 ff 02          	cmp    $0x2,%r15
   5902e:	0f 95 c1             	setne  %cl
   59031:	4c 39 da             	cmp    %r11,%rdx
   59034:	0f 94 c2             	sete   %dl
   59037:	20 ca                	and    %cl,%dl
   59039:	4d 89 f9             	mov    %r15,%r9
   5903c:	4d 89 c5             	mov    %r8,%r13
   5903f:	80 fa 01             	cmp    $0x1,%dl
   59042:	0f 85 af fc ff ff    	jne    58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   59048:	49 3b 85 d8 01 00 00 	cmp    0x1d8(%r13),%rax
   5904f:	0f 87 a2 fc ff ff    	ja     58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
   59055:	4d 8b 65 10          	mov    0x10(%r13),%r12
   59059:	4d 8b bd e0 00 00 00 	mov    0xe0(%r13),%r15
   59060:	49 8b 9d d0 01 00 00 	mov    0x1d0(%r13),%rbx
   59067:	49 81 fe ff 01 00 00 	cmp    $0x1ff,%r14
   5906e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   59073:	77 38                	ja     590ad <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x42d>
   59075:	0f b6 8a e8 00 00 00 	movzbl 0xe8(%rdx),%ecx
   5907c:	80 f9 02             	cmp    $0x2,%cl
   5907f:	74 2c                	je     590ad <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x42d>
   59081:	48 8b 92 c8 00 00 00 	mov    0xc8(%rdx),%rdx
   59088:	48 31 c2             	xor    %rax,%rdx
   5908b:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   59090:	4d 8b 80 c0 00 00 00 	mov    0xc0(%r8),%r8
   59097:	4d 31 d8             	xor    %r11,%r8
   5909a:	49 09 d0             	or     %rdx,%r8
   5909d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   590a2:	0f 94 c2             	sete   %dl
   590a5:	84 ca                	test   %cl,%dl
   590a7:	0f 85 f7 fd ff ff    	jne    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   590ad:	48 85 ed             	test   %rbp,%rbp
   590b0:	74 3b                	je     590ed <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x46d>
   590b2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   590b7:	0f b6 89 e8 00 00 00 	movzbl 0xe8(%rcx),%ecx
   590be:	80 f9 02             	cmp    $0x2,%cl
   590c1:	74 2a                	je     590ed <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x46d>
   590c3:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
   590c8:	49 8b 92 c8 00 00 00 	mov    0xc8(%r10),%rdx
   590cf:	48 31 c2             	xor    %rax,%rdx
   590d2:	4d 8b 82 c0 00 00 00 	mov    0xc0(%r10),%r8
   590d9:	4d 31 d8             	xor    %r11,%r8
   590dc:	49 09 d0             	or     %rdx,%r8
   590df:	0f 94 c2             	sete   %dl
   590e2:	4d 89 d0             	mov    %r10,%r8
   590e5:	84 ca                	test   %cl,%dl
   590e7:	0f 85 b7 fd ff ff    	jne    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   590ed:	4d 85 c9             	test   %r9,%r9
   590f0:	0f 94 c1             	sete   %cl
   590f3:	48 39 d8             	cmp    %rbx,%rax
   590f6:	0f 97 c2             	seta   %dl
   590f9:	08 ca                	or     %cl,%dl
   590fb:	80 fa 01             	cmp    $0x1,%dl
   590fe:	0f 85 89 00 00 00    	jne    5918d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x50d>
   59104:	4c 8d 86 b8 3e 00 00 	lea    0x3eb8(%rsi),%r8
   5910b:	31 c9                	xor    %ecx,%ecx
   5910d:	eb 17                	jmp    59126 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x4a6>
   5910f:	48 81 c1 20 fe ff ff 	add    $0xfffffffffffffe20,%rcx
   59116:	49 81 c0 e0 01 00 00 	add    $0x1e0,%r8
   5911d:	48 81 f9 00 20 fe ff 	cmp    $0xfffffffffffe2000,%rcx
   59124:	74 67                	je     5918d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x50d>
   59126:	41 0f b6 90 e8 00 00 	movzbl 0xe8(%r8),%edx
   5912d:	00 
   5912e:	80 fa 02             	cmp    $0x2,%dl
   59131:	74 23                	je     59156 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x4d6>
   59133:	49 39 80 c8 00 00 00 	cmp    %rax,0xc8(%r8)
   5913a:	75 1a                	jne    59156 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x4d6>
   5913c:	4d 39 98 c0 00 00 00 	cmp    %r11,0xc0(%r8)
   59143:	4d 89 c2             	mov    %r8,%r10
   59146:	41 0f 94 c0          	sete   %r8b
   5914a:	41 84 d0             	test   %dl,%r8b
   5914d:	4d 89 d0             	mov    %r10,%r8
   59150:	0f 85 4e fd ff ff    	jne    58ea4 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x224>
   59156:	41 0f b6 90 d8 01 00 	movzbl 0x1d8(%r8),%edx
   5915d:	00 
   5915e:	80 fa 02             	cmp    $0x2,%dl
   59161:	74 ac                	je     5910f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x48f>
   59163:	49 39 80 b8 01 00 00 	cmp    %rax,0x1b8(%r8)
   5916a:	75 a3                	jne    5910f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x48f>
   5916c:	4d 39 98 b0 01 00 00 	cmp    %r11,0x1b0(%r8)
   59173:	4d 89 c2             	mov    %r8,%r10
   59176:	41 0f 94 c0          	sete   %r8b
   5917a:	41 84 d0             	test   %dl,%r8b
   5917d:	4d 89 d0             	mov    %r10,%r8
   59180:	74 8d                	je     5910f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x48f>
   59182:	49 89 f0             	mov    %rsi,%r8
   59185:	49 29 c8             	sub    %rcx,%r8
   59188:	e9 10 fd ff ff       	jmp    58e9d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x21d>
   5918d:	4d 89 ce             	mov    %r9,%r14
   59190:	49 8d 75 18          	lea    0x18(%r13),%rsi
   59194:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   59199:	ba c8 00 00 00       	mov    $0xc8,%edx
   5919e:	ff 15 2c c6 06 00    	call   *0x6c62c(%rip)        # c57d0 <memcpy@GLIBC_2.14>
   591a4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   591a9:	49 83 fc 01          	cmp    $0x1,%r12
   591ad:	75 09                	jne    591b8 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x538>
   591af:	49 39 c7             	cmp    %rax,%r15
   591b2:	0f 84 cb fd ff ff    	je     58f83 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x303>
   591b8:	48 39 d8             	cmp    %rbx,%rax
   591bb:	0f 87 20 fe ff ff    	ja     58fe1 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x361>
   591c1:	41 f6 c6 01          	test   $0x1,%r14b
   591c5:	48 8b 3c 24          	mov    (%rsp),%rdi
   591c9:	e9 29 fb ff ff       	jmp    58cf7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x77>
