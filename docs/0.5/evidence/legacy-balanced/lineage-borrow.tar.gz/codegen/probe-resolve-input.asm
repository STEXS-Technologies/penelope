
/home/ac/projects/penelope/target/pre-pr-lineage-borrow/release/build/penelope-timeline/04c22339e62283d7/out/timeline_operations-04c22339e62283d7:     file format elf64-x86-64


Disassembly of section .text:

0000000000058cb0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input>:
   58cb0:	55                   	push   %rbp
   58cb1:	41 57                	push   %r15
   58cb3:	41 56                	push   %r14
   58cb5:	41 55                	push   %r13
   58cb7:	41 54                	push   %r12
   58cb9:	53                   	push   %rbx
   58cba:	48 83 ec 68          	sub    $0x68,%rsp
   58cbe:	4c 8b 86 38 1f 02 00 	mov    0x21f38(%rsi),%r8
   58cc5:	4c 39 c1             	cmp    %r8,%rcx
   58cc8:	76 59                	jbe    58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58cca:	48 89 d0             	mov    %rdx,%rax
   58ccd:	4c 8b 26             	mov    (%rsi),%r12
   58cd0:	4c 8b be c8 01 00 00 	mov    0x1c8(%rsi),%r15
   58cd7:	49 83 fc 02          	cmp    $0x2,%r12
   58cdb:	41 0f 95 c1          	setne  %r9b
   58cdf:	4c 8d 96 e8 01 00 00 	lea    0x1e8(%rsi),%r10
   58ce6:	4c 8b b6 e8 01 00 00 	mov    0x1e8(%rsi),%r14
   58ced:	48 8b 9e b0 03 00 00 	mov    0x3b0(%rsi),%rbx
   58cf4:	49 39 d7             	cmp    %rdx,%r15
   58cf7:	41 0f 94 c3          	sete   %r11b
   58cfb:	48 89 f2             	mov    %rsi,%rdx
   58cfe:	45 84 d9             	test   %r11b,%r9b
   58d01:	75 17                	jne    58d1a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x6a>
   58d03:	41 83 fe 02          	cmp    $0x2,%r14d
   58d07:	41 0f 95 c1          	setne  %r9b
   58d0b:	48 39 c3             	cmp    %rax,%rbx
   58d0e:	41 0f 94 c3          	sete   %r11b
   58d12:	4c 89 d2             	mov    %r10,%rdx
   58d15:	45 84 d9             	test   %r11b,%r9b
   58d18:	74 09                	je     58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58d1a:	48 3b 8a d8 01 00 00 	cmp    0x1d8(%rdx),%rcx
   58d21:	76 14                	jbe    58d37 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x87>
   58d23:	66 c7 07 01 03       	movw   $0x301,(%rdi)
   58d28:	48 83 c4 68          	add    $0x68,%rsp
   58d2c:	5b                   	pop    %rbx
   58d2d:	41 5c                	pop    %r12
   58d2f:	41 5d                	pop    %r13
   58d31:	41 5e                	pop    %r14
   58d33:	41 5f                	pop    %r15
   58d35:	5d                   	pop    %rbp
   58d36:	c3                   	ret
   58d37:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   58d3c:	4d 89 c5             	mov    %r8,%r13
   58d3f:	49 f7 d5             	not    %r13
   58d42:	49 01 cd             	add    %rcx,%r13
   58d45:	4d 69 cd f0 00 00 00 	imul   $0xf0,%r13,%r9
   58d4c:	4a 8d 2c 0e          	lea    (%rsi,%r9,1),%rbp
   58d50:	48 81 c5 b8 3e 00 00 	add    $0x3eb8,%rbp
   58d57:	49 81 fd ff 01 00 00 	cmp    $0x1ff,%r13
   58d5e:	77 32                	ja     58d92 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0xe2>
   58d60:	44 0f b6 8d e8 00 00 	movzbl 0xe8(%rbp),%r9d
   58d67:	00 
   58d68:	41 80 f9 02          	cmp    $0x2,%r9b
   58d6c:	74 24                	je     58d92 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0xe2>
   58d6e:	4c 8b 9d c8 00 00 00 	mov    0xc8(%rbp),%r11
   58d75:	49 31 cb             	xor    %rcx,%r11
   58d78:	48 8b 9d c0 00 00 00 	mov    0xc0(%rbp),%rbx
   58d7f:	48 31 c3             	xor    %rax,%rbx
   58d82:	4c 09 db             	or     %r11,%rbx
   58d85:	41 0f 94 c3          	sete   %r11b
   58d89:	45 84 cb             	test   %r9b,%r11b
   58d8c:	0f 85 a6 02 00 00    	jne    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   58d92:	44 8d 49 ff          	lea    -0x1(%rcx),%r9d
   58d96:	41 81 e1 ff 01 00 00 	and    $0x1ff,%r9d
   58d9d:	4d 69 c9 f0 00 00 00 	imul   $0xf0,%r9,%r9
   58da4:	4e 8d 14 0e          	lea    (%rsi,%r9,1),%r10
   58da8:	49 81 c2 b8 3e 00 00 	add    $0x3eb8,%r10
   58daf:	4d 85 c0             	test   %r8,%r8
   58db2:	74 36                	je     58dea <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x13a>
   58db4:	45 0f b6 8a e8 00 00 	movzbl 0xe8(%r10),%r9d
   58dbb:	00 
   58dbc:	41 80 f9 02          	cmp    $0x2,%r9b
   58dc0:	74 28                	je     58dea <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x13a>
   58dc2:	4d 8b 9a c8 00 00 00 	mov    0xc8(%r10),%r11
   58dc9:	49 31 cb             	xor    %rcx,%r11
   58dcc:	49 8b 9a c0 00 00 00 	mov    0xc0(%r10),%rbx
   58dd3:	48 31 c3             	xor    %rax,%rbx
   58dd6:	4c 09 db             	or     %r11,%rbx
   58dd9:	41 0f 94 c3          	sete   %r11b
   58ddd:	45 84 cb             	test   %r9b,%r11b
   58de0:	74 08                	je     58dea <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x13a>
   58de2:	4c 89 d5             	mov    %r10,%rbp
   58de5:	e9 4e 02 00 00       	jmp    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   58dea:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
   58def:	4c 8b 0a             	mov    (%rdx),%r9
   58df2:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
   58df7:	4d 85 c9             	test   %r9,%r9
   58dfa:	74 0d                	je     58e09 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x159>
   58dfc:	48 3b 8a d0 01 00 00 	cmp    0x1d0(%rdx),%rcx
   58e03:	0f 86 92 00 00 00    	jbe    58e9b <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1eb>
   58e09:	48 8d 9e b8 3e 00 00 	lea    0x3eb8(%rsi),%rbx
   58e10:	45 31 c9             	xor    %r9d,%r9d
   58e13:	eb 22                	jmp    58e37 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x187>
   58e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   58e1c:	00 00 00 00 
   58e20:	49 81 c1 20 fe ff ff 	add    $0xfffffffffffffe20,%r9
   58e27:	48 81 c3 e0 01 00 00 	add    $0x1e0,%rbx
   58e2e:	49 81 f9 00 20 fe ff 	cmp    $0xfffffffffffe2000,%r9
   58e35:	74 64                	je     58e9b <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1eb>
   58e37:	44 0f b6 9b e8 00 00 	movzbl 0xe8(%rbx),%r11d
   58e3e:	00 
   58e3f:	41 80 fb 02          	cmp    $0x2,%r11b
   58e43:	74 1d                	je     58e62 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b2>
   58e45:	48 39 8b c8 00 00 00 	cmp    %rcx,0xc8(%rbx)
   58e4c:	75 14                	jne    58e62 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1b2>
   58e4e:	48 39 83 c0 00 00 00 	cmp    %rax,0xc0(%rbx)
   58e55:	41 0f 94 c2          	sete   %r10b
   58e59:	45 84 da             	test   %r11b,%r10b
   58e5c:	0f 85 d3 01 00 00    	jne    59035 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x385>
   58e62:	44 0f b6 9b d8 01 00 	movzbl 0x1d8(%rbx),%r11d
   58e69:	00 
   58e6a:	41 80 fb 02          	cmp    $0x2,%r11b
   58e6e:	74 b0                	je     58e20 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x170>
   58e70:	48 39 8b b8 01 00 00 	cmp    %rcx,0x1b8(%rbx)
   58e77:	75 a7                	jne    58e20 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x170>
   58e79:	48 39 83 b0 01 00 00 	cmp    %rax,0x1b0(%rbx)
   58e80:	41 0f 94 c2          	sete   %r10b
   58e84:	45 84 da             	test   %r11b,%r10b
   58e87:	74 97                	je     58e20 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x170>
   58e89:	48 89 f5             	mov    %rsi,%rbp
   58e8c:	4c 29 cd             	sub    %r9,%rbp
   58e8f:	48 81 c5 a8 3f 00 00 	add    $0x3fa8,%rbp
   58e96:	e9 9d 01 00 00       	jmp    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   58e9b:	83 7a 10 01          	cmpl   $0x1,0x10(%rdx)
   58e9f:	75 20                	jne    58ec1 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x211>
   58ea1:	48 39 8a e0 00 00 00 	cmp    %rcx,0xe0(%rdx)
   58ea8:	75 17                	jne    58ec1 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x211>
   58eaa:	48 83 c2 18          	add    $0x18,%rdx
   58eae:	48 83 c4 68          	add    $0x68,%rsp
   58eb2:	5b                   	pop    %rbx
   58eb3:	41 5c                	pop    %r12
   58eb5:	41 5d                	pop    %r13
   58eb7:	41 5e                	pop    %r14
   58eb9:	41 5f                	pop    %r15
   58ebb:	5d                   	pop    %rbp
   58ebc:	e9 cf ed ff ff       	jmp    57c90 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::exact_input>
   58ec1:	48 3b 8a d0 01 00 00 	cmp    0x1d0(%rdx),%rcx
   58ec8:	0f 87 55 fe ff ff    	ja     58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58ece:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   58ed4:	0f 84 49 fe ff ff    	je     58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58eda:	41 83 fc 02          	cmp    $0x2,%r12d
   58ede:	41 0f 95 c1          	setne  %r9b
   58ee2:	48 8b 42 08          	mov    0x8(%rdx),%rax
   58ee6:	49 39 c7             	cmp    %rax,%r15
   58ee9:	41 0f 94 c2          	sete   %r10b
   58eed:	48 89 f2             	mov    %rsi,%rdx
   58ef0:	45 84 d1             	test   %r10b,%r9b
   58ef3:	4c 8d 96 e8 01 00 00 	lea    0x1e8(%rsi),%r10
   58efa:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
   58eff:	75 1e                	jne    58f1f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x26f>
   58f01:	41 83 fe 02          	cmp    $0x2,%r14d
   58f05:	0f 95 c2             	setne  %dl
   58f08:	49 39 c1             	cmp    %rax,%r9
   58f0b:	41 0f 94 c1          	sete   %r9b
   58f0f:	41 20 d1             	and    %dl,%r9b
   58f12:	4c 89 d2             	mov    %r10,%rdx
   58f15:	41 80 f9 01          	cmp    $0x1,%r9b
   58f19:	0f 85 04 fe ff ff    	jne    58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58f1f:	48 3b 8a d8 01 00 00 	cmp    0x1d8(%rdx),%rcx
   58f26:	0f 87 f7 fd ff ff    	ja     58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   58f2c:	49 81 fd ff 01 00 00 	cmp    $0x1ff,%r13
   58f33:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   58f38:	77 32                	ja     58f6c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2bc>
   58f3a:	44 0f b6 8d e8 00 00 	movzbl 0xe8(%rbp),%r9d
   58f41:	00 
   58f42:	41 80 f9 02          	cmp    $0x2,%r9b
   58f46:	74 24                	je     58f6c <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2bc>
   58f48:	4c 8b 95 c8 00 00 00 	mov    0xc8(%rbp),%r10
   58f4f:	49 31 ca             	xor    %rcx,%r10
   58f52:	4c 8b 9d c0 00 00 00 	mov    0xc0(%rbp),%r11
   58f59:	49 31 c3             	xor    %rax,%r11
   58f5c:	4d 09 d3             	or     %r10,%r11
   58f5f:	41 0f 94 c2          	sete   %r10b
   58f63:	45 84 ca             	test   %r9b,%r10b
   58f66:	0f 85 cc 00 00 00    	jne    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   58f6c:	4d 85 c0             	test   %r8,%r8
   58f6f:	74 35                	je     58fa6 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2f6>
   58f71:	44 0f b6 83 e8 00 00 	movzbl 0xe8(%rbx),%r8d
   58f78:	00 
   58f79:	41 80 f8 02          	cmp    $0x2,%r8b
   58f7d:	74 27                	je     58fa6 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x2f6>
   58f7f:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
   58f86:	49 31 c9             	xor    %rcx,%r9
   58f89:	4c 8b 93 c0 00 00 00 	mov    0xc0(%rbx),%r10
   58f90:	49 31 c2             	xor    %rax,%r10
   58f93:	4d 09 ca             	or     %r9,%r10
   58f96:	41 0f 94 c1          	sete   %r9b
   58f9a:	48 89 dd             	mov    %rbx,%rbp
   58f9d:	45 84 c1             	test   %r8b,%r9b
   58fa0:	0f 85 92 00 00 00    	jne    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   58fa6:	4c 8b 02             	mov    (%rdx),%r8
   58fa9:	4d 85 c0             	test   %r8,%r8
   58fac:	74 0d                	je     58fbb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x30b>
   58fae:	48 3b 8a d0 01 00 00 	cmp    0x1d0(%rdx),%rcx
   58fb5:	0f 86 10 01 00 00    	jbe    590cb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x41b>
   58fbb:	48 8d ae b8 3e 00 00 	lea    0x3eb8(%rsi),%rbp
   58fc2:	45 31 c9             	xor    %r9d,%r9d
   58fc5:	eb 1b                	jmp    58fe2 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x332>
   58fc7:	49 81 c1 20 fe ff ff 	add    $0xfffffffffffffe20,%r9
   58fce:	48 81 c5 e0 01 00 00 	add    $0x1e0,%rbp
   58fd5:	49 81 f9 00 20 fe ff 	cmp    $0xfffffffffffe2000,%r9
   58fdc:	0f 84 e9 00 00 00    	je     590cb <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x41b>
   58fe2:	44 0f b6 95 e8 00 00 	movzbl 0xe8(%rbp),%r10d
   58fe9:	00 
   58fea:	41 80 fa 02          	cmp    $0x2,%r10b
   58fee:	74 19                	je     59009 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x359>
   58ff0:	48 39 8d c8 00 00 00 	cmp    %rcx,0xc8(%rbp)
   58ff7:	75 10                	jne    59009 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x359>
   58ff9:	48 39 85 c0 00 00 00 	cmp    %rax,0xc0(%rbp)
   59000:	41 0f 94 c3          	sete   %r11b
   59004:	45 84 d3             	test   %r10b,%r11b
   59007:	75 2f                	jne    59038 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x388>
   59009:	44 0f b6 95 d8 01 00 	movzbl 0x1d8(%rbp),%r10d
   59010:	00 
   59011:	41 80 fa 02          	cmp    $0x2,%r10b
   59015:	74 b0                	je     58fc7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x317>
   59017:	48 39 8d b8 01 00 00 	cmp    %rcx,0x1b8(%rbp)
   5901e:	75 a7                	jne    58fc7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x317>
   59020:	48 39 85 b0 01 00 00 	cmp    %rax,0x1b0(%rbp)
   59027:	41 0f 94 c3          	sete   %r11b
   5902b:	45 84 d3             	test   %r10b,%r11b
   5902e:	74 97                	je     58fc7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x317>
   59030:	e9 54 fe ff ff       	jmp    58e89 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1d9>
   59035:	48 89 dd             	mov    %rbx,%rbp
   59038:	48 8b 8e 50 1f 02 00 	mov    0x21f50(%rsi),%rcx
   5903f:	f3 0f 6f 85 a0 00 00 	movdqu 0xa0(%rbp),%xmm0
   59046:	00 
   59047:	f3 0f 6f 8d b0 00 00 	movdqu 0xb0(%rbp),%xmm1
   5904e:	00 
   5904f:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   59055:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   5905b:	b0 05                	mov    $0x5,%al
   5905d:	48 83 f9 08          	cmp    $0x8,%rcx
   59061:	72 5c                	jb     590bf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x40f>
   59063:	48 8d b5 d8 00 00 00 	lea    0xd8(%rbp),%rsi
   5906a:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   5906f:	48 89 fb             	mov    %rdi,%rbx
   59072:	48 89 c7             	mov    %rax,%rdi
   59075:	ff 15 c5 d5 06 00    	call   *0x6d5c5(%rip)        # c6640 <_DYNAMIC+0x2a0>
   5907b:	48 89 df             	mov    %rbx,%rdi
   5907e:	f3 0f 6f 44 24 48    	movdqu 0x48(%rsp),%xmm0
   59084:	f3 0f 6f 4c 24 58    	movdqu 0x58(%rsp),%xmm1
   5908a:	66 0f 74 4c 24 30    	pcmpeqb 0x30(%rsp),%xmm1
   59090:	66 0f 74 44 24 20    	pcmpeqb 0x20(%rsp),%xmm0
   59096:	66 0f db c1          	pand   %xmm1,%xmm0
   5909a:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   5909e:	b0 0d                	mov    $0xd,%al
   590a0:	81 f9 ff ff 00 00    	cmp    $0xffff,%ecx
   590a6:	75 17                	jne    590bf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x40f>
   590a8:	48 83 bd e0 00 00 00 	cmpq   $0x8,0xe0(%rbp)
   590af:	08 
   590b0:	75 0d                	jne    590bf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x40f>
   590b2:	48 89 6f 08          	mov    %rbp,0x8(%rdi)
   590b6:	31 c0                	xor    %eax,%eax
   590b8:	88 07                	mov    %al,(%rdi)
   590ba:	e9 69 fc ff ff       	jmp    58d28 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x78>
   590bf:	88 47 01             	mov    %al,0x1(%rdi)
   590c2:	b0 01                	mov    $0x1,%al
   590c4:	88 07                	mov    %al,(%rdi)
   590c6:	e9 5d fc ff ff       	jmp    58d28 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x78>
   590cb:	83 7a 10 01          	cmpl   $0x1,0x10(%rdx)
   590cf:	75 0d                	jne    590de <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x42e>
   590d1:	48 39 8a e0 00 00 00 	cmp    %rcx,0xe0(%rdx)
   590d8:	0f 84 cc fd ff ff    	je     58eaa <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x1fa>
   590de:	48 3b 8a d0 01 00 00 	cmp    0x1d0(%rdx),%rcx
   590e5:	0f 87 38 fc ff ff    	ja     58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
   590eb:	4d 85 c0             	test   %r8,%r8
   590ee:	e9 30 fc ff ff       	jmp    58d23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::resolve_input+0x73>
