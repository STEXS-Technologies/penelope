import collections,json,statistics
from fractions import Fraction
from pathlib import Path
raw=Path('/tmp/penelope-pre-pr-lineage-borrow-measure')
def parse(path):
 rows={}
 for line in path.read_text().splitlines():
  fields=line.split(',')
  if fields[0]!='latency':continue
  assert len(fields)==8 and fields[4]=='1000'
  for metric,value in zip(('p50_ns','p95_ns','p99_ns'),map(int,fields[5:])):
   rows[(fields[1],int(fields[2]),int(fields[3]),metric)]=value
 assert len(rows)==1920
 return rows
samples={label:[parse(raw/f'round-{i:02d}-{label}.stdout') for i in range(1,json.loads((raw/'metadata.json').read_text())['rounds']+1)] for label in ('original','candidate','probe')}
keys=samples['original'][0].keys()
assert all(row.keys()==keys for rows in samples.values() for row in rows)
rows=[]
for key in keys:
 values={label:[sample[key] for sample in group] for label,group in samples.items()}
 medians={label:statistics.median(v) for label,v in values.items()}
 threshold=5 if key[3]=='p50_ns' else 10 if key[3]=='p95_ns' else None
 deltas={label:(medians['probe']/medians[label]-1)*100 for label in ('original','candidate')}
 flags={label:threshold is not None and Fraction(str(medians['probe']))*100>Fraction(str(medians[label]))*(100+threshold) for label in deltas}
 rows.append({'operation':key[0],'state_words':key[1],'steps':key[2],'metric':key[3], 'samples':values,'medians':medians,'probe_delta_percent':deltas,'review_flags':flags,'paired_threshold_exceedances':{label:sum(a>b*(1+threshold/100) for a,b in zip(values['probe'],values[label])) if threshold else None for label in ('original','candidate')}})
result={'rounds':json.loads((raw/'metadata.json').read_text())['rounds'],'rows':rows,'flags':{label:dict(collections.Counter(r['metric'] for r in rows if r['review_flags'][label] and not r['operation'].startswith('ring_'))) for label in ('original','candidate')},'scope':'Rotating original/candidate/borrow-probe comparison, not equivalence or acceptance. All controls retained without subtraction.'}
(raw/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['flags'])
for row in rows:
 if row['operation'] in ('history_collect_root','history_read_all_inherited') and row['state_words']==1 and row['steps'] in (1,8,32,128) and row['metric']=='p50_ns':print(row['operation'],row['steps'],row['medians'],row['probe_delta_percent'])
