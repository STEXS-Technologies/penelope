import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
out=Path('/tmp/penelope-pre-pr-lineage-borrow-measure');out.mkdir(exist_ok=False)
root=Path('/home/ac/projects/.penelope-pre-pr-borrow-probe')
build=Path('/tmp/penelope-pre-pr-timeline-diagnostic/probe-build-formatted.jsonl')
artifacts=[e['executable'] for line in build.read_text().splitlines() if (e:=json.loads(line)).get('reason')=='compiler-artifact' and e['target']['name']=='timeline_operations' and e.get('executable')]
assert len(artifacts)==1
binaries={'original':Path('/tmp/penelope-pre-pr-legacy-comparison/binaries/before/timeline_operations'),'candidate':Path('/tmp/penelope-pre-pr-legacy-comparison/binaries/after/timeline_operations'),'probe':Path(artifacts[0])}
for name,p in binaries.items():shutil.copy2(p,out/(name+'.bin'))
source=root/'crates/penelope-timeline/src/history.rs'
before=hashlib.sha256(source.read_bytes()).hexdigest()
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/penelope-timeline/src/history.rs'],cwd=root))
(out/'metadata.json').write_text(json.dumps({'base':'7ab93d2cbb426f1e058fb7abc76c42c3f8582178','probe_history_sha256':before,'binaries_sha256':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in binaries.items()},'rounds':12,'warmups':1,'cpu':4,'samples':1000,'order':'rotating original/candidate/probe; whole first triple excluded','scope':'Isolated borrowed-lineage trial; no candidate adoption or acceptance.'},indent=2)+'\n')
labels=list(binaries)
for i in range(13):
 for label in labels[i%3:]+labels[:i%3]:
  name=('warmup' if i==0 else f'round-{i:02d}')+'-'+label
  print(name,flush=True)
  start=time.monotonic();r=subprocess.run(['taskset','-c','4',str(out/(label+'.bin'))],env={**os.environ,'PENELOPE_TIMELINE_SAMPLES':'1000'},capture_output=True,text=True)
  (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  (out/(name+'.result.json')).write_text(json.dumps({'exit_code':r.returncode,'seconds':time.monotonic()-start})+'\n');r.check_returncode()
  assert len([l for l in r.stdout.splitlines() if l.startswith('latency,')])==640
assert before==hashlib.sha256(source.read_bytes()).hexdigest()
print('Completed 12 rotating triples; probe source unchanged',flush=True)
