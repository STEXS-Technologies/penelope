import hashlib,json,os,subprocess
from pathlib import Path
out=Path('/tmp/penelope-pre-pr-lineage-borrow-measure')
meta=json.loads((out/'metadata.json').read_text())
assert meta['rounds']==12
for i in range(1,13):
 for label in ('original','candidate','probe'):
  assert json.loads((out/f'round-{i:02d}-{label}.result.json').read_text())['exit_code']==0
for name,digest in meta['binaries_sha256'].items():assert hashlib.sha256((out/(name+'.bin')).read_bytes()).hexdigest()==digest
(out/'initial-12-rounds-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'initial-12-rounds-summary.json').write_bytes((out/'summary.json').read_bytes())
meta['rounds']=31;(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
labels=['original','candidate','probe']
for i in range(13,32):
 for label in labels[i%3:]+labels[:i%3]:
  name=f'round-{i:02d}-{label}'
  print(name,flush=True)
  r=subprocess.run(['taskset','-c','4',str(out/(label+'.bin'))],env={**os.environ,'PENELOPE_TIMELINE_SAMPLES':'1000'},capture_output=True,text=True)
  (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  (out/(name+'.result.json')).write_text(json.dumps({'exit_code':r.returncode})+'\n');r.check_returncode()
  assert len([l for l in r.stdout.splitlines() if l.startswith('latency,')])==640
source=Path('/home/ac/projects/.penelope-pre-pr-borrow-probe/crates/penelope-timeline/src/history.rs')
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['probe_history_sha256']
print('All 31 rotating triples complete; binaries and source unchanged',flush=True)
