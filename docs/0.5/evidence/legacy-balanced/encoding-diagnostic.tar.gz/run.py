import hashlib,importlib.util,json,os,subprocess
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-050-contract-diagnostic');out.mkdir(exist_ok=False)
repos={'baseline':Path('/tmp/penelope-v040-baseline'),'patched-baseline':Path('/tmp/penelope-v040-patched-deps'),'candidate':root}
os.sched_setaffinity(0,{4,5,6,7})
spec=importlib.util.spec_from_file_location('bench',root/'scripts/benchmark-decision-comparison.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
bins={};metadata={'purpose':'Diagnostic hardware counters across original baseline, patched-dependencies baseline and current source; no release acceptance.','rounds':15,'variants':{}}
for label,repo in repos.items():
 target={'baseline':'before','candidate':'after','patched-baseline':'patched-baseline'}[label]
 env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/f'target/sqlite-performance-{target}')}
 result=subprocess.run(['cargo','+1.100.0','bench','-p','penelope-ports','--bench','contract_throughput','--locked','--no-run','--message-format=json'],cwd=repo,env=env,text=True,capture_output=True,check=True)
 (out/(label+'-build.jsonl')).write_text(result.stdout);(out/(label+'-build.stderr')).write_text(result.stderr)
 bins[label]=[d['executable'] for l in result.stdout.splitlines() if (d:=json.loads(l)).get('reason')=='compiler-artifact' and d['target']['name']=='contract_throughput' and d.get('executable')][0]
 metadata['variants'][label]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],cwd=repo,text=True),'binary':bins[label],'binary_sha256':hashlib.sha256(Path(bins[label]).read_bytes()).hexdigest()}
 subprocess.run(['taskset','-c','4',bins[label]],stdout=subprocess.DEVNULL,check=True)
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
for n in range(1,16):
 labels=list(repos);labels=labels[n%3:]+labels[:n%3]
 for label in labels:
  counter=out/f'round-{n}-{label}.perf.jsonl'
  result=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(counter),'--','taskset','-c','4',bins[label]],capture_output=True,text=True,check=True)
  (out/f'round-{n}-{label}.json').write_text(json.dumps({'stdout':result.stdout,'stderr':result.stderr,'observations':bench.observations(result.stdout)},indent=2)+'\n')
 print('Completed diagnostic round',n,flush=True)
