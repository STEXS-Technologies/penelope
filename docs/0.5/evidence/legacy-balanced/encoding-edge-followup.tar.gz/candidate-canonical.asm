
/home/ac/projects/penelope/target/sqlite-performance-after/release/build/penelope-ports/ee158e120ce888e7/out/contract_throughput-ee158e120ce888e7:     file format elf64-x86-64


Disassembly of section .text:

000000000001f220 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes>:
   1f220:	push   %r14
   1f222:	push   %rbx
   1f223:	sub    $0x38,%rsp
   1f227:	mov    %rsi,%r14
   1f22a:	mov    %rdi,%rbx
   1f22d:	call   *0x418d5(%rip)        # 60b08 <_DYNAMIC+0x308>
   1f233:	mov    $0x200,%edi
   1f238:	mov    $0x1,%esi
   1f23d:	call   *0x418ad(%rip)        # 60af0 <_DYNAMIC+0x2f0>
   1f243:	test   %rax,%rax
   1f246:	je     1f491 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x271>
   1f24c:	movq   $0x200,0x18(%rsp)
   1f255:	mov    %rax,0x20(%rsp)
   1f25a:	lea    0x18(%rsp),%rcx
   1f25f:	mov    %rcx,0x30(%rsp)
   1f264:	movb   $0x7b,(%rax)
   1f267:	movq   $0x1,0x28(%rsp)
   1f270:	lea    0x30(%rsp),%rax
   1f275:	mov    %rax,0x8(%rsp)
   1f27a:	movb   $0x1,0x10(%rsp)
   1f27f:	lea    0x20(%r14),%rcx
   1f283:	lea    -0x177f3(%rip),%rsi        # 7a97 <anon.f62ff1550d1d8e93736aadb112c3e8c6.30.llvm.12660996087838708201>
   1f28a:	lea    0x8(%rsp),%rdi
   1f28f:	mov    $0x9,%edx
   1f294:	call   1fb50 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f299:	test   %rax,%rax
   1f29c:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2a2:	lea    0x38(%r14),%rcx
   1f2a6:	lea    -0x1780d(%rip),%rsi        # 7aa0 <anon.f62ff1550d1d8e93736aadb112c3e8c6.31.llvm.12660996087838708201>
   1f2ad:	lea    0x8(%rsp),%rdi
   1f2b2:	mov    $0xa,%edx
   1f2b7:	call   1fb50 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f2bc:	test   %rax,%rax
   1f2bf:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2c5:	lea    0x50(%r14),%rcx
   1f2c9:	lea    -0x17826(%rip),%rsi        # 7aaa <anon.f62ff1550d1d8e93736aadb112c3e8c6.31.llvm.12660996087838708201+0xa>
   1f2d0:	lea    0x8(%rsp),%rdi
   1f2d5:	mov    $0xd,%edx
   1f2da:	call   1fb50 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f2df:	test   %rax,%rax
   1f2e2:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2e8:	lea    0x68(%r14),%rcx
   1f2ec:	lea    -0x1783c(%rip),%rsi        # 7ab7 <anon.f62ff1550d1d8e93736aadb112c3e8c6.31.llvm.12660996087838708201+0x17>
   1f2f3:	lea    0x8(%rsp),%rdi
   1f2f8:	mov    $0x12,%edx
   1f2fd:	call   1fb50 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f302:	test   %rax,%rax
   1f305:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f30b:	lea    0xb0(%r14),%rcx
   1f312:	lea    -0x17850(%rip),%rsi        # 7ac9 <anon.f62ff1550d1d8e93736aadb112c3e8c6.31.llvm.12660996087838708201+0x29>
   1f319:	lea    0x8(%rsp),%rdi
   1f31e:	mov    $0x11,%edx
   1f323:	call   1fd20 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ContentDigest>>
   1f328:	test   %rax,%rax
   1f32b:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f331:	lea    0xd0(%r14),%rcx
   1f338:	lea    -0x177bf(%rip),%rsi        # 7b80 <anon.f62ff1550d1d8e93736aadb112c3e8c6.48.llvm.12660996087838708201+0x14>
   1f33f:	lea    0x8(%rsp),%rdi
   1f344:	mov    $0x8,%edx
   1f349:	call   1fea0 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, u64>>
   1f34e:	test   %rax,%rax
   1f351:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f357:	lea    0x80(%r14),%rcx
   1f35e:	lea    -0x17871(%rip),%rsi        # 7af4 <anon.f62ff1550d1d8e93736aadb112c3e8c6.42.llvm.12660996087838708201+0x9>
   1f365:	lea    0x8(%rsp),%rdi
   1f36a:	mov    $0xa,%edx
   1f36f:	call   1fb50 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f374:	test   %rax,%rax
   1f377:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f37d:	lea    -0x17886(%rip),%rsi        # 7afe <anon.f62ff1550d1d8e93736aadb112c3e8c6.42.llvm.12660996087838708201+0x13>
   1f384:	lea    0x8(%rsp),%rdi
   1f389:	mov    $0xc,%edx
   1f38e:	mov    %r14,%rcx
   1f391:	call   1f970 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::CausationId>>
   1f396:	test   %rax,%rax
   1f399:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f39f:	lea    0x98(%r14),%rcx
   1f3a6:	lea    -0x178a3(%rip),%rsi        # 7b0a <anon.f62ff1550d1d8e93736aadb112c3e8c6.42.llvm.12660996087838708201+0x1f>
   1f3ad:	lea    0x8(%rsp),%rdi
   1f3b2:	mov    $0x5,%edx
   1f3b7:	call   1fc60 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::OutcomeActor>>
   1f3bc:	test   %rax,%rax
   1f3bf:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f3c1:	lea    0xd8(%r14),%rcx
   1f3c8:	lea    -0x178c0(%rip),%rsi        # 7b0f <anon.f62ff1550d1d8e93736aadb112c3e8c6.42.llvm.12660996087838708201+0x24>
   1f3cf:	lea    0x8(%rsp),%rdi
   1f3d4:	mov    $0xb,%edx
   1f3d9:	call   1fa30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::LogicalTime>>
   1f3de:	test   %rax,%rax
   1f3e1:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f3e3:	lea    0x100(%r14),%rcx
   1f3ea:	lea    -0x178b5(%rip),%rsi        # 7b3c <anon.f62ff1550d1d8e93736aadb112c3e8c6.47.llvm.12660996087838708201>
   1f3f1:	lea    0x8(%rsp),%rdi
   1f3f6:	mov    $0x4,%edx
   1f3fb:	call   1fde0 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ProcessOutcomeKind>>
   1f400:	test   %rax,%rax
   1f403:	jne    1f42a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f405:	add    $0xe0,%r14
   1f40c:	lea    -0x178a7(%rip),%rsi        # 7b6c <anon.f62ff1550d1d8e93736aadb112c3e8c6.48.llvm.12660996087838708201>
   1f413:	lea    0x8(%rsp),%rdi
   1f418:	mov    $0xe,%edx
   1f41d:	mov    %r14,%rcx
   1f420:	call   1fd20 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ContentDigest>>
   1f425:	test   %rax,%rax
   1f428:	je     1f45e <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x23e>
   1f42a:	mov    %rax,%rdi
   1f42d:	call   1e0c0 <core::ptr::drop_glue::<serde_json::error::Error>>
   1f432:	movq   $0xffffffffffffffff,(%rbx)
   1f439:	mov    0x18(%rsp),%rsi
   1f43e:	test   %rsi,%rsi
   1f441:	je     1f453 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x233>
   1f443:	mov    0x20(%rsp),%rdi
   1f448:	mov    $0x1,%edx
   1f44d:	call   *0x415dd(%rip)        # 60a30 <_DYNAMIC+0x230>
   1f453:	mov    %rbx,%rax
   1f456:	add    $0x38,%rsp
   1f45a:	pop    %rbx
   1f45b:	pop    %r14
   1f45d:	ret
   1f45e:	cmpb   $0x0,0x10(%rsp)
   1f463:	je     1f47e <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x25e>
   1f465:	mov    0x8(%rsp),%rax
   1f46a:	mov    (%rax),%rdi
   1f46d:	lea    -0x178b4(%rip),%rsi        # 7bc0 <anon.f62ff1550d1d8e93736aadb112c3e8c6.66.llvm.12660996087838708201>
   1f474:	mov    $0x1,%edx
   1f479:	call   1ffc0 <<alloc::vec::Vec<u8>>::extend_from_slice>
   1f47e:	mov    0x28(%rsp),%rax
   1f483:	mov    %rax,0x10(%rbx)
   1f487:	movups 0x18(%rsp),%xmm0
   1f48c:	movups %xmm0,(%rbx)
   1f48f:	jmp    1f453 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x233>
   1f491:	mov    $0x1,%edi
   1f496:	mov    $0x200,%esi
   1f49b:	call   *0x416bf(%rip)        # 60b60 <_DYNAMIC+0x360>
   1f4a1:	mov    %rax,%rbx
   1f4a4:	mov    0x18(%rsp),%rsi
   1f4a9:	test   %rsi,%rsi
   1f4ac:	je     1f4be <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x29e>
   1f4ae:	mov    0x20(%rsp),%rdi
   1f4b3:	mov    $0x1,%edx
   1f4b8:	call   *0x41572(%rip)        # 60a30 <_DYNAMIC+0x230>
   1f4be:	mov    %rbx,%rdi
   1f4c1:	call   5d770 <_Unwind_Resume@plt>
