import hashlib,importlib.util,json,os,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/tmp/penelope-encoding-edge-diagnostic');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{4,5,6,7})
spec=importlib.util.spec_from_file_location('bench',root/'scripts/benchmark-decision-comparison.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
variants={'patched-baseline':(Path('/tmp/penelope-v040-patched-deps'),'sqlite-performance-patched-baseline'),'without-domain-core':(Path('/tmp/penelope-v040-no-domain-core'),'encoding-without-domain-core'),'candidate':(root,'sqlite-performance-after')}
metadata={'purpose':'Isolate deletion of the unused penelope-domain -> penelope-core manifest edge on the old source, holding the patched dependency stack fixed. Diagnostic only.','rounds':15,'variants':{},'build_environment':{k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS']}}
binaries={}
for label,(repo,target) in variants.items():
 env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target'/target)}
 p=subprocess.run(['cargo','+1.100.0','bench','--locked','-p','penelope-ports','--bench','contract_throughput','--no-run','--message-format=json'],cwd=repo,env=env,text=True,capture_output=True)
 (out/(label+'-build.jsonl')).write_text(p.stdout);(out/(label+'-build.stderr')).write_text(p.stderr);p.check_returncode()
 artifacts=[e for l in p.stdout.splitlines() if (e:=json.loads(l)).get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='contract_throughput' and e.get('executable')];assert len(artifacts)==1 and not artifacts[0]['profile']['debug_assertions'];binary=artifacts[0]['executable'];binaries[label]=binary
 metadata['variants'][label]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],cwd=repo,text=True),'binary':binary,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'canonical_implementation_sha256':hashlib.sha256((repo/'crates/penelope-domain/src/implementation.rs').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256((repo/'crates/penelope-ports/benches/contract_throughput.rs').read_bytes()).hexdigest()}
 subprocess.run(['taskset','-c','4',binary],stdout=subprocess.DEVNULL,check=True)
 print('Built',label,flush=True)
assert len({v['canonical_implementation_sha256'] for v in metadata['variants'].values()})==1
assert len({v['fixture_sha256'] for v in metadata['variants'].values()})==1
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
for round in range(1,16):
 labels=list(variants);labels=labels[round%3:]+labels[:round%3]
 for label in labels:
  perf=out/f'round-{round}-{label}.perf.jsonl'
  p=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(perf),'--','taskset','-c','4',binaries[label]],text=True,capture_output=True)
  (out/f'round-{round}-{label}.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'observations':bench.observations(p.stdout)},indent=2)+'\n');p.check_returncode()
 print('Completed diagnostic round',round,flush=True)
