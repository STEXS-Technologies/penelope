
/home/ac/projects/penelope/target/sqlite-performance-patched-baseline/release/build/penelope-ports/e9b230cab0fab0ab/out/contract_throughput-e9b230cab0fab0ab:     file format elf64-x86-64


Disassembly of section .text:

000000000001f200 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes>:
   1f200:	push   %r14
   1f202:	push   %rbx
   1f203:	sub    $0x38,%rsp
   1f207:	mov    %rsi,%r14
   1f20a:	mov    %rdi,%rbx
   1f20d:	call   *0x418d5(%rip)        # 60ae8 <_DYNAMIC+0x308>
   1f213:	mov    $0x200,%edi
   1f218:	mov    $0x1,%esi
   1f21d:	call   *0x418ad(%rip)        # 60ad0 <_DYNAMIC+0x2f0>
   1f223:	test   %rax,%rax
   1f226:	je     1f471 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x271>
   1f22c:	movq   $0x200,0x18(%rsp)
   1f235:	mov    %rax,0x20(%rsp)
   1f23a:	lea    0x18(%rsp),%rcx
   1f23f:	mov    %rcx,0x30(%rsp)
   1f244:	movb   $0x7b,(%rax)
   1f247:	movq   $0x1,0x28(%rsp)
   1f250:	lea    0x30(%rsp),%rax
   1f255:	mov    %rax,0x8(%rsp)
   1f25a:	movb   $0x1,0x10(%rsp)
   1f25f:	lea    0x20(%r14),%rcx
   1f263:	lea    -0x177d3(%rip),%rsi        # 7a97 <anon.4ebe1797ff24f38e876d064db2384f50.30.llvm.7950360494056520853>
   1f26a:	lea    0x8(%rsp),%rdi
   1f26f:	mov    $0x9,%edx
   1f274:	call   1fb30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f279:	test   %rax,%rax
   1f27c:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f282:	lea    0x38(%r14),%rcx
   1f286:	lea    -0x177ed(%rip),%rsi        # 7aa0 <anon.4ebe1797ff24f38e876d064db2384f50.31.llvm.7950360494056520853>
   1f28d:	lea    0x8(%rsp),%rdi
   1f292:	mov    $0xa,%edx
   1f297:	call   1fb30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f29c:	test   %rax,%rax
   1f29f:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2a5:	lea    0x50(%r14),%rcx
   1f2a9:	lea    -0x17806(%rip),%rsi        # 7aaa <anon.4ebe1797ff24f38e876d064db2384f50.31.llvm.7950360494056520853+0xa>
   1f2b0:	lea    0x8(%rsp),%rdi
   1f2b5:	mov    $0xd,%edx
   1f2ba:	call   1fb30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f2bf:	test   %rax,%rax
   1f2c2:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2c8:	lea    0x68(%r14),%rcx
   1f2cc:	lea    -0x1781c(%rip),%rsi        # 7ab7 <anon.4ebe1797ff24f38e876d064db2384f50.31.llvm.7950360494056520853+0x17>
   1f2d3:	lea    0x8(%rsp),%rdi
   1f2d8:	mov    $0x12,%edx
   1f2dd:	call   1fb30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f2e2:	test   %rax,%rax
   1f2e5:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f2eb:	lea    0xb0(%r14),%rcx
   1f2f2:	lea    -0x17830(%rip),%rsi        # 7ac9 <anon.4ebe1797ff24f38e876d064db2384f50.31.llvm.7950360494056520853+0x29>
   1f2f9:	lea    0x8(%rsp),%rdi
   1f2fe:	mov    $0x11,%edx
   1f303:	call   1fd00 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ContentDigest>>
   1f308:	test   %rax,%rax
   1f30b:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f311:	lea    0xd0(%r14),%rcx
   1f318:	lea    -0x1779f(%rip),%rsi        # 7b80 <anon.4ebe1797ff24f38e876d064db2384f50.48.llvm.7950360494056520853+0x14>
   1f31f:	lea    0x8(%rsp),%rdi
   1f324:	mov    $0x8,%edx
   1f329:	call   1fe80 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, u64>>
   1f32e:	test   %rax,%rax
   1f331:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f337:	lea    0x80(%r14),%rcx
   1f33e:	lea    -0x17851(%rip),%rsi        # 7af4 <anon.4ebe1797ff24f38e876d064db2384f50.42.llvm.7950360494056520853+0x9>
   1f345:	lea    0x8(%rsp),%rdi
   1f34a:	mov    $0xa,%edx
   1f34f:	call   1fb30 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::MigrationId>>
   1f354:	test   %rax,%rax
   1f357:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f35d:	lea    -0x17866(%rip),%rsi        # 7afe <anon.4ebe1797ff24f38e876d064db2384f50.42.llvm.7950360494056520853+0x13>
   1f364:	lea    0x8(%rsp),%rdi
   1f369:	mov    $0xc,%edx
   1f36e:	mov    %r14,%rcx
   1f371:	call   1f950 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::CausationId>>
   1f376:	test   %rax,%rax
   1f379:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f37f:	lea    0x98(%r14),%rcx
   1f386:	lea    -0x17883(%rip),%rsi        # 7b0a <anon.4ebe1797ff24f38e876d064db2384f50.42.llvm.7950360494056520853+0x1f>
   1f38d:	lea    0x8(%rsp),%rdi
   1f392:	mov    $0x5,%edx
   1f397:	call   1fc40 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::OutcomeActor>>
   1f39c:	test   %rax,%rax
   1f39f:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f3a1:	lea    0xd8(%r14),%rcx
   1f3a8:	lea    -0x178a0(%rip),%rsi        # 7b0f <anon.4ebe1797ff24f38e876d064db2384f50.42.llvm.7950360494056520853+0x24>
   1f3af:	lea    0x8(%rsp),%rdi
   1f3b4:	mov    $0xb,%edx
   1f3b9:	call   1fa10 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::LogicalTime>>
   1f3be:	test   %rax,%rax
   1f3c1:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f3c3:	lea    0x100(%r14),%rcx
   1f3ca:	lea    -0x17895(%rip),%rsi        # 7b3c <anon.4ebe1797ff24f38e876d064db2384f50.47.llvm.7950360494056520853>
   1f3d1:	lea    0x8(%rsp),%rdi
   1f3d6:	mov    $0x4,%edx
   1f3db:	call   1fdc0 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ProcessOutcomeKind>>
   1f3e0:	test   %rax,%rax
   1f3e3:	jne    1f40a <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x20a>
   1f3e5:	add    $0xe0,%r14
   1f3ec:	lea    -0x17887(%rip),%rsi        # 7b6c <anon.4ebe1797ff24f38e876d064db2384f50.48.llvm.7950360494056520853>
   1f3f3:	lea    0x8(%rsp),%rdi
   1f3f8:	mov    $0xe,%edx
   1f3fd:	mov    %r14,%rcx
   1f400:	call   1fd00 <<serde_json::ser::Compound<&mut alloc::vec::Vec<u8>, serde_json::ser::CompactFormatter> as serde_core::ser::SerializeMap>::serialize_entry::<str, penelope_domain::entry::implementation::ContentDigest>>
   1f405:	test   %rax,%rax
   1f408:	je     1f43e <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x23e>
   1f40a:	mov    %rax,%rdi
   1f40d:	call   1e0a0 <core::ptr::drop_glue::<serde_json::error::Error>>
   1f412:	movq   $0xffffffffffffffff,(%rbx)
   1f419:	mov    0x18(%rsp),%rsi
   1f41e:	test   %rsi,%rsi
   1f421:	je     1f433 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x233>
   1f423:	mov    0x20(%rsp),%rdi
   1f428:	mov    $0x1,%edx
   1f42d:	call   *0x415dd(%rip)        # 60a10 <_DYNAMIC+0x230>
   1f433:	mov    %rbx,%rax
   1f436:	add    $0x38,%rsp
   1f43a:	pop    %rbx
   1f43b:	pop    %r14
   1f43d:	ret
   1f43e:	cmpb   $0x0,0x10(%rsp)
   1f443:	je     1f45e <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x25e>
   1f445:	mov    0x8(%rsp),%rax
   1f44a:	mov    (%rax),%rdi
   1f44d:	lea    -0x17894(%rip),%rsi        # 7bc0 <anon.4ebe1797ff24f38e876d064db2384f50.66.llvm.7950360494056520853>
   1f454:	mov    $0x1,%edx
   1f459:	call   1ffa0 <<alloc::vec::Vec<u8>>::extend_from_slice>
   1f45e:	mov    0x28(%rsp),%rax
   1f463:	mov    %rax,0x10(%rbx)
   1f467:	movups 0x18(%rsp),%xmm0
   1f46c:	movups %xmm0,(%rbx)
   1f46f:	jmp    1f433 <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x233>
   1f471:	mov    $0x1,%edi
   1f476:	mov    $0x200,%esi
   1f47b:	call   *0x416bf(%rip)        # 60b40 <_DYNAMIC+0x360>
   1f481:	mov    %rax,%rbx
   1f484:	mov    0x18(%rsp),%rsi
   1f489:	test   %rsi,%rsi
   1f48c:	je     1f49e <<penelope_domain::entry::implementation::ProcessOutcome as penelope_domain::entry::implementation::CanonicalWireBytes>::canonical_wire_bytes+0x29e>
   1f48e:	mov    0x20(%rsp),%rdi
   1f493:	mov    $0x1,%edx
   1f498:	call   *0x41572(%rip)        # 60a10 <_DYNAMIC+0x230>
   1f49e:	mov    %rbx,%rdi
   1f4a1:	call   5d750 <_Unwind_Resume@plt>
