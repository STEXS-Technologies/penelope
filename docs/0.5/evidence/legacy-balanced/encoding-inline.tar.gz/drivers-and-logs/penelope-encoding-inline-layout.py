import os,subprocess,json,hashlib,shutil,importlib.util
from pathlib import Path
root=Path('/home/ac/projects/penelope');repo=Path('/tmp/penelope-encoding-inline');out=Path('/tmp/penelope-encoding-inline-layout');out.mkdir(exist_ok=False);previous=Path('/tmp/penelope-encoding-inline-diagnostic')
os.sched_setaffinity(0,{4,5,6,7});env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/encoding-inline')}
spec=importlib.util.spec_from_file_location('benchmark',root/'scripts/benchmark-decision-comparison.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
binaries={};metadata={'rounds_per_cell':5,'cpu':4,'scope':'Diagnostic-only 32-byte .text placement grid on the two same-checkout source variants; no production linker flag. Separate frozen and varied opaque fixtures.','cells':{}}
for variant in ['control','inline']:
 (repo/'crates/penelope-domain/src/implementation.rs').write_bytes((previous/(variant+'-implementation.rs')).read_bytes())
 for fixture in ['contract_throughput','opaque_encoding']:
  for address in ['20000','20020','20040','20060']:
   label=fixture+'-'+variant+'-'+address;print('build',label,flush=True)
   args=['cargo','+1.100.0','rustc','--locked','-p','penelope-ports','--bench',fixture,'--profile','bench','--message-format=json','--','-C','link-arg=-Wl,--section-start=.text=0x'+address]
   r=subprocess.run(args,cwd=repo,env=env,capture_output=True,text=True);(out/(label+'-build.jsonl')).write_text(r.stdout);(out/(label+'-build.stderr')).write_text(r.stderr);r.check_returncode()
   entries=[json.loads(l) for l in r.stdout.splitlines()];found=[x['executable'] for x in entries if x.get('reason')=='compiler-artifact' and x['target']['name']==fixture and x.get('executable')];assert len(found)==1
   dest=out/label.ljust(48,'_');shutil.copyfile(found[0],dest);dest.chmod(0o755);binaries[label]=str(dest)
   text=out/(label+'.text.bin');subprocess.run(['objcopy','--dump-section','.text='+str(text),dest],check=True)
   (out/(label+'-sections.txt')).write_text(subprocess.check_output(['readelf','-SW',dest],text=True))
   metadata['cells'][label]={'build_args':args,'binary_sha256_before_run':hashlib.sha256(dest.read_bytes()).hexdigest(),'text_sha256':hashlib.sha256(text.read_bytes()).hexdigest(),'text_bytes':text.stat().st_size}
   r=subprocess.run(['taskset','-c','4',dest],capture_output=True,text=True);r.check_returncode();(out/(label+'-warmup.stdout')).write_text(r.stdout)
(out/'metadata.json').write_text(json.dumps(metadata,indent=2))
for i in range(1,6):
 labels=list(binaries);offset=(i*5)%len(labels);labels=labels[offset:]+labels[:offset]
 for label in labels:
  counter=out/f'round-{i}-{label}.perf.jsonl';r=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(counter),'--','taskset','-c','4',binaries[label]],capture_output=True,text=True)
  (out/f'round-{i}-{label}.json').write_text(json.dumps({'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observations':helper.observations(r.stdout)},indent=2));r.check_returncode()
 print('round',i,flush=True)
print('completed',flush=True)
