import os,subprocess,json,hashlib,shutil,importlib.util
from pathlib import Path
root=Path('/home/ac/projects/penelope');repo=Path('/tmp/penelope-encoding-inline');out=Path('/tmp/penelope-encoding-inline-diagnostic');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{4,5,6,7})
spec=importlib.util.spec_from_file_location('benchmark',root/'scripts/benchmark-decision-comparison.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/encoding-inline')}
binaries={};meta={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'rounds':15,'cpu':4,'build_cpus':[4,5,6,7],'rustc':subprocess.check_output(['rustc','+1.100.0','-vV'],text=True),'environment':{k:env.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'variants':{},'scope':'Single checkout and target directory. Control captured before inserting #[inline] on macro-generated canonical_wire_bytes implementations. Frozen fixture unchanged. Opaque diagnostic cycles four DTOs and black-boxes input and entire output, checking aggregate size and untimed independent serde_json::to_vec bytes.'}
p=repo/'crates/penelope-domain/src/implementation.rs';original=p.read_text()
assert (repo/'crates/penelope-ports/benches/contract_throughput.rs').read_bytes()==subprocess.check_output(['git','show','42ec187c9adfc7403b06215f405f2575f53c35c2:crates/penelope-ports/benches/contract_throughput.rs'],cwd=root)
for variant in ['control','inline']:
 if variant=='inline':
  marker='''            impl CanonicalWireBytes for $ty {
                fn canonical_wire_bytes''';assert marker in original;p.write_text(original.replace(marker,'''            impl CanonicalWireBytes for $ty {
                #[inline]
                fn canonical_wire_bytes'''))
 print('build',variant,flush=True)
 r=subprocess.run(['cargo','+1.100.0','bench','--locked','-p','penelope-ports','--bench','contract_throughput','--bench','opaque_encoding','--no-run','--message-format=json'],cwd=repo,env=env,capture_output=True,text=True)
 (out/(variant+'-build.jsonl')).write_text(r.stdout);(out/(variant+'-build.stderr')).write_text(r.stderr);r.check_returncode()
 (out/(variant+'-diff.patch')).write_bytes(subprocess.check_output(['git','diff'],cwd=repo));(out/(variant+'-implementation.rs')).write_bytes(p.read_bytes())
 entries=[json.loads(l) for l in r.stdout.splitlines()]
 for fixture in ['contract_throughput','opaque_encoding']:
  found=[x['executable'] for x in entries if x.get('reason')=='compiler-artifact' and x['target']['name']==fixture and x.get('executable')];assert len(found)==1
  label=fixture+'-'+variant;dest=out/label.ljust(40,'_');shutil.copyfile(found[0],dest);dest.chmod(0o755);binaries[label]=str(dest)
  symbols=subprocess.check_output(['nm','-S','--demangle',dest],text=True);(out/(label+'-symbols.txt')).write_text(symbols)
  sections=subprocess.check_output(['readelf','-SW',dest],text=True);(out/(label+'-sections.txt')).write_text(sections)
  meta['variants'][label]={'binary_sha256_before_run':hashlib.sha256(dest.read_bytes()).hexdigest(),'binary_bytes':dest.stat().st_size}
  r=subprocess.run(['taskset','-c','4',dest],capture_output=True,text=True);r.check_returncode();(out/(label+'-warmup.stdout')).write_text(r.stdout)
(out/'opaque_encoding.rs').write_bytes((repo/'crates/penelope-ports/benches/opaque_encoding.rs').read_bytes())
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
for i in range(1,16):
 labels=list(binaries);offset=i%len(labels);labels=labels[offset:]+labels[:offset]
 for label in labels:
  counter=out/f'round-{i}-{label}.perf.jsonl';r=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(counter),'--','taskset','-c','4',binaries[label]],capture_output=True,text=True)
  (out/f'round-{i}-{label}.json').write_text(json.dumps({'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observations':helper.observations(r.stdout)},indent=2));r.check_returncode()
 print('round',i,flush=True)
print('completed',flush=True)
