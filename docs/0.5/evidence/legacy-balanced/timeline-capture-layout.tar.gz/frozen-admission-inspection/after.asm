
/tmp/penelope-timeline-current-paired/binary-diagnostics/after:     file format elf64-x86-64


Disassembly of section .text:

0000000000059de0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission>:
   59de0:	movdqu (%rdx),%xmm0
   59de4:	movdqu 0x10(%rdx),%xmm1
   59de9:	movdqu 0x21eb8(%rsi),%xmm2
   59df1:	pcmpeqb %xmm0,%xmm2
   59df5:	movdqu 0x21ec8(%rsi),%xmm0
   59dfd:	pcmpeqb %xmm1,%xmm0
   59e01:	pand   %xmm2,%xmm0
   59e05:	pmovmskb %xmm0,%eax
   59e09:	cmp    $0xffff,%eax
   59e0e:	jne    59ea7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59e14:	movdqu 0x20(%rdx),%xmm0
   59e19:	movdqu 0x30(%rdx),%xmm1
   59e1e:	movdqu 0x21ed8(%rsi),%xmm2
   59e26:	pcmpeqb %xmm0,%xmm2
   59e2a:	movdqu 0x21ee8(%rsi),%xmm0
   59e32:	pcmpeqb %xmm1,%xmm0
   59e36:	pand   %xmm2,%xmm0
   59e3a:	pmovmskb %xmm0,%eax
   59e3e:	cmp    $0xffff,%eax
   59e43:	jne    59ea7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59e45:	movdqu 0x40(%rdx),%xmm0
   59e4a:	movdqu 0x50(%rdx),%xmm1
   59e4f:	movdqu 0x21ef8(%rsi),%xmm2
   59e57:	pcmpeqb %xmm0,%xmm2
   59e5b:	movdqu 0x21f08(%rsi),%xmm0
   59e63:	pcmpeqb %xmm1,%xmm0
   59e67:	pand   %xmm2,%xmm0
   59e6b:	pmovmskb %xmm0,%eax
   59e6f:	cmp    $0xffff,%eax
   59e74:	jne    59ea7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59e76:	movdqu 0x60(%rdx),%xmm0
   59e7b:	movdqu 0x70(%rdx),%xmm1
   59e80:	movdqu 0x21f18(%rsi),%xmm2
   59e88:	pcmpeqb %xmm0,%xmm2
   59e8c:	movdqu 0x21f28(%rsi),%xmm0
   59e94:	pcmpeqb %xmm1,%xmm0
   59e98:	pand   %xmm2,%xmm0
   59e9c:	pmovmskb %xmm0,%eax
   59ea0:	cmp    $0xffff,%eax
   59ea5:	je     59eb3 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xd3>
   59ea7:	movb   $0x0,0x8(%rdi)
   59eab:	movq   $0x2,(%rdi)
   59eb2:	ret
   59eb3:	push   %rbp
   59eb4:	push   %r15
   59eb6:	push   %r14
   59eb8:	push   %r13
   59eba:	push   %r12
   59ebc:	push   %rbx
   59ebd:	sub    $0x38,%rsp
   59ec1:	mov    0xc0(%rdx),%r15
   59ec8:	cmpl   $0x2,(%rsi)
   59ecb:	je     59ed9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xf9>
   59ecd:	mov    %rsi,%rax
   59ed0:	cmp    %r15,0x1c8(%rsi)
   59ed7:	je     59ef2 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x112>
   59ed9:	cmpl   $0x2,0x1e8(%rsi)
   59ee0:	je     59f4f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59ee2:	cmp    %r15,0x3b0(%rsi)
   59ee9:	jne    59f4f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59eeb:	lea    0x1e8(%rsi),%rax
   59ef2:	mov    0xc8(%rdx),%r12
   59ef9:	cmp    0x1d8(%rax),%r12
   59f00:	ja     59f4f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59f02:	cmp    0x21f38(%rsi),%r12
   59f09:	jb     59f4f <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59f0b:	mov    %r8d,%ebp
   59f0e:	mov    %rdi,%r13
   59f11:	mov    %rdx,%rbx
   59f14:	add    $0xa0,%rdx
   59f1b:	mov    %rsi,%r14
   59f1e:	mov    0x21f58(%rsi),%rax
   59f25:	mov    (%rcx),%rsi
   59f28:	lea    0x8(%rsp),%rdi
   59f2d:	mov    %rax,%rcx
   59f30:	call   571c0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_payload::<timeline_operations::workload::State<1>>>
   59f35:	cmpb   $0x1,0x8(%rsp)
   59f3a:	jne    59f69 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x189>
   59f3c:	movzbl 0x9(%rsp),%eax
   59f41:	mov    %al,0x8(%r13)
   59f45:	movq   $0x2,0x0(%r13)
   59f4d:	jmp    59f5a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   59f4f:	movb   $0x3,0x8(%rdi)
   59f53:	movq   $0x2,(%rdi)
   59f5a:	add    $0x38,%rsp
   59f5e:	pop    %rbx
   59f5f:	pop    %r12
   59f61:	pop    %r13
   59f63:	pop    %r14
   59f65:	pop    %r15
   59f67:	pop    %rbp
   59f68:	ret
   59f69:	mov    0x10(%rsp),%rax
   59f6e:	mov    %rax,(%rsp)
   59f72:	lea    0x3d0(%r14),%rcx
   59f79:	lea    0x3eb8(%r14),%rax
   59f80:	movq   $0x0,0x8(%rsp)
   59f89:	movq   $0x0,0x18(%rsp)
   59f92:	lea    0x28(%rsp),%rdi
   59f97:	mov    %rcx,0x28(%rsp)
   59f9c:	mov    %rax,0x30(%rsp)
   59fa1:	mov    %rbx,%rsi
   59fa4:	call   574e0 <<core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>> as core::iter::adapters::fuse::FuseImpl<core::slice::iter::Iter<core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>>>::try_fold::<(), core::iter::adapters::flatten::try_flatten_one<&core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>, (), core::ops::control_flow::ControlFlow<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>, core::iter::traits::iterator::Iterator::find::check<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>, <penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>>
   59fa9:	test   %rax,%rax
   59fac:	je     59fe0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x200>
   59fae:	mov    (%rsp),%rcx
   59fb2:	cmp    %rcx,0xd8(%rax)
   59fb9:	jne    59fcd <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1ed>
   59fbb:	test   %bpl,%bpl
   59fbe:	je     59fc9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1e9>
   59fc0:	cmpb   $0x1,0xe0(%rax)
   59fc7:	jne    59fcd <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1ed>
   59fc9:	xor    %eax,%eax
   59fcb:	jmp    59fd7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1f7>
   59fcd:	movb   $0xd,0x8(%r13)
   59fd2:	mov    $0x2,%eax
   59fd7:	mov    %rax,0x0(%r13)
   59fdb:	jmp    59f5a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   59fe0:	mov    (%rsp),%rsi
   59fe4:	test   %bpl,%bpl
   59fe7:	mov    %r13,%rax
   59fea:	je     5a04e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x26e>
   59fec:	xor    %edx,%edx
   59fee:	jmp    59ff7 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x217>
   59ff0:	add    $0x1d0,%rdx
   59ff7:	cmpb   $0x1,0x4b0(%r14,%rdx,1)
   5a000:	jne    5a016 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x236>
   5a002:	cmp    %r15,0x490(%r14,%rdx,1)
   5a00a:	jne    5a016 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x236>
   5a00c:	cmp    %r12,0x498(%r14,%rdx,1)
   5a014:	je     5a03e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x25e>
   5a016:	cmp    $0x3a00,%rdx
   5a01d:	je     5a04e <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x26e>
   5a01f:	cmpb   $0x1,0x598(%r14,%rdx,1)
   5a028:	jne    59ff0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   5a02a:	cmp    %r15,0x578(%r14,%rdx,1)
   5a032:	jne    59ff0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   5a034:	cmp    %r12,0x580(%r14,%rdx,1)
   5a03c:	jne    59ff0 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   5a03e:	movb   $0xd,0x8(%rax)
   5a042:	movq   $0x2,(%rax)
   5a049:	jmp    59f5a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   5a04e:	mov    0x21f48(%r14),%rdx
   5a055:	add    %rsi,%rdx
   5a058:	jb     5a3c9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5e9>
   5a05e:	cmp    0x21f60(%r14),%rdx
   5a065:	ja     5a3c9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5e9>
   5a06b:	cmpb   $0x2,0x4b0(%r14)
   5a073:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a079:	cmpb   $0x2,0x598(%r14)
   5a081:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a087:	cmpb   $0x2,0x680(%r14)
   5a08f:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a095:	cmpb   $0x2,0x768(%r14)
   5a09d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0a3:	cmpb   $0x2,0x850(%r14)
   5a0ab:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0b1:	cmpb   $0x2,0x938(%r14)
   5a0b9:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0bf:	cmpb   $0x2,0xa20(%r14)
   5a0c7:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0cd:	cmpb   $0x2,0xb08(%r14)
   5a0d5:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0db:	cmpb   $0x2,0xbf0(%r14)
   5a0e3:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0e9:	cmpb   $0x2,0xcd8(%r14)
   5a0f1:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0f7:	cmpb   $0x2,0xdc0(%r14)
   5a0ff:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a105:	cmpb   $0x2,0xea8(%r14)
   5a10d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a113:	cmpb   $0x2,0xf90(%r14)
   5a11b:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a121:	cmpb   $0x2,0x1078(%r14)
   5a129:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a12f:	cmpb   $0x2,0x1160(%r14)
   5a137:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a13d:	cmpb   $0x2,0x1248(%r14)
   5a145:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a14b:	cmpb   $0x2,0x1330(%r14)
   5a153:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a159:	cmpb   $0x2,0x1418(%r14)
   5a161:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a167:	cmpb   $0x2,0x1500(%r14)
   5a16f:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a175:	cmpb   $0x2,0x15e8(%r14)
   5a17d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a183:	cmpb   $0x2,0x16d0(%r14)
   5a18b:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a191:	cmpb   $0x2,0x17b8(%r14)
   5a199:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a19f:	cmpb   $0x2,0x18a0(%r14)
   5a1a7:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1ad:	cmpb   $0x2,0x1988(%r14)
   5a1b5:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1bb:	cmpb   $0x2,0x1a70(%r14)
   5a1c3:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1c9:	cmpb   $0x2,0x1b58(%r14)
   5a1d1:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1d7:	cmpb   $0x2,0x1c40(%r14)
   5a1df:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1e5:	cmpb   $0x2,0x1d28(%r14)
   5a1ed:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a1f3:	cmpb   $0x2,0x1e10(%r14)
   5a1fb:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a201:	cmpb   $0x2,0x1ef8(%r14)
   5a209:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a20f:	cmpb   $0x2,0x1fe0(%r14)
   5a217:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a21d:	cmpb   $0x2,0x20c8(%r14)
   5a225:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a22b:	cmpb   $0x2,0x21b0(%r14)
   5a233:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a239:	cmpb   $0x2,0x2298(%r14)
   5a241:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a247:	cmpb   $0x2,0x2380(%r14)
   5a24f:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a255:	cmpb   $0x2,0x2468(%r14)
   5a25d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a263:	cmpb   $0x2,0x2550(%r14)
   5a26b:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a271:	cmpb   $0x2,0x2638(%r14)
   5a279:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a27f:	cmpb   $0x2,0x2720(%r14)
   5a287:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a28d:	cmpb   $0x2,0x2808(%r14)
   5a295:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a29b:	cmpb   $0x2,0x28f0(%r14)
   5a2a3:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2a9:	cmpb   $0x2,0x29d8(%r14)
   5a2b1:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2b7:	cmpb   $0x2,0x2ac0(%r14)
   5a2bf:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2c5:	cmpb   $0x2,0x2ba8(%r14)
   5a2cd:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2d3:	cmpb   $0x2,0x2c90(%r14)
   5a2db:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2e1:	cmpb   $0x2,0x2d78(%r14)
   5a2e9:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2ef:	cmpb   $0x2,0x2e60(%r14)
   5a2f7:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a2fd:	cmpb   $0x2,0x2f48(%r14)
   5a305:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a30b:	cmpb   $0x2,0x3030(%r14)
   5a313:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a319:	cmpb   $0x2,0x3118(%r14)
   5a321:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a327:	cmpb   $0x2,0x3200(%r14)
   5a32f:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a335:	cmpb   $0x2,0x32e8(%r14)
   5a33d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a343:	cmpb   $0x2,0x33d0(%r14)
   5a34b:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a351:	cmpb   $0x2,0x34b8(%r14)
   5a359:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a35b:	cmpb   $0x2,0x35a0(%r14)
   5a363:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a365:	cmpb   $0x2,0x3688(%r14)
   5a36d:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a36f:	cmpb   $0x2,0x3770(%r14)
   5a377:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a379:	cmpb   $0x2,0x3858(%r14)
   5a381:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a383:	cmpb   $0x2,0x3940(%r14)
   5a38b:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a38d:	cmpb   $0x2,0x3a28(%r14)
   5a395:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a397:	cmpb   $0x2,0x3b10(%r14)
   5a39f:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a3a1:	cmpb   $0x2,0x3bf8(%r14)
   5a3a9:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a3ab:	cmpb   $0x2,0x3ce0(%r14)
   5a3b3:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a3b5:	cmpb   $0x2,0x3dc8(%r14)
   5a3bd:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a3bf:	cmpb   $0x2,0x3eb0(%r14)
   5a3c7:	je     5a3d9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a3c9:	movb   $0x5,0x8(%rax)
   5a3cd:	movq   $0x2,(%rax)
   5a3d4:	jmp    59f5a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   5a3d9:	movq   $0x1,(%rax)
   5a3e0:	mov    %rsi,0x8(%rax)
   5a3e4:	mov    %rdx,0x10(%rax)
   5a3e8:	jmp    59f5a <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
