
/tmp/penelope-timeline-current-paired/binary-diagnostics/before:     file format elf64-x86-64


Disassembly of section .text:

0000000000059b50 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission>:
   59b50:	movdqu (%rdx),%xmm0
   59b54:	movdqu 0x10(%rdx),%xmm1
   59b59:	movdqu 0x21eb8(%rsi),%xmm2
   59b61:	pcmpeqb %xmm0,%xmm2
   59b65:	movdqu 0x21ec8(%rsi),%xmm0
   59b6d:	pcmpeqb %xmm1,%xmm0
   59b71:	pand   %xmm2,%xmm0
   59b75:	pmovmskb %xmm0,%eax
   59b79:	cmp    $0xffff,%eax
   59b7e:	jne    59c17 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59b84:	movdqu 0x20(%rdx),%xmm0
   59b89:	movdqu 0x30(%rdx),%xmm1
   59b8e:	movdqu 0x21ed8(%rsi),%xmm2
   59b96:	pcmpeqb %xmm0,%xmm2
   59b9a:	movdqu 0x21ee8(%rsi),%xmm0
   59ba2:	pcmpeqb %xmm1,%xmm0
   59ba6:	pand   %xmm2,%xmm0
   59baa:	pmovmskb %xmm0,%eax
   59bae:	cmp    $0xffff,%eax
   59bb3:	jne    59c17 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59bb5:	movdqu 0x40(%rdx),%xmm0
   59bba:	movdqu 0x50(%rdx),%xmm1
   59bbf:	movdqu 0x21ef8(%rsi),%xmm2
   59bc7:	pcmpeqb %xmm0,%xmm2
   59bcb:	movdqu 0x21f08(%rsi),%xmm0
   59bd3:	pcmpeqb %xmm1,%xmm0
   59bd7:	pand   %xmm2,%xmm0
   59bdb:	pmovmskb %xmm0,%eax
   59bdf:	cmp    $0xffff,%eax
   59be4:	jne    59c17 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xc7>
   59be6:	movdqu 0x60(%rdx),%xmm0
   59beb:	movdqu 0x70(%rdx),%xmm1
   59bf0:	movdqu 0x21f18(%rsi),%xmm2
   59bf8:	pcmpeqb %xmm0,%xmm2
   59bfc:	movdqu 0x21f28(%rsi),%xmm0
   59c04:	pcmpeqb %xmm1,%xmm0
   59c08:	pand   %xmm2,%xmm0
   59c0c:	pmovmskb %xmm0,%eax
   59c10:	cmp    $0xffff,%eax
   59c15:	je     59c23 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xd3>
   59c17:	movb   $0x0,0x8(%rdi)
   59c1b:	movq   $0x2,(%rdi)
   59c22:	ret
   59c23:	push   %rbp
   59c24:	push   %r15
   59c26:	push   %r14
   59c28:	push   %r13
   59c2a:	push   %r12
   59c2c:	push   %rbx
   59c2d:	sub    $0x38,%rsp
   59c31:	mov    0xc0(%rdx),%r15
   59c38:	cmpl   $0x2,(%rsi)
   59c3b:	je     59c49 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0xf9>
   59c3d:	mov    %rsi,%rax
   59c40:	cmp    %r15,0x1c8(%rsi)
   59c47:	je     59c62 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x112>
   59c49:	cmpl   $0x2,0x1e8(%rsi)
   59c50:	je     59cbf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59c52:	cmp    %r15,0x3b0(%rsi)
   59c59:	jne    59cbf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59c5b:	lea    0x1e8(%rsi),%rax
   59c62:	mov    0xc8(%rdx),%r12
   59c69:	cmp    0x1d8(%rax),%r12
   59c70:	ja     59cbf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59c72:	cmp    0x21f38(%rsi),%r12
   59c79:	jb     59cbf <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x16f>
   59c7b:	mov    %r8d,%ebp
   59c7e:	mov    %rdi,%r13
   59c81:	mov    %rdx,%rbx
   59c84:	add    $0xa0,%rdx
   59c8b:	mov    %rsi,%r14
   59c8e:	mov    0x21f58(%rsi),%rax
   59c95:	mov    (%rcx),%rsi
   59c98:	lea    0x8(%rsp),%rdi
   59c9d:	mov    %rax,%rcx
   59ca0:	call   57010 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_payload::<timeline_operations::workload::State<1>>>
   59ca5:	cmpb   $0x1,0x8(%rsp)
   59caa:	jne    59cd9 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x189>
   59cac:	movzbl 0x9(%rsp),%eax
   59cb1:	mov    %al,0x8(%r13)
   59cb5:	movq   $0x2,0x0(%r13)
   59cbd:	jmp    59cca <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   59cbf:	movb   $0x3,0x8(%rdi)
   59cc3:	movq   $0x2,(%rdi)
   59cca:	add    $0x38,%rsp
   59cce:	pop    %rbx
   59ccf:	pop    %r12
   59cd1:	pop    %r13
   59cd3:	pop    %r14
   59cd5:	pop    %r15
   59cd7:	pop    %rbp
   59cd8:	ret
   59cd9:	mov    0x10(%rsp),%rax
   59cde:	mov    %rax,(%rsp)
   59ce2:	lea    0x3d0(%r14),%rcx
   59ce9:	lea    0x3eb8(%r14),%rax
   59cf0:	movq   $0x0,0x8(%rsp)
   59cf9:	movq   $0x0,0x18(%rsp)
   59d02:	lea    0x28(%rsp),%rdi
   59d07:	mov    %rcx,0x28(%rsp)
   59d0c:	mov    %rax,0x30(%rsp)
   59d11:	mov    %rbx,%rsi
   59d14:	call   57330 <<core::iter::adapters::fuse::Fuse<core::slice::iter::Iter<core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>> as core::iter::adapters::fuse::FuseImpl<core::slice::iter::Iter<core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>>>::try_fold::<(), core::iter::adapters::flatten::try_flatten_one<&core::option::Option<penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>, (), core::ops::control_flow::ControlFlow<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>, core::iter::traits::iterator::Iterator::find::check<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>, <penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<&penelope_timeline::history::StoredAnchor<timeline_operations::workload::State<1>>>>>
   59d19:	test   %rax,%rax
   59d1c:	je     59d50 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x200>
   59d1e:	mov    (%rsp),%rcx
   59d22:	cmp    %rcx,0xd8(%rax)
   59d29:	jne    59d3d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1ed>
   59d2b:	test   %bpl,%bpl
   59d2e:	je     59d39 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1e9>
   59d30:	cmpb   $0x1,0xe0(%rax)
   59d37:	jne    59d3d <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1ed>
   59d39:	xor    %eax,%eax
   59d3b:	jmp    59d47 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x1f7>
   59d3d:	movb   $0xd,0x8(%r13)
   59d42:	mov    $0x2,%eax
   59d47:	mov    %rax,0x0(%r13)
   59d4b:	jmp    59cca <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   59d50:	mov    (%rsp),%rsi
   59d54:	test   %bpl,%bpl
   59d57:	mov    %r13,%rax
   59d5a:	je     59dbe <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x26e>
   59d5c:	xor    %edx,%edx
   59d5e:	jmp    59d67 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x217>
   59d60:	add    $0x1d0,%rdx
   59d67:	cmpb   $0x1,0x4b0(%r14,%rdx,1)
   59d70:	jne    59d86 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x236>
   59d72:	cmp    %r15,0x490(%r14,%rdx,1)
   59d7a:	jne    59d86 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x236>
   59d7c:	cmp    %r12,0x498(%r14,%rdx,1)
   59d84:	je     59dae <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x25e>
   59d86:	cmp    $0x3a00,%rdx
   59d8d:	je     59dbe <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x26e>
   59d8f:	cmpb   $0x1,0x598(%r14,%rdx,1)
   59d98:	jne    59d60 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   59d9a:	cmp    %r15,0x578(%r14,%rdx,1)
   59da2:	jne    59d60 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   59da4:	cmp    %r12,0x580(%r14,%rdx,1)
   59dac:	jne    59d60 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x210>
   59dae:	movb   $0xd,0x8(%rax)
   59db2:	movq   $0x2,(%rax)
   59db9:	jmp    59cca <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   59dbe:	mov    0x21f48(%r14),%rdx
   59dc5:	add    %rsi,%rdx
   59dc8:	jb     5a139 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5e9>
   59dce:	cmp    0x21f60(%r14),%rdx
   59dd5:	ja     5a139 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5e9>
   59ddb:	cmpb   $0x2,0x4b0(%r14)
   59de3:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59de9:	cmpb   $0x2,0x598(%r14)
   59df1:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59df7:	cmpb   $0x2,0x680(%r14)
   59dff:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e05:	cmpb   $0x2,0x768(%r14)
   59e0d:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e13:	cmpb   $0x2,0x850(%r14)
   59e1b:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e21:	cmpb   $0x2,0x938(%r14)
   59e29:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e2f:	cmpb   $0x2,0xa20(%r14)
   59e37:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e3d:	cmpb   $0x2,0xb08(%r14)
   59e45:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e4b:	cmpb   $0x2,0xbf0(%r14)
   59e53:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e59:	cmpb   $0x2,0xcd8(%r14)
   59e61:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e67:	cmpb   $0x2,0xdc0(%r14)
   59e6f:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e75:	cmpb   $0x2,0xea8(%r14)
   59e7d:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e83:	cmpb   $0x2,0xf90(%r14)
   59e8b:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e91:	cmpb   $0x2,0x1078(%r14)
   59e99:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59e9f:	cmpb   $0x2,0x1160(%r14)
   59ea7:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ead:	cmpb   $0x2,0x1248(%r14)
   59eb5:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ebb:	cmpb   $0x2,0x1330(%r14)
   59ec3:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ec9:	cmpb   $0x2,0x1418(%r14)
   59ed1:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ed7:	cmpb   $0x2,0x1500(%r14)
   59edf:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ee5:	cmpb   $0x2,0x15e8(%r14)
   59eed:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ef3:	cmpb   $0x2,0x16d0(%r14)
   59efb:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f01:	cmpb   $0x2,0x17b8(%r14)
   59f09:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f0f:	cmpb   $0x2,0x18a0(%r14)
   59f17:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f1d:	cmpb   $0x2,0x1988(%r14)
   59f25:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f2b:	cmpb   $0x2,0x1a70(%r14)
   59f33:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f39:	cmpb   $0x2,0x1b58(%r14)
   59f41:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f47:	cmpb   $0x2,0x1c40(%r14)
   59f4f:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f55:	cmpb   $0x2,0x1d28(%r14)
   59f5d:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f63:	cmpb   $0x2,0x1e10(%r14)
   59f6b:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f71:	cmpb   $0x2,0x1ef8(%r14)
   59f79:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f7f:	cmpb   $0x2,0x1fe0(%r14)
   59f87:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f8d:	cmpb   $0x2,0x20c8(%r14)
   59f95:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59f9b:	cmpb   $0x2,0x21b0(%r14)
   59fa3:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fa9:	cmpb   $0x2,0x2298(%r14)
   59fb1:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fb7:	cmpb   $0x2,0x2380(%r14)
   59fbf:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fc5:	cmpb   $0x2,0x2468(%r14)
   59fcd:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fd3:	cmpb   $0x2,0x2550(%r14)
   59fdb:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fe1:	cmpb   $0x2,0x2638(%r14)
   59fe9:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59fef:	cmpb   $0x2,0x2720(%r14)
   59ff7:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   59ffd:	cmpb   $0x2,0x2808(%r14)
   5a005:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a00b:	cmpb   $0x2,0x28f0(%r14)
   5a013:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a019:	cmpb   $0x2,0x29d8(%r14)
   5a021:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a027:	cmpb   $0x2,0x2ac0(%r14)
   5a02f:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a035:	cmpb   $0x2,0x2ba8(%r14)
   5a03d:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a043:	cmpb   $0x2,0x2c90(%r14)
   5a04b:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a051:	cmpb   $0x2,0x2d78(%r14)
   5a059:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a05f:	cmpb   $0x2,0x2e60(%r14)
   5a067:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a06d:	cmpb   $0x2,0x2f48(%r14)
   5a075:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a07b:	cmpb   $0x2,0x3030(%r14)
   5a083:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a089:	cmpb   $0x2,0x3118(%r14)
   5a091:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a097:	cmpb   $0x2,0x3200(%r14)
   5a09f:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0a5:	cmpb   $0x2,0x32e8(%r14)
   5a0ad:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0b3:	cmpb   $0x2,0x33d0(%r14)
   5a0bb:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0c1:	cmpb   $0x2,0x34b8(%r14)
   5a0c9:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0cb:	cmpb   $0x2,0x35a0(%r14)
   5a0d3:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0d5:	cmpb   $0x2,0x3688(%r14)
   5a0dd:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0df:	cmpb   $0x2,0x3770(%r14)
   5a0e7:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0e9:	cmpb   $0x2,0x3858(%r14)
   5a0f1:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0f3:	cmpb   $0x2,0x3940(%r14)
   5a0fb:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a0fd:	cmpb   $0x2,0x3a28(%r14)
   5a105:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a107:	cmpb   $0x2,0x3b10(%r14)
   5a10f:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a111:	cmpb   $0x2,0x3bf8(%r14)
   5a119:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a11b:	cmpb   $0x2,0x3ce0(%r14)
   5a123:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a125:	cmpb   $0x2,0x3dc8(%r14)
   5a12d:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a12f:	cmpb   $0x2,0x3eb0(%r14)
   5a137:	je     5a149 <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x5f9>
   5a139:	movb   $0x5,0x8(%rax)
   5a13d:	movq   $0x2,(%rax)
   5a144:	jmp    59cca <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
   5a149:	movq   $0x1,(%rax)
   5a150:	mov    %rsi,0x8(%rax)
   5a154:	mov    %rdx,0x10(%rax)
   5a158:	jmp    59cca <<penelope_timeline::history::FixedHistory<timeline_operations::workload::State<1>, u64, 512, 65, 2>>::check_anchor_admission+0x17a>
