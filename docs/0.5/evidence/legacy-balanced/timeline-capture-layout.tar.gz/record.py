import json,hashlib,tarfile,statistics,subprocess
from pathlib import Path
root=Path('/home/ac/projects/penelope');raw=Path('/tmp/penelope-history-capture-layout');out=root/'docs/0.5/evidence/legacy-balanced'
m=json.loads((raw/'metadata.json').read_text());rows=[]
assert m['rounds']==15
for variant in ['before','after']:
 cells=[v for k,v in m['cells'].items() if k.startswith(variant)]
 assert len(cells)==4 and len({v['text_sha256'] for v in cells})==1
for label in m['cells']:
 runs=[json.loads((raw/f'round-{i}-{label}.json').read_text()) for i in range(1,16)]
 assert all(r['exit']==0 and len(r['observations'])==1 for r in runs)
 row={'label':label,**{k:statistics.median(r['observations'][0][k] for r in runs) for k in ['p50_ns','p95_ns','p99_ns']}}
 counters={}
 for event in ['instructions','cycles','task-clock']:
  values=[]
  for i in range(1,16):
   records=[json.loads(l) for l in (raw/f'round-{i}-{label}.perf.jsonl').read_text().splitlines() if l.strip()]
   entry=next(r for r in records if r['event']==event)
   assert 0<float(entry['pcnt-running'])<=100
   values.append(float(entry['counter-value']))
  counters[event]=statistics.median(values)
 row['whole_process_counters_median']=counters;rows.append(row)
(raw/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
files={str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
for p in Path('/tmp/penelope-history-capture-inspect').glob('*'):files['frozen-admission-inspection/'+p.name]=p
files['driver.py']=Path('/tmp/penelope-history-capture-layout.py');files['driver.log']=Path('/tmp/penelope-history-capture-layout.log');files['record.py']=Path(__file__)
archive=out/'timeline-capture-layout.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name)
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(hashes)
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
manifest={'scope':'Diagnostic-only filtered original workload helper; not frozen benchmark replacement, no performance acceptance','revisions':{k:v['revision'] for k,v in m['sources'].items()},'rounds_per_cell':15,'cells':8,'samples_per_process':10000,'summary':rows,'text_identity':'Each source variant retains identical .text bytes at all four linked placements; before and after code differ.','frozen_binary_inspection':'Original retained check_anchor_admission functions each have 284 instructions and size 0x60d; assembly is identical after normalizing addresses and RIP-relative relocation displacements. This is scoped instruction comparison, not whole-executable equivalence.','conditions':'CPU4; shared host frequency, caches and memory bandwidth uncontrolled. Whole-process counters include original fixture construction and reporting, not capture alone.','conclusion':'Changing placement alters elapsed time and reverses which source is faster in the focused fixture. This demonstrates layout sensitivity; exact microarchitectural cause and frozen workload findings remain open. No production linker setting or safety-check removal.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':hashes}
(out/'timeline-capture-layout.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified members',len(hashes),'archive bytes',archive.stat().st_size)
