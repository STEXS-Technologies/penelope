#[path = "support/workload.rs"]
mod workload;
struct Focus(workload::Latency);
impl workload::Reporter for Focus {
    fn sample<T, R>(&mut self, name: &str, words: usize, steps: usize,
        setup: impl FnMut() -> T, operation: impl FnMut(&mut T) -> R) {
        if name == "history_capture" && words == 1 && steps == 1 {
            self.0.sample(name, words, steps, setup, operation);
        }
    }
}
fn main() { workload::run(Focus(workload::Latency::new())); }
