import os,subprocess,json,hashlib,shutil,importlib.util
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-history-capture-layout');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{4,5,6,7})
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','PENELOPE_TIMELINE_SAMPLES':'10000'}
spec=importlib.util.spec_from_file_location('benchmark',root/'scripts/benchmark-decision-comparison.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
main='''#[path = "support/workload.rs"]
mod workload;
struct Focus(workload::Latency);
impl workload::Reporter for Focus {
    fn sample<T, R>(&mut self, name: &str, words: usize, steps: usize,
        setup: impl FnMut() -> T, operation: impl FnMut(&mut T) -> R) {
        if name == "history_capture" && words == 1 && steps == 1 {
            self.0.sample(name, words, steps, setup, operation);
        }
    }
}
fn main() { workload::run(Focus(workload::Latency::new())); }
'''
metadata={'rounds':15,'samples_per_process':10000,'cpu':4,'scope':'Temporary same-helper single-profile placement diagnostic, not replacement frozen benchmark','cells':{},'sources':{}}
binaries={}
for variant,revision in [('before','42ec187c9adfc7403b06215f405f2575f53c35c2'),('after','208acf0')]:
 repo=Path('/tmp/penelope-history-capture-'+variant)
 subprocess.run(['git','worktree','add','--detach',str(repo),revision],cwd=root,check=True,capture_output=True)
 manifest=repo/'crates/penelope-timeline/Cargo.toml';manifest.write_text(manifest.read_text()+'\n[[bench]]\nname = "capture_focus"\nharness = false\n')
 (repo/'crates/penelope-timeline/benches/capture_focus.rs').write_text(main)
 metadata['sources'][variant]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'helper_sha256':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'crates/penelope-timeline/benches/support').glob('*.rs')}}
 (out/(variant+'-patch.diff')).write_bytes(subprocess.check_output(['git','diff'],cwd=repo))
 (out/'capture_focus.rs').write_text(main)
 buildenv={**env,'CARGO_TARGET_DIR':str(root/'target/history-capture-layout'/variant)}
 for address in ['20000','20020','20040','20060']:
  label=variant+'-'+address;print('build',label,flush=True)
  args=['cargo','+1.100.0','rustc','--locked','-p','penelope-timeline','--bench','capture_focus','--profile','bench','--message-format=json','--','-C','link-arg=-Wl,--section-start=.text=0x'+address]
  r=subprocess.run(args,cwd=repo,env=buildenv,capture_output=True,text=True);(out/(label+'-build.jsonl')).write_text(r.stdout);(out/(label+'-build.stderr')).write_text(r.stderr);r.check_returncode()
  found=[x['executable'] for x in map(json.loads,r.stdout.splitlines()) if x.get('reason')=='compiler-artifact' and x['target']['name']=='capture_focus' and x.get('executable')];assert len(found)==1
  dest=out/label.ljust(32,'_');shutil.copy2(found[0],dest);binaries[label]=str(dest)
  # Explicit output keeps the measured input binary unchanged.
  text=out/(label+'.text');transformed=out/(label+'.objcopy-output')
  subprocess.run(['objcopy','--dump-section','.text='+str(text),str(dest),str(transformed)],check=True)
  (out/(label+'-sections')).write_bytes(subprocess.check_output(['readelf','-SW',dest]))
  (out/(label+'-symbols')).write_bytes(subprocess.check_output(['nm','-SC',dest]))
  metadata['cells'][label]={'build_args':args,'binary_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'text_sha256':hashlib.sha256(text.read_bytes()).hexdigest(),'text_bytes':text.stat().st_size}
  r=subprocess.run(['taskset','-c','4',dest],env=env,capture_output=True,text=True);r.check_returncode();(out/(label+'-warmup.stdout')).write_text(r.stdout)
assert metadata['sources']['before']['helper_sha256']==metadata['sources']['after']['helper_sha256']
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
for i in range(1,16):
 labels=list(binaries);offset=(i*3)%len(labels);labels=labels[offset:]+labels[:offset]
 for label in labels:
  dest=Path(binaries[label]);assert hashlib.sha256(dest.read_bytes()).hexdigest()==metadata['cells'][label]['binary_sha256']
  counter=out/f'round-{i}-{label}.perf.jsonl'
  r=subprocess.run(['perf','stat','-j','-e','instructions,cycles,task-clock,context-switches,cpu-migrations','-o',str(counter),'--','taskset','-c','4',dest],env=env,capture_output=True,text=True)
  observed=helper.timeline_observations(r.stdout)
  assert len(observed)==1 and observed[0]['operation']=='history_capture' and observed[0]['state_words']==1 and observed[0]['steps']==1 and observed[0]['samples']==10000
  (out/f'round-{i}-{label}.json').write_text(json.dumps({'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observations':observed},indent=2)+'\n');r.check_returncode()
 print('round',i,flush=True)
print('completed',flush=True)
