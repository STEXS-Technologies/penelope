import pathlib,subprocess,json,hashlib,os,shutil,time,datetime
P=pathlib.Path;r=P('/home/ac/projects/.penelope-sqlite-qpsg-probe');out=P('/tmp/penelope-050-qpsg-qualification-followup');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','PENELOPE_BENCH_DIR':'/home/ac/projects/penelope/target/versioned-sqlite-data','TMPDIR':'/home/ac/projects/penelope/target/versioned-sqlite-data'}
targets={'1.100.0':'/home/ac/projects/penelope/target/sqlite-qpsg-probe','1.89.0':'/home/ac/projects/penelope/target/candidate-capability-performance/1.89.0'}
specs=[('machine_store',['-p','penelope-sqlite']),('machine_backpressure',['-p','penelope-sqlite']),('native_pipeline',['--manifest-path','ci/machine-consumer/Cargo.toml','--features','protected'])]
tracked=subprocess.check_output(['git','ls-files','--','crates','ci','fuzz','scripts','.github','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=r,text=True).splitlines()
def hashes():return {p:hashlib.sha256(os.readlink(r/p).encode() if (r/p).is_symlink() else (r/p).read_bytes()).hexdigest() for p in tracked}
meta={'status':'running','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'source_pre':hashes(),'source_diff':subprocess.check_output(['git','diff','HEAD'],cwd=r,text=True),'checks':[],'binaries':{},'scope':'Isolated three-line QPSG probe; stable and MSRV checks, three rotating stable comparison pairs of existing full machine_store/backpressure/native_pipeline fixtures, one MSRV run each. No final release qualification.','conditions':'CPU4 except machine_store4-7; builds/tests complete before timing. NVMe Btrfs data. Both chaos campaigns8-15/16-23 and shared host remain uncontrolled. Retained original candidate binaries from versioned capability refresh.','environment':{k:env.get(k) for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','PENELOPE_BENCH_DIR','TMPDIR']}}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(label,cmd,version='1.100.0'):
 print(label,flush=True);start=time.monotonic()
 with (out/(label+'.stdout')).open('w') as o,(out/(label+'.stderr')).open('w') as e:res=subprocess.run(cmd,cwd=r,env={**env,'CARGO_TARGET_DIR':targets[version]},stdout=o,stderr=e)
 meta['checks'].append({'label':label,'args':cmd,'exit_code':res.returncode,'seconds':time.monotonic()-start});save();res.check_returncode();return (out/(label+'.stdout')).read_text()
try:
 save()
 run('fmt',['cargo','+1.100.0','fmt','--all','--','--check'])
 run('clippy',['taskset','-c','4-7','cargo','+1.100.0','clippy','-p','penelope-sqlite','--all-targets','--all-features','--locked','--','-D','warnings'])
 for v in ['1.100.0','1.89.0']:
  for name,args in specs:
   raw=run('build-'+v+'-'+name,['taskset','-c','4-7','cargo','+'+v,'bench','--locked','--no-run','--message-format=json','--bench',name]+args,v)
   binaries=[x['executable'] for line in raw.splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x['target']['name']==name and x.get('executable')];assert len(binaries)==1
   b=out/(v+'-'+name+'.bin');shutil.copy2(binaries[0],b);meta['binaries'][v+'-'+name]={'file':b.name,'sha256':hashlib.sha256(b.read_bytes()).hexdigest()};save()
 for name,_ in specs:
  b=P('/tmp/penelope-050-capability-performance')/('1.100.0-'+name+'.bin');copy=out/('current-'+name+'.bin');shutil.copy2(b,copy);meta['binaries']['current-'+name]={'file':copy.name,'sha256':hashlib.sha256(copy.read_bytes()).hexdigest()}
 save()
 for n in range(3):
  rotated=specs[n:]+specs[:n]
  for name,_ in rotated:
   for variant in (['current','probe'] if n%2==0 else ['probe','current']):
    b=out/(('current-' if variant=='current' else '1.100.0-')+name+'.bin');label=f'run-{n+1}-{variant}-{name}'
    raw=run(label,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S}','-o',str(out/(label+'.resources.json')),'taskset','-c','4-7' if name=='machine_store' else '4',str(b)])
    if name!='native_pipeline':
     d=json.loads(raw);assert d['measurement_mode']=='release-101' and d['journal_mode']=='WAL' and d['synchronous']=='FULL';assert all(x['measured_rounds']==101 for x in d['profiles'])
    else:assert sum(l.startswith('native_pipeline_summary,') for l in raw.splitlines())==12
 for name,_ in specs:
  label='msrv-run-'+name;run(label,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e}','-o',str(out/(label+'.resources.json')),'taskset','-c','4-7' if name=='machine_store' else '4',str(out/('1.89.0-'+name+'.bin'))],'1.89.0')
 meta['source_post']=hashes();assert meta['source_post']==meta['source_pre']
 for b in meta['binaries'].values():assert hashlib.sha256((out/b['file']).read_bytes()).hexdigest()==b['sha256']
 meta['status']='completed';save();print('Completed',flush=True)
except BaseException as error:meta['status']='failed';meta['error']=repr(error);save();raise
