import json,pathlib,statistics
p=pathlib.Path('/tmp/penelope-050-qpsg-qualification-followup');m=json.loads((p/'metadata.json').read_text());assert m['status']=='completed'
def metrics(name,path):
 if name=='native_pipeline':
  lines=[l.split(',') for l in path.read_text().splitlines() if l.startswith('native_pipeline_')]
  result={r[1]+'/'+k:int(r[i]) for r in lines if r[0]=='native_pipeline_summary' for k,i in [('p50_ns',3),('p95_ns',4),('p99_ns',5)]}
  totals=sorted(int(r[3]) for r in lines if r[0]=='native_pipeline_total' and r[-1]=='false');assert len(totals)==101
  result.update({'outer_iteration_total/'+k:totals[i] for k,i in [('p50_ns',50),('p95_ns',95),('p99_ns',99)]})
  return result
 d=json.loads(path.read_text());result={}
 for c in d['profiles']:
  dims='writers='+str(c['writers']) if name=='machine_store' else 'queue='+str(c['queue_capacity'])+',burst='+str(c['requests_per_round'])
  for op,v in c.items():
   if isinstance(v,dict):
    for k,x in v.items():
     if k in ['p50_ns','p95_ns','p99_ns']:result[dims+'/'+op+'/'+k]=x
 return result
rows=[]
for name in ['machine_store','machine_backpressure','native_pipeline']:
 ss={v:[metrics(name,p/f'run-{i}-{v}-{name}.stdout') for i in range(1,4)] for v in ['current','probe']};keys=set(ss['current'][0]);assert all(set(x)==keys for group in ss.values() for x in group)
 for k in sorted(keys):
  samples={v:[x[k] for x in xs] for v,xs in ss.items()};med={v:statistics.median(xs) for v,xs in samples.items()};th=5 if k.endswith('/p50_ns') else 10 if k.endswith('/p95_ns') else None
  rows.append({'benchmark':name,'metric':k,'samples':samples,'median_run_quantiles':med,'delta_percent':100*(med['probe']/med['current']-1) if med['current'] else None,'review_threshold_percent':th,'descriptive_flag':th is not None and 100*med['probe']>(100+th)*med['current']})
s={'scope':'Three paired stable processes per full existing fixture, median of per-run quantiles, all descriptive threshold findings retained. Not pooled percentiles, significance or universal equivalence. MSRV runs test compatibility and are excluded from timing summary.','rows':rows,'flags':[x for x in rows if x['descriptive_flag']]};(p/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for x in rows:
 if x['metric'].endswith('/p50_ns') and (x['benchmark']=='native_pipeline' and 'outer' in x['metric'] or x['benchmark']=='machine_store' and any(t in x['metric'] for t in ['/commit/','/release_to_last_finish/'])):print(x['benchmark'],x['metric'],x['median_run_quantiles'],x['delta_percent'])
print('metrics',len(rows),'descriptive flags',len(s['flags']))
