import hashlib,json,os,pathlib,shutil,subprocess,time
P=pathlib.Path
out=P('/tmp/penelope-050-versioned-sqlite');out.mkdir(exist_ok=False)
repos={'before':P('/tmp/penelope-v040-baseline'),'after':P('/home/ac/projects/.penelope-050-performance')}
targets={'before':P('/home/ac/projects/penelope/target/sqlite-performance-before'),'after':P('/home/ac/projects/penelope/target/candidate-capability-performance/1.100.0')}
data=P('/home/ac/projects/penelope/target/versioned-sqlite-data');data.mkdir(exist_ok=True)
os.sched_setaffinity(0,{4,5,6,7})
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','PENELOPE_BENCH_DIR':str(data)}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source(r):
 names=subprocess.check_output(['git','ls-files'],cwd=r,text=True).splitlines()
 return {n:hashlib.sha256(os.readlink(r/n).encode() if (r/n).is_symlink() else (r/n).read_bytes()).hexdigest() for n in names if n.startswith(('crates/','ci/','fuzz/','scripts/','.github/')) or n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
def run(cmd,name,**kw):
 with (out/(name+'.stdout')).open('w') as o,(out/(name+'.stderr')).open('w') as e:
  subprocess.run(cmd,stdout=o,stderr=e,check=True,**kw)
source_before={k:source(r) for k,r in repos.items()}
assert (repos['before']/'crates/penelope-sqlite/benches/durable_store.rs').read_bytes()==(repos['after']/'crates/penelope-sqlite/benches/durable_store.rs').read_bytes()
meta={'status':'running','rounds':31,'warmup_pairs':1,'order':'alternating revision order; warmup excluded only from summary','revisions':{k:subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip() for k,r in repos.items()},'source_pre':source_before,'environment':{k:env.get(k) for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS']},'measurement_cpus':[4],'build_cpus':[4,5,6,7],'shared_host':'Both existing chaos campaigns remain active on CPUs8-15 and16-23; cache,frequency,thermal,storage and unrelated activity uncontrolled.','data_parent':str(data),'scope':'Unchanged fixture and independent locked dependencies; 10 warm/reopen replay samples per dataset, no rare-tail guarantee, no physical disk-write or WAL-size instrumentation.'}
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
run(['rustc','+1.100.0','-vV'],'rustc',env=env)
run(['findmnt','-J','-T',str(data)],'filesystem',env=env)
bins={}
for label,r in repos.items():
 assert not subprocess.check_output(['git','diff','HEAD','--'],cwd=r)
 print('Build',label,flush=True)
 run(['cargo','+1.100.0','bench','-p','penelope-sqlite','--bench','durable_store','--locked','--no-run','--message-format=json'],'build-'+label,cwd=r,env={**env,'CARGO_TARGET_DIR':str(targets[label])})
 artifacts=[x['executable'] for line in (out/('build-'+label+'.stdout')).read_text().splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x['target']['name']=='durable_store' and x.get('executable')]
 assert len(artifacts)==1
 b=out/('durable_store-'+label);shutil.copy2(artifacts[0],b);bins[label]=b
 run(['readelf','-SW',str(b)],'sections-'+label,env=env)
meta['binaries']={k:{'file':v.name,'sha256':sha(v),'bytes':v.stat().st_size} for k,v in bins.items()}
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for n in range(32):
 for label in (['before','after'] if n%2==0 else ['after','before']):
  name=('warmup' if n==0 else f'round-{n}')+'-'+label
  cmd=['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S}','-o',str(out/(name+'.resources.json')),'taskset','-c','4',str(bins[label])]
  run(cmd,name,cwd=repos[label],env=env)
  report=json.loads((out/(name+'.stdout')).read_text());assert report['journal_mode']=='WAL' and report['synchronous']=='FULL';assert [x['records'] for x in report['tasks']]==[16,128,512]
 print('Completed pair',n,flush=True)
meta['source_post']={k:source(r) for k,r in repos.items()};assert meta['source_post']==source_before
for k,b in bins.items():assert sha(b)==meta['binaries'][k]['sha256']
meta['status']='completed';meta['tracked_diff_post']={k:subprocess.check_output(['git','diff','HEAD','--'],cwd=r,text=True) for k,r in repos.items()};assert not any(meta['tracked_diff_post'].values())
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Completed and source verified',flush=True)
