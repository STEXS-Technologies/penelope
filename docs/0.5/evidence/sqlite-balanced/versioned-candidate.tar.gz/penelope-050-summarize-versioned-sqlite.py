import json,pathlib,statistics
p=pathlib.Path('/tmp/penelope-050-versioned-sqlite')
def leaves(x,path=''):
 if isinstance(x,dict):
  for k,v in x.items():yield from leaves(v,path+'/'+k)
 elif isinstance(x,list):
  for k,v in enumerate(x):yield from leaves(v,path+'/'+str(k))
 elif isinstance(x,(int,float)) and path.endswith(('_ns','_kib','_seconds')):yield path,x
samples={l:[] for l in ['before','after']}
for l in samples:
 for n in range(1,32):
  d=dict(leaves(json.loads((p/f'round-{n}-{l}.stdout').read_text())))
  d.update(dict(leaves(json.loads((p/f'round-{n}-{l}.resources.json').read_text()))));samples[l].append(d)
keys=set(samples['before'][0]);assert all(set(d)==keys for ss in samples.values() for d in ss)
rows=[]
for k in sorted(keys):
 b,a=([d[k] for d in samples[l]] for l in samples);bm,am=map(statistics.median,[b,a]);threshold=5 if k.endswith('/p50_ns') else 10 if k.endswith('/p95_ns') else None
 rows.append({'metric':k,'before':b,'after':a,'median_before':bm,'median_after':am,'absolute_delta':am-bm,'median_delta_percent':100*(am/bm-1) if bm else None,'review_threshold_percent':threshold,'review_flag':threshold is not None and 100*am>(100+threshold)*bm,'paired_threshold_exceedances':sum(100*y>(100+threshold)*x for x,y in zip(b,a)) if threshold is not None else None})
s={'pairs':31,'rows':rows,'review_flags':[x for x in rows if x['review_flag']],'limits':'Medians of31 reported run percentiles, not pooled percentiles, confidence bounds or equivalence. Each replay percentile uses only10 samples per process. Single database-open samples are not percentiles. Full warmup pair retained/excluded from summary. All p50/p95 flags retained under strict integer cross-multiplication; p99/resources descriptive only.'}
(p/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for x in rows:
 if x['metric'].endswith('/p50_ns'): print(x['metric'],x['median_before'],x['median_after'],round(x['median_delta_percent'],2),x['paired_threshold_exceedances'])
print('metrics',len(rows),'flags',len(s['review_flags']))
