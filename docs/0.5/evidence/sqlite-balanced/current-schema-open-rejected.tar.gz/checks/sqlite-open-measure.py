import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/penelope')
probe=Path('/home/ac/projects/.penelope-pre-pr-sqlite-open-probe')
out=Path('/tmp/penelope-pre-pr-sqlite-open-measure')
out.mkdir(exist_ok=False)
data=root/'target/perf-data-pre-pr-sqlite-open'
data.mkdir(exist_ok=False)
artifacts=[json.loads(l) for l in Path('/tmp/penelope-pre-pr-sqlite-open-build.jsonl').read_text().splitlines() if l.startswith('{')]
exe=next(Path(x['executable']) for x in artifacts if x.get('executable') and x.get('target',{}).get('name')=='durable_store')
binaries={'original':Path('/tmp/penelope-050-sqlite-post-qpsg-candidate/binaries/before'),'candidate':Path('/tmp/penelope-050-sqlite-post-qpsg-candidate/binaries/after'),'probe':exe}
fixture='crates/penelope-sqlite/benches/durable_store.rs'
assert (root/fixture).read_bytes()==(probe/fixture).read_bytes()
patch=subprocess.check_output(['git','diff','HEAD','--','crates/penelope-sqlite'],cwd=probe)
(out/'probe.patch').write_bytes(patch)
meta={'rounds':31,'warmups':1,'cpu':4,'fixture_sha256':hashlib.sha256((probe/fixture).read_bytes()).hexdigest(),'probe_schema_sha256':hashlib.sha256((probe/'crates/penelope-sqlite/src/schema.rs').read_bytes()).hexdigest(),'binaries_sha256':{},'storage':'Same NVMe/Btrfs target parent; WAL/FULL; no fsync bypass; OS cache uncontrolled','queued_after_timeline_pid':3241335}
for label,path in binaries.items():
 shutil.copy2(path,out/(label+'.bin'));meta['binaries_sha256'][label]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Waiting for running timeline comparison PID 3241335',flush=True)
while True:
 try:os.kill(3241335,0)
 except ProcessLookupError:break
 time.sleep(2)
labels=list(binaries)
for i in range(32):
 for label in labels[i%3:]+labels[:i%3]:
  name=('warmup' if i==0 else f'round-{i:02d}')+'-'+label
  print(name,flush=True)
  start=time.monotonic()
  r=subprocess.run(['taskset','-c','4',str(out/(label+'.bin'))],env={**os.environ,'PENELOPE_BENCH_DIR':str(data)},capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  (out/(name+'.result.json')).write_text(json.dumps({'exit_code':r.returncode,'wall_seconds':time.monotonic()-start})+'\n')
  r.check_returncode();report=json.loads(r.stdout)
  assert report['journal_mode']=='WAL' and report['synchronous']=='FULL'
for label,digest in meta['binaries_sha256'].items():assert hashlib.sha256((out/(label+'.bin')).read_bytes()).hexdigest()==digest
assert hashlib.sha256((probe/'crates/penelope-sqlite/src/schema.rs').read_bytes()).hexdigest()==meta['probe_schema_sha256']
print('31 rotating triples complete; source and binaries unchanged',flush=True)
