import json,statistics
from fractions import Fraction
from pathlib import Path
raw=Path('/tmp/penelope-pre-pr-sqlite-open-measure')
def metrics(value,path=''):
 rows={}
 if isinstance(value,dict):
  for k,v in value.items():
   if k in ('p50_ns','p95_ns','p99_ns') and isinstance(v,(int,float)):rows[path+'/'+k]=v
   else:rows.update(metrics(v,path+'/'+k))
 elif isinstance(value,list):
  for i,v in enumerate(value):rows.update(metrics(v,path+'/'+str(i)))
 return rows
samples={label:[metrics(json.loads((raw/f'round-{i:02d}-{label}.json').read_text())) for i in range(1,32)] for label in ('original','candidate','probe')}
keys=samples['original'][0].keys();assert len(keys)==36
assert all(row.keys()==keys for rows in samples.values() for row in rows)
rows=[]
for key in keys:
 values={label:[sample[key] for sample in group] for label,group in samples.items()}
 medians={label:statistics.median(v) for label,v in values.items()}
 threshold=5 if key.endswith('p50_ns') else 10 if key.endswith('p95_ns') else None
 flags={label:threshold is not None and Fraction(str(medians['probe']))*100>Fraction(str(medians[label]))*(100+threshold) for label in ('original','candidate')}
 rows.append({'metric':key,'samples':values,'medians':medians,'probe_delta_percent':{label:(medians['probe']/medians[label]-1)*100 for label in flags},'review_flags':flags,'paired_threshold_exceedances':{label:sum(Fraction(a)*100>Fraction(b)*(100+threshold) for a,b in zip(values['probe'],values[label])) if threshold else None for label in flags}})
record={'rounds':31,'metrics':rows,'flags':{label:sum(row['review_flags'][label] for row in rows) for label in ('original','candidate')},'limits':['Only ten replay observations per process; 16-record append p95 is max of fourteen observations.','Shared host, uncontrolled frequency and OS cache; no equivalence, isolation or acceptance claim.']}
(raw/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['flags'])
for row in rows:
 if 'reopen' in row['metric'] and row['metric'].endswith('p50_ns') or row['review_flags']['original']:print(row['metric'],row['medians'],row['probe_delta_percent'])
