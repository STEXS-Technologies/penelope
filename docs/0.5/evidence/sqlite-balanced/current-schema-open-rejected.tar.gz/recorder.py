import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/penelope');raw=Path('/tmp/penelope-pre-pr-sqlite-open-measure')
meta=json.loads((raw/'metadata.json').read_text());summary=json.loads((raw/'summary.json').read_text());assert len(summary['metrics'])==36 and summary['rounds']==31
probe=Path('/home/ac/projects/.penelope-pre-pr-sqlite-open-probe')
(raw/'probe.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','crates'],cwd=probe))
files={str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
for name in ['sqlite-open-measure.py','sqlite-open-build.jsonl','sqlite-open-build.stderr','sqlite-open-tests-final-stable.log','sqlite-open-tests-final-msrv.log','sqlite-open-negative-control.log']:
 p=Path('/tmp/penelope-pre-pr-'+name);assert p.is_file();files['checks/'+name]=p
files['summarize.py']=Path('/tmp/penelope-summarize-sqlite-open-probe.py');files['recorder.py']=Path(__file__)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={n:sha(p) for n,p in files.items()};dest=root/'docs/0.5/evidence/sqlite-balanced/current-schema-open-rejected.tar.gz'
with tarfile.open(dest,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(dest) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
record={'base_commit':'7ab93d2cbb426f1e058fb7abc76c42c3f8582178','scope':'Isolated current-schema read preflight before acquiring migration writer lock. Rejected, not integrated. Full durability configuration and version recheck for all noncurrent versions retained.','metadata':meta,'results':summary,'checks':'61 SQLite unit tests passed on stable and MSRV. Held-writer test fails with original schema, passes with probe; future-version writer-lock admission and corruption refusal preserved.','disposition':'Reject: only 1.34% improvement in 16-record reopen/replay p50 relative to candidate; still 7.06% slower than original 0.4. This does not fix the performance finding. No acceptance granted.','archive':{'file':dest.name,'sha256':sha(dest),'members_sha256':hashes}}
(root/'docs/0.5/evidence/sqlite-balanced/current-schema-open-rejected.json').write_text(json.dumps(record,indent=2)+'\n')
print('Rejected SQLite open experiment retained with verified archive')
