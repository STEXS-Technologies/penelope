import pathlib,json,hashlib,os,shutil,subprocess,time
P=pathlib.Path;r=P('/home/ac/projects/.penelope-sqlite-qpsg-probe');out=P('/tmp/penelope-050-qpsg-balanced');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/sqlite-qpsg-probe','PENELOPE_BENCH_DIR':'/home/ac/projects/penelope/target/versioned-sqlite-data','TMPDIR':'/home/ac/projects/penelope/target/versioned-sqlite-data'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads(P('/tmp/penelope-050-qpsg-qualification-followup/metadata.json').read_text());assert prior['status']=='completed'
def sources():return {p:hashlib.sha256(os.readlink(r/p).encode() if (r/p).is_symlink() else (r/p).read_bytes()).hexdigest() for p in prior['source_pre']}
assert sources()==prior['source_post']
meta={'status':'running','source_commit':prior['source_commit'],'source_diff':prior['source_diff'],'source_pre':sources(),'environment':{k:env.get(k) for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','PENELOPE_BENCH_DIR','TMPDIR']},'build_cpus':[4,5,6,7],'measurement_cpus':[4],'legacy_rounds':31,'native_pairs':15,'warmup_legacy_triples':1,'warmup_native_pairs':1,'order':'Legacy rotate original/current/probe; native alternate current/probe. Whole warmup triple/pair retained separately. Fixtures also retain their original internal warmups.','conditions':'Shared host, active chaos on8-15/16-23, uncontrolled storage/cache/frequency/thermals; NVMe Btrfs. All builds complete before timing.','checks':[],'binaries':{}}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(label,cmd):
 print(label,flush=True);start=time.monotonic()
 with (out/(label+'.stdout')).open('w') as o,(out/(label+'.stderr')).open('w') as e:res=subprocess.run(cmd,cwd=r,env=env,stdout=o,stderr=e)
 meta['checks'].append({'label':label,'args':cmd,'exit_code':res.returncode,'seconds':time.monotonic()-start});save();res.check_returncode();return (out/(label+'.stdout')).read_text()
def retain(label,p,expected=None):
 b=out/(label+'.bin');shutil.copy2(p,b);h=sha(b)
 if expected:assert h==expected
 meta['binaries'][label]={'file':b.name,'sha256':h,'bytes':b.stat().st_size};save();return b
try:
 save();raw=run('build-durable',['taskset','-c','4-7','cargo','+1.100.0','bench','-p','penelope-sqlite','--bench','durable_store','--locked','--no-run','--message-format=json']);arts=[x['executable'] for l in raw.splitlines() if (x:=json.loads(l)).get('reason')=='compiler-artifact' and x['target']['name']=='durable_store' and x.get('executable')];assert len(arts)==1
 legacy={'probe':retain('legacy-probe',P(arts[0]))};old=json.loads(P('/tmp/penelope-050-versioned-sqlite/metadata.json').read_text())
 for label,key in [('original','before'),('current','after')]:legacy[label]=retain('legacy-'+label,P('/tmp/penelope-050-versioned-sqlite')/old['binaries'][key]['file'],old['binaries'][key]['sha256'])
 legacy={k:legacy[k] for k in ['original','current','probe']}
 native={}
 for label,key in [('current','current-native_pipeline'),('probe','1.100.0-native_pipeline')]:
  x=prior['binaries'][key];native[label]=retain('native-'+label,P('/tmp/penelope-050-qpsg-qualification-followup')/x['file'],x['sha256'])
 for n in range(32):
  labels=list(legacy);labels=labels[n%3:]+labels[:n%3]
  for label in labels:
   name=('legacy-warmup' if not n else f'legacy-{n}')+'-'+label
   raw=run(name,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S}','-o',str(out/(name+'.resources.json')),'taskset','-c','4',str(legacy[label])]);d=json.loads(raw);assert d['journal_mode']=='WAL' and d['synchronous']=='FULL';assert [c['records'] for c in d['tasks']]==[16,128,512]
 for n in range(16):
  for label in (['current','probe'] if n%2==0 else ['probe','current']):
   name=('native-warmup' if not n else f'native-{n}')+'-'+label
   raw=run(name,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S}','-o',str(out/(name+'.resources.json')),'taskset','-c','4',str(native[label])]);lines=[l.split(',') for l in raw.splitlines() if l.startswith('native_pipeline_')];assert sum(x[0]=='native_pipeline_summary' for x in lines)==12;assert sum(x[0]=='native_pipeline_total' for x in lines)==109;assert sum(x[0]=='native_pipeline_total' and x[-1]=='false' for x in lines)==101
 for x in meta['binaries'].values():assert sha(out/x['file'])==x['sha256']
 meta['source_post']=sources();assert meta['source_post']==meta['source_pre'];meta['status']='completed';save();print('Completed',flush=True)
except BaseException as err:meta['status']='failed';meta['error']=repr(err);save();raise
