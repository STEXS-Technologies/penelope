import pathlib,json,statistics,math,random
P=pathlib.Path;p=P('/tmp/penelope-050-qpsg-balanced');m=json.loads((p/'metadata.json').read_text());assert m['status']=='completed'
def leaves(x,k=''):
 if isinstance(x,dict):
  for a,b in x.items():yield from leaves(b,k+'/'+a)
 elif isinstance(x,list):
  for a,b in enumerate(x):yield from leaves(b,k+'/'+str(a))
 elif isinstance(x,(int,float)) and k.endswith(('_ns','_kib','_seconds')):yield k,x
rows=[]
def compare(bench,ss,b,a):
 keys=set(ss[b][0]);assert all(set(x)==keys for group in ss.values() for x in group)
 for k in sorted(keys):
  vals={v:[x[k] for x in ss[v]] for v in [b,a]};bm,am=[statistics.median(vals[v]) for v in [b,a]];th=5 if k.endswith('/p50_ns') else 10 if k.endswith('/p95_ns') else None;ratios=[y/x for x,y in zip(vals[b],vals[a]) if x]
  row={'benchmark':bench,'before':b,'after':a,'metric':k,'samples':vals,'median_before':bm,'median_after':am,'median_delta_percent':100*(am/bm-1) if bm else None,'absolute_delta':am-bm,'threshold_percent':th,'review_flag':th is not None and 100*am>(100+th)*bm,'paired_threshold_exceedances':sum(100*y>(100+th)*x for x,y in zip(vals[b],vals[a])) if th is not None else None,'paired_median_delta_percent':100*(statistics.median(ratios)-1) if ratios else None}
  if k.endswith(('/p50_ns','/p95_ns')) and len(ratios)==len(vals[b]):
   logs=list(map(math.log,ratios));rng=random.Random(1);boots=sorted(math.expm1(statistics.mean(rng.choices(logs,k=len(logs))))*100 for _ in range(5000));row['exploratory_paired_geomean_delta_percent']=math.expm1(statistics.mean(logs))*100;row['exploratory_paired_bootstrap_95_percent']=[boots[125],boots[4874]]
  rows.append(row)
ss={v:[] for v in ['original','current','probe']}
for v in ss:
 for n in range(1,32):
  name=f'legacy-{n}-{v}';x=dict(leaves(json.loads((p/(name+'.stdout')).read_text())));x.update(dict(leaves(json.loads((p/(name+'.resources.json')).read_text()))));ss[v].append(x)
for b,a in [('original','current'),('original','probe'),('current','probe')]:compare('legacy_sqlite',ss,b,a)
ss={v:[] for v in ['current','probe']}
for v in ss:
 for n in range(1,16):
  name=f'native-{n}-{v}';lines=[l.split(',') for l in (p/(name+'.stdout')).read_text().splitlines() if l.startswith('native_pipeline_')];x={r[1]+'/'+k:int(r[i]) for r in lines if r[0]=='native_pipeline_summary' for k,i in [('p50_ns',3),('p95_ns',4),('p99_ns',5)]};totals=sorted(int(r[3]) for r in lines if r[0]=='native_pipeline_total' and r[-1]=='false');assert len(totals)==101;x.update({'outer_iteration_total/'+k:totals[i] for k,i in [('p50_ns',50),('p95_ns',95),('p99_ns',99)]});x.update(dict(leaves(json.loads((p/(name+'.resources.json')).read_text()))));ss[v].append(x)
compare('native_pipeline',ss,'current','probe')
s={'rows':rows,'flags':[x for x in rows if x['review_flag']],'limits':'31 rotating legacy triples and15 alternating native pairs, all per-run reports retained. Aggregate medians of run quantiles are not pooled event percentiles. Whole warmup triple/pair excluded from summary only. Bootstrap5000 paired resamples, fixed seed1, percentile endpoints; exploratory, not causal attribution, equivalence or release acceptance. Original legacy fixture has only10 replay samples per process; no rare-tail or cold-cache guarantee.'};(p/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for x in rows:
 if x['after']=='probe' and x['metric'].endswith('/p50_ns') and ('warm_record' in x['metric'] or 'exact_retry' in x['metric'] or 'reopen_and' in x['metric'] or 'outer_iteration' in x['metric']):print(x['benchmark'],x['before'],x['metric'],x['median_before'],x['median_after'],round(x['median_delta_percent'],2),x['paired_threshold_exceedances'],x.get('exploratory_paired_bootstrap_95_percent'))
print('metric rows',len(rows),'flags',len(s['flags']))
