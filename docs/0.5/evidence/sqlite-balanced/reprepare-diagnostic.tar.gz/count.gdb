set pagination off
set confirm off
set debuginfod enabled off
python
import gdb,json
counts={}
class Counter(gdb.Breakpoint):
 def __init__(self,name):
  self.name=name;counts[name]=0;super().__init__(name,internal=True)
 def stop(self):
  counts[self.name]+=1
  return False
for n in ['sqlite3Prepare','sqlite3Reprepare','sqlite3RunParser']:Counter(n)
end
run
python
print('PENELOPE_SQLITE_CALL_COUNTS '+json.dumps(counts,sort_keys=True))
end
quit
