import json,pathlib,subprocess,os,shutil,hashlib
p=pathlib.Path('/tmp/penelope-050-sqlite-profile');r=pathlib.Path('/home/ac/projects/.penelope-sqlite-qpsg-probe')
artifacts=[x['executable'] for line in (p/'qpsg-build.jsonl').read_text().splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x['target']['name']=='durable_store' and x.get('executable')];assert len(artifacts)==1
b=p/'durable_store-qpsg';shutil.copy2(artifacts[0],b)
(p/'qpsg-source.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--'],cwd=r));shutil.copy2(r/'crates/penelope-sqlite/src/schema.rs',p/'qpsg-schema.rs')
bins={'before':pathlib.Path('/tmp/penelope-050-versioned-sqlite/durable_store-before'),'after':pathlib.Path('/tmp/penelope-050-versioned-sqlite/durable_store-after'),'qpsg':b}
meta={'purpose':'Diagnostic only: unchanged fixture, original,versioned candidate and isolated QPSG connection setting. Candidate source unchanged.','rounds':9,'warmup_rounds':1,'order':'rotate three variants','binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in bins.items()},'env':'PENELOPE_BENCH_DIR NVMe path; CPUs4; shared chaos and host uncontrolled; no build overlaps timing.','qpsg_documentation':'https://www.sqlite.org/c3ref/c_dbconfig_defensive.html#sqlitedbconfigenableqpsg','limitations':'Pilot fixture only, not supported workload-matrix safety/performance qualification. QPSG disables parameter-sensitive plan optimizations; other workloads may be slower. CPU profiling and debugger counts are separate perturbed tmpfs diagnostics, not the NVMe paired timings.'}
(p/'pilot-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
env={**os.environ,'PENELOPE_BENCH_DIR':'/home/ac/projects/penelope/target/versioned-sqlite-data'}
for n in range(10):
 labels=list(bins);labels=labels[n%3:]+labels[:n%3]
 for l in labels:
  name=('warmup' if not n else f'round-{n}')+'-'+l
  with (p/(name+'.json')).open('w') as o,(p/(name+'.stderr')).open('w') as e:subprocess.run(['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e}','-o',str(p/(name+'.resources.json')),'taskset','-c','4',str(bins[l])],stdout=o,stderr=e,env=env,check=True)
  d=json.loads((p/(name+'.json')).read_text());assert d['journal_mode']=='WAL' and d['synchronous']=='FULL';assert [x['records'] for x in d['tasks']]==[16,128,512]
 print('Completed triple',n,flush=True)
for k,b in bins.items():assert hashlib.sha256(b.read_bytes()).hexdigest()==meta['binaries'][k]['sha256']
print('Pilot completed',flush=True)
