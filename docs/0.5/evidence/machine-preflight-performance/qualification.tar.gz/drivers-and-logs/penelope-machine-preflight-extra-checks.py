import subprocess,os,json
from pathlib import Path
root=Path('/home/ac/projects/penelope');repo=Path('/tmp/penelope-machine-preflight');out=Path('/tmp/penelope-machine-preflight-extra-checks');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/machine-preflight')};checks=[]
def run(name,args):
 print(name,flush=True)
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  r=subprocess.run(args,cwd=repo,env=env,stdout=stdout,stderr=stderr)
 checks.append({'name':name,'argv':args,'exit':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2));r.check_returncode()
for compiler in ['1.100.0','1.89.0']:
 for benchmark in ['machine_store','machine_backpressure']:
  run('debug-'+compiler+'-'+benchmark,['cargo','+'+compiler,'bench','--locked','-p','penelope-sqlite','--bench',benchmark,'--profile','dev'])
run('msrv-performance',['python',str(root/'scripts/benchmark-durable-store.py'),str(out/'msrv-performance'),'--repository',str(repo),'--toolchain','1.89.0','--benchmark','machine_store','--data-parent',str(root/'target'),'--cpu','4','--parallel-cpus','4,5,6,7','--runs','1'])
print('completed',flush=True)
