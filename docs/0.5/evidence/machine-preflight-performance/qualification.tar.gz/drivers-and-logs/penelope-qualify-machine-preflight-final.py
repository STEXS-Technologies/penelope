import os, subprocess, json, hashlib, shutil
from pathlib import Path
root=Path('/home/ac/projects/penelope'); candidate=Path('/tmp/penelope-machine-preflight')
out=Path('/tmp/penelope-machine-preflight-final-evaluation');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/machine-preflight')}
checks=[]
def run(name,args,cwd=candidate,e=env,expected=0):
 print(name,flush=True)
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=cwd,env=e,stdout=stdout,stderr=stderr)
 checks.append({'name':name,'argv':args,'cwd':str(cwd),'exit':result.returncode,'expected':expected})
 (out/'checks.json').write_text(json.dumps(checks,indent=2))
 assert result.returncode==expected,(name,result.returncode)
for f in ['crates/penelope-sqlite/src/machine.rs','crates/penelope-sqlite/tests/machines.rs']:
 p=out/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(candidate/f,p)
(out/'candidate.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=candidate))
source=candidate/'crates/penelope-sqlite/src/machine.rs';saved=source.read_bytes()
try:
 source.write_bytes(subprocess.check_output(['git','show','HEAD:crates/penelope-sqlite/src/machine.rs'],cwd=candidate))
 run('baseline-held-writer-negative',['cargo','+1.100.0','test','--locked','-p','penelope-sqlite','--test','machines','--','--exact','resolved_commits_do_not_wait_for_an_unrelated_writer'],expected=101)
finally:source.write_bytes(saved)
for compiler in ['1.100.0','1.89.0']:
 run('tests-'+compiler,['cargo','+'+compiler,'test','--locked','-p','penelope-sqlite','--all-features'])
run('clippy',['cargo','+1.100.0','clippy','--locked','-p','penelope-sqlite','--all-targets','--all-features','--','-D','warnings'])
run('fmt',['cargo','+1.100.0','fmt','--all','--','--check'])
run('diff',['git','diff','--check'])
for i,variant in enumerate(['baseline','candidate','candidate','baseline','baseline','candidate'],1):
 repo=root if variant=='baseline' else candidate
 target=root/'target/sqlite-performance-after' if variant=='baseline' else root/'target/machine-preflight'
 run('measure-'+str(i)+'-'+variant,['python',str(root/'scripts/benchmark-durable-store.py'),str(out/('measure-'+str(i)+'-'+variant)),'--repository',str(repo),'--benchmark','machine_store','--data-parent',str(root/'target'),'--cpu','4','--parallel-cpus','4,5,6,7','--runs','1'],cwd=repo,e={**env,'CARGO_TARGET_DIR':str(target)})
print('completed',flush=True)
