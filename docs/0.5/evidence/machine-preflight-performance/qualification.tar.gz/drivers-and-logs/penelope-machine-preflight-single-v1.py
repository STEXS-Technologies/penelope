import os,subprocess,json,hashlib,statistics,shutil
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-machine-preflight-single');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2'}
binaries={}
for variant in ['baseline','candidate']:
 repo=Path('/tmp/penelope-machine-preflight-baseline' if variant=='baseline' else '/tmp/penelope-machine-preflight')
 e={**env,'CARGO_TARGET_DIR':str(root/('target/machine-preflight-single-base' if variant=='baseline' else 'target/machine-preflight'))}
 print('build',variant,flush=True)
 r=subprocess.run(['taskset','-c','4,5,6,7','cargo','+1.100.0','bench','--locked','-p','penelope-sqlite','--bench','machine_store','--no-run','--message-format=json'],cwd=repo,env=e,capture_output=True,text=True)
 (out/(variant+'-build.jsonl')).write_text(r.stdout);(out/(variant+'-build.stderr')).write_text(r.stderr);r.check_returncode()
 entries=[json.loads(l) for l in r.stdout.splitlines()];b=[x['executable'] for x in entries if x.get('reason')=='compiler-artifact' and x['target']['name']=='machine_store' and x.get('executable')];assert len(b)==1
 dest=out/(variant+'-benchmark');shutil.copyfile(b[0],dest);dest.chmod(0o755);binaries[variant]=str(dest)
 (out/(variant+'-diff.patch')).write_bytes(subprocess.check_output(['git','diff'],cwd=repo))
 for file in ['crates/penelope-sqlite/src/machine.rs','crates/penelope-sqlite/benches/machine_store.rs']:
  p=out/variant/file;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/file,p)
(out/'metadata.json').write_text(json.dumps({'revision':'0032740','binaries':{v:{'path':b,'sha256_before_run':hashlib.sha256(Path(b).read_bytes()).hexdigest()} for v,b in binaries.items()},'order':'15 rounds, baseline/candidate then candidate/baseline alternating','cpu':[4,5,6,7],'filesystem':json.loads(subprocess.check_output(['findmnt','-J','-T',str(root/'target')])),'rustc':subprocess.check_output(['rustc','+1.100.0','-vV'],text=True),'environment':{k:env.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'scope':'Same machine_store fixture restricted to one writer; 101 measured commits plus 8 warmups per process; WAL FULL; no cold-cache claim'},indent=2))
results=[]
for i in range(1,16):
 order=['baseline','candidate'] if i%2 else ['candidate','baseline']
 for variant in order:
  print(i,variant,flush=True);prefix=out/f'round-{i}-{variant}'
  with prefix.with_suffix('.json').open('w') as f:
   subprocess.run(['/usr/bin/time','-f','{"rss_kib":%M,"wall_seconds":%e}','-o',str(prefix.with_suffix('.resources.json')),'taskset','-c','4,5,6,7',binaries[variant]],env={**env,'PENELOPE_BENCH_DIR':str(root/'target')},stdout=f,check=True)
  d=json.loads(prefix.with_suffix('.json').read_text());assert d['measurement_mode']=='release-101' and len(d['profiles'])==1
  p=d['profiles'][0];assert p['writers']==1 and p['measured_rounds']==101 and p['committed_rows_including_warmup']==109 and p['integrity_check']=='ok'
  results.append({'round':i,'variant':variant,'commit_p50_ns':p['commit']['p50_ns'],'retry_p50_ns':p['exact_retry']['p50_ns']})
(out/'summary.json').write_text(json.dumps(results,indent=2));print('completed',flush=True)
