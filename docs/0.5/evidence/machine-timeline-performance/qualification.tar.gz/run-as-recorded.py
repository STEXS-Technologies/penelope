import csv,hashlib,json,math,os,platform,subprocess,time
from pathlib import Path
root=Path.cwd(); out=Path('/tmp/penelope-machine-timeline-qualification'); out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')}
def run(label,args,**kw):
 start=time.time()
 result=subprocess.run(args,env=env,text=True,capture_output=True,**kw)
 (out/(label+'.stdout')).write_text(result.stdout);(out/(label+'.stderr')).write_text(result.stderr)
 checks.append({'label':label,'args':args,'exit_code':result.returncode,'seconds':time.time()-start})
 (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 result.check_returncode(); print(label,'passed',flush=True)
 return result.stdout
checks=[]
metadata={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],text=True),'platform':platform.platform(),'cpu':4,'affinity':[4],'measurement':'individual last-live-input and complete correction call; 101 samples after 8 warmups, separate zero-allocation probe','cache':'warm uncontrolled OS caches; no global eviction','order':'native then machine, ascending horizons and widths; no equivalence or regression attribution claim','crate_source_hashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in subprocess.check_output(['git','ls-files','crates'],text=True).splitlines()},'lock_sha256':hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest(),'binary_hashes':{},'rustc':{}}
for toolchain,count in [('1.100.0',3),('1.89.0',1)]:
 metadata['rustc'][toolchain]=run('rustc-'+toolchain,['rustc','+'+toolchain,'-vV'])
 build=run('build-'+toolchain,['cargo','+'+toolchain,'bench','--locked','-p','penelope-timeline','--bench','machine_timeline','--no-run','--message-format=json'])
 entries=[json.loads(line) for line in build.splitlines()]
 artifacts=[e for e in entries if e.get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='machine_timeline' and e.get('executable')]
 assert len(artifacts)==1
 artifact=artifacts[0];assert not artifact['profile']['debug_assertions']
 binary=artifact['executable'];metadata['binary_hashes'][toolchain]=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
 for i in range(count):
  label=f'release-{toolchain}-{i+1}'
  data=run(label,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e}','-o',str(out/(label+'.resources.json')),'taskset','-c','4',binary])
  rows=list(csv.DictReader(data.splitlines()));assert len(rows)==64
  expected={(p,str(w),str(h),op) for p in ['native','machine'] for w in [8,256,4096,65536] for h in [1,8,32,128] for op in ['live_input','correction']}
  assert {(r['path'],r['state_bytes'],r['horizon'],r['operation']) for r in rows}==expected
  for r in rows:
   samples=[int(n) for n in r['raw_ns'].split(';')];assert len(samples)==101 and min(samples)>0 and r['samples']=='101'
   assert [r[k] for k in ['allocations','reallocations','requested_bytes']]==['0','0','0']
   ordered=sorted(samples)
   for pct in [50,95,99]:assert int(r[f'p{pct}_ns'])==ordered[math.ceil(len(samples)*pct/100)-1]
 run('debug-'+toolchain,['cargo','+'+toolchain,'test','--locked','-p','penelope-timeline','--bench','machine_timeline'])
 run('tests-'+toolchain,['cargo','+'+toolchain,'test','--locked','-p','penelope-timeline','--lib','--tests','--all-features'])
run('clippy',['cargo','clippy','--locked','-p','penelope-timeline','--all-targets','--all-features','--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
run('diff',['git','diff','--check'])
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('All profile dimensions, sample counts, ranks and allocation results verified',flush=True)
