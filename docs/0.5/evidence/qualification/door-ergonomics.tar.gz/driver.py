import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-door-qualification');out.mkdir(exist_ok=False)
source=root/'crates/penelope/examples/door_machine.rs';original=source.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2'}
m={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':sha(original),'checks':[],'negative_controls':[]}
def run(label,args):
 start=time.monotonic();p=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr)
 row={'label':label,'command':args,'exit_code':p.returncode,'seconds':time.monotonic()-start};m['checks'].append(row);(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');p.check_returncode();print(label,'PASS',flush=True)
 return p
for version in ['1.100.0','1.89.0']:
 p=run('door-'+version,['cargo','+'+version,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','door','--locked'])
 assert len(p.stdout.splitlines())==8
 run('tutorial-'+version,['cargo','+'+version,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','first-machine','--locked'])
 run('workspace-example-clippy-'+version,['cargo','+'+version,'clippy','-p','penelope','--example','door_machine','--locked','--','-D','warnings'])
mutations=[('guard-code',b'reason: RejectCode::new(1)',b'reason: RejectCode::new(9)'),('guard-predicate',b'if key != expected {',b'if key == expected {'),('unhandled-category',b'return Ok(Transition::Unhandled);',b'return Ok(Transition::Rejected { reason: RejectCode::new(99) });'),('transition-identity',b'(Door::Open, 1)',b'(Door::Open, 11)')]
try:
 for label,old,new in mutations:
  assert original.count(old)==1,(label,original.count(old))
  changed=original.replace(old,new);source.write_bytes(changed)
  args=['cargo','+1.100.0','run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','door','--locked']
  p=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
  (out/('control-'+label+'.stdout')).write_text(p.stdout);(out/('control-'+label+'.stderr')).write_text(p.stderr)
  assert p.returncode==1 and 'Finished' in p.stderr and 'differs from the truth table' in p.stderr,(label,p.returncode,p.stderr)
  m['negative_controls'].append({'label':label,'command':args,'source_sha256':sha(changed),'replacement_before':old.decode(),'replacement_after':new.decode(),'exit_code':p.returncode,'compiled_and_rejected_by_runtime_oracle':True})
  source.write_bytes(original);print(label,'CAUGHT',flush=True)
finally:source.write_bytes(original)
assert source.read_bytes()==original
run('restored-door',['cargo','+1.100.0','run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','door','--locked'])
run('format',['cargo','+1.100.0','fmt','--all','--check'])
run('pins',['./scripts/check-action-pins.sh'])
m['source_restored_exactly']=True;(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('COMPLETE',flush=True)
