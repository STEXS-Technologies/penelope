import hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');raw=Path('/tmp/penelope-050-door-qualification');dest=root/'docs/0.5/evidence/qualification';sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((raw/'manifest.json').read_text());assert len(m['checks'])==9 and all(c['exit_code']==0 for c in m['checks'])
assert len(m['negative_controls'])==4 and all(c['compiled_and_rejected_by_runtime_oracle'] and c['exit_code']==1 for c in m['negative_controls'])
source='crates/penelope/examples/door_machine.rs';text=(root/source).read_text();assert sha(text.encode())==m['source_sha256'] and m['source_restored_exactly']
assert re.findall(r'^enum (\w+)',text,re.M)==['Door','DoorEvent'];assert len(re.findall(r'^impl Machine for ',text,re.M))==1
assert not re.search(r'\b(?:Clone|Serialize|Deserialize)\b',text)
expected=['Open -> Ok(true); revision=1 state=Open','Lock { key: 7 } -> Err(2); revision=1 state=Open','Close -> Ok(true); revision=2 state=Closed','Lock { key: 7 } -> Ok(true); revision=3 state=Locked { key: 7 }','Unlock { key: 8 } -> Err(1); revision=3 state=Locked { key: 7 }','Open -> Ok(false); revision=3 state=Locked { key: 7 }','Unlock { key: 7 } -> Ok(true); revision=4 state=Closed','Close -> Ok(false); revision=4 state=Closed']
for version in ['1.100.0','1.89.0']:assert (raw/('door-'+version+'.stdout')).read_text().splitlines()==expected
production=json.loads((dest/'current-package-checkpoint.json').read_text())['coverage']['source_sha256'];assert len(production)==72
for name,h in production.items():assert sha((root/name).read_bytes())==h
paths=[source,'ci/machine-consumer/Cargo.toml','.github/workflows/ci.yml','.github/workflows/release.yml','docs/0.5/machine.md','docs/RELEASE.md','docs/getting-started.md']
for name in ['Cargo.lock','ci/machine-consumer/Cargo.lock']:assert (root/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name],cwd=root)
command='cargo run --manifest-path ci/machine-consumer/Cargo.toml --bin door --locked'
assert (root/'.github/workflows/ci.yml').read_text().count(command)==2 and command in (root/'.github/workflows/release.yml').read_text()
files={'raw/'+p.name:p for p in raw.iterdir() if p.is_file()};files['driver.py']=Path('/tmp/penelope-050-door-qualification.py');files['recorder.py']=Path(__file__)
for name in paths:files['source/'+name]=root/name
archive=dest/'door-ergonomics.tar.gz';members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in members.items():assert sha(t.extractfile(name).read())==h
out={'scope':'Plan9.1 refined to the actual API: one non-Clone state enum with variant-local data, one event enum, one Machine implementation and no SQL/registration/runtime service. Exact same public example runs through a facade-only external package. This adds an example, not a local metadata convenience API or a new engine.','base_commit':m['base_commit'],'source_sha256':{name:sha((root/name).read_bytes()) for name in paths},'checked_production_files_unchanged':72,'checks':m['checks'],'negative_controls':m['negative_controls'],'source_restored_exactly':True,'expected_trace':expected,'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'limits':['Source hashes bind the exact pre-commit example/workflow/documentation bytes retained in this archive; the base commit alone does not contain the new files.','The example uses explicit fixture scope/event/digest/logical-time metadata. It does not reduce that setup or establish durable identity/authentication/deduplication.','This is a finite eight-event truth table, not exhaustive application-model correctness or a user study.','No effects are staged by this minimal model. Existing counter/nested and durable progression examples cover staged effects and native admission.','Remote CI for this follow-up and final all-ten package reconciliation remain pending. Prior packages/coverage and live full chaos retain their original source/harness scopes.']}
(dest/'door-ergonomics.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified9 checks,4 compiled negative controls,8 decisions on both compilers,72 unchanged production files and',len(members),'archive members')
