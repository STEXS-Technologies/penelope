import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-qpsg-chaos');out=Path('/tmp/penelope-050-qpsg-property-stress')
assert not out.exists(),'Do not replace an existing campaign'
out.mkdir();source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert source=='cefa55faffe837fe30625205dd8236e9c242fb36'
def identity():
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0');return {os.fsdecode(p):hashlib.sha256((root/os.fsdecode(p)).read_bytes()).hexdigest() for p in paths if p and not (root/os.fsdecode(p)).is_symlink()}
pre=identity();(out/'source-pre.json').write_text(json.dumps(pre,indent=2)+'\n')
args=['taskset','-c','4-7','python3','scripts/run_property_stress.py','--seconds','300','--cases','10000','--jobs','3','--output',str(out/'properties')]
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTUP_TOOLCHAIN':'1.100.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/candidate-qpsg-adoption'}
manifest={'source_commit':source,'args':args,'status':'running','scope':'Three registered legacy property tests, each at least300 seconds with rotating integer seeds and10000 requested cases per batch. Not the full machine/timeline chaos campaign or a performance comparison.','started_unix':time.time()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Started',source,flush=True)
with (out/'campaign.log').open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
post=identity();(out/'source-post.json').write_text(json.dumps(post,indent=2)+'\n');diff=subprocess.run(['git','diff','--exit-code'],cwd=root,capture_output=True,text=True);(out/'source-diff.log').write_text(diff.stdout+diff.stderr)
manifest.update(status='complete' if r.returncode==0 and pre==post and diff.returncode==0 else 'failed',exit_code=r.returncode,source_unchanged=pre==post,source_diff_exit=diff.returncode,ended_unix=time.time())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest),flush=True)
raise SystemExit(0 if manifest['status']=='complete' else 1)
