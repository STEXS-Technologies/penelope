import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate')
probe=Path('/home/ac/projects/.penelope-050-replay-qualification')
raw=Path('/tmp/penelope-050-replay-mutation-fuzz')
dest=root/'docs/0.5/evidence/qualification'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((raw/'manifest.json').read_text())
initial=json.loads((dest/'replay-mutation-initial.json').read_text())
assert m['status']=='complete' and m['source_unchanged'] and m['binary_unchanged']
assert len(m['checks'])==14 and all(c['exit_code']==0 for c in m['checks'])
assert m['source_hashes']==m['source_after_sha256']
assert m['base_commit']==initial['base_commit'] and m['binary_sha256']==initial['binary_sha256']
for name,h in m['source_hashes'].items():assert sha((probe/name).read_bytes())==h,name
assert sha(Path('/home/ac/projects/penelope/target/replay-mutation-fuzz/x86_64-unknown-linux-gnu/release/fuzz_sqlite_machine').read_bytes())==m['binary_sha256']
assert len(m['rounds'])==3 and [r['seed'] for r in m['rounds']]==[1,2,3]
for row in m['rounds']:
 assert row['exit_code']==0 and '-runs=100000' in row['command'] and '-max_len=96' in row['command']
 log=(raw/f"round-{row['seed']}.log").read_text()
 assert log.count('Done 100000 runs')==1
 assert 'ERROR: AddressSanitizer' not in log
assert len(m['deterministic_seeds'])==10
for name,h in m['deterministic_seeds'].items():assert sha((raw/'seeds/fuzz_sqlite_machine'/name).read_bytes())==h
# Keep original seeds and every terminal corpus, not only successful summaries.
files={'raw/'+str(p.relative_to(raw)):p for p in raw.rglob('*') if p.is_file()}
files['driver.py']=Path('/tmp/penelope-050-replay-mutation-fuzz.py')
files['recorder.py']=Path(__file__)
for name in ['fuzz/fuzz_targets/fuzz_sqlite_machine.rs','scripts/seed-machine-corpus.py']:
 files['source/'+name]=probe/name
patch=subprocess.check_output(['git','diff','--binary'],cwd=probe)
(raw/'source-patch.diff').write_bytes(patch)
files['source-patch.diff']=raw/'source-patch.diff'
archive=dest/'replay-mutation-complete.tar.gz'
members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(members)
 for name,h in members.items():assert sha(t.extractfile(name).read())==h
result={'status':'supplementary_three_rounds_complete','base_commit':m['base_commit'],'scope':m['scope'],'start_utc':m['start_utc'],'end_utc':m['end_utc'],'initial_evidence':'replay-mutation-initial.json','initial_checks':m['checks'],'rounds':m['rounds'],'requested_executions':300000,'source_unchanged':True,'binary_unchanged':True,'binary_sha256':m['binary_sha256'],'source_sha256':m['source_hashes'],'deterministic_seed_sha256':m['deterministic_seeds'],'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'member_count':len(members),'members_sha256':members},'limits':['This f36b77d-based harness predates isolated event replay at9084239. It checks exact historical resubmission and snapshot restore, not the newer model-reevaluation method.','Clean database reopens are not process kills or power-loss tests.','Bounded seeded fuzzing supplies observations, not exhaustive correctness or authenticated storage.','The current production full campaign, newer event-replay supplementary campaign, performance findings and final release reconciliation remain separate open gates.']}
(dest/'replay-mutation-complete.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified three completed100000-run rounds, unchanged source/binary,',len(members),'archive members')
