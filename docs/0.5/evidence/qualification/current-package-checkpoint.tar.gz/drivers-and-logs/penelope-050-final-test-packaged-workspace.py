import subprocess,os,json,hashlib,tarfile,time,shutil,tomllib
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-final-packaging');out=Path('/tmp/penelope-050-final-packaged-workspace');out.mkdir(exist_ok=False)
qualified_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
source=Path('/home/ac/projects/penelope/target/final-package-checks/package');unpacked=Path('/home/ac/projects/penelope/target/final-package-unpacked');unpacked.mkdir(exist_ok=False)
archives=sorted(source.glob('*.crate'));assert len(archives)==10
packages=[]
for archive in archives:
 with tarfile.open(archive) as t:
  tops={m.name.split('/')[0] for m in t};assert len(tops)==1
  top=tops.pop();t.extractall(unpacked,filter='data')
  vcs=json.loads(t.extractfile(top+'/.cargo_vcs_info.json').read())
  assert vcs['git']['sha1']==qualified_commit and not vcs['git'].get('dirty',False),vcs
  packages.append({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'directory':top,'vcs':vcs})
manifest='[workspace]\nresolver = "3"\nmembers = [\n'+''.join('    '+json.dumps(p['directory'])+',\n' for p in packages)+']\n\n[patch.crates-io]\n'
for p in packages:
 name=p['directory'].removesuffix('-0.5.0');manifest+=name+' = { path = '+json.dumps(p['directory'])+' }\n'
(unpacked/'Cargo.toml').write_text(manifest);shutil.copy2(root/'Cargo.lock',unpacked/'Cargo.lock')
(out/'Cargo.toml').write_text(manifest);(out/'Cargo.lock').write_bytes((unpacked/'Cargo.lock').read_bytes());(out/'archives.json').write_text(json.dumps(packages,indent=2)+'\n')
(out/'Cargo.lock-original').write_bytes((root/'Cargo.lock').read_bytes())
original=tomllib.loads((out/'Cargo.lock-original').read_text())
original_external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in original['package'] if p.get('source')}
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/final-package-tests'}
assert not Path(env['CARGO_TARGET_DIR']).exists(), 'Require a genuinely fresh compiled test target'
checks=[]
commands=[('lock-normalization',['cargo','+1.100.0','metadata','--offline','--format-version','1']),('metadata',['cargo','+1.100.0','metadata','--locked','--format-version','1'])]
commands += [('tests-'+v,['cargo','+'+v,'test','--workspace','--all-targets','--all-features','--locked']) for v in ['1.100.0','1.89.0']]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
 if label.startswith('tests-'):
  for name in ['generated_tables_and_hierarchies_match_reference_and_single_level_flat_dispatch','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap','event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot','event_replay_refuses_wrong_predecessor_model_codec_limits_and_duplicate_revision','event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions']:
   assert r.stdout.count('test '+name+' ... ok')==1,(label,name)
  import re
  reports=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',r.stdout)
  assert len(reports)==96 and sum(int(x[0]) for x in reports)==700 and all(x[1]=='0' and x[2]=='0' for x in reports),(label,reports)
 if label=='lock-normalization':
  lock=(unpacked/'Cargo.lock').read_bytes();(out/'Cargo.lock').write_bytes(lock)
  data=tomllib.loads(lock.decode());external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in data['package'] if p.get('source')}
  assert external<=original_external,external-original_external
  (out/'external-lock-diff.json').write_text(json.dumps({'added':sorted(external-original_external),'removed':sorted(original_external-external)},indent=2)+'\n')
 if label=='metadata':
  data=json.loads(r.stdout);selected=[p for p in data['packages'] if p['name'].startswith('penelope')]
  assert len(selected)==10 and all(p['version']=='0.5.0' and Path(p['manifest_path']).is_relative_to(unpacked) for p in selected)
assert (out/'Cargo.lock').read_bytes()==(unpacked/'Cargo.lock').read_bytes()
print('completed',flush=True)
