import json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-final-packaging');out=Path('/tmp/penelope-050-final-coverage');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTUP_TOOLCHAIN':'1.100.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/final-candidate-coverage','CARGO_LLVM_COV_TARGET_DIR':'/home/ac/projects/penelope/target/final-candidate-coverage/instrumented'}
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
(out/'source-commit.txt').write_text(source+'\n')
assert not Path(env['CARGO_TARGET_DIR']).exists(), 'Require a fresh coverage target'
checks=[]
for label,args in [('clean',['cargo','llvm-cov','clean']),('coverage',['cargo','llvm-cov','--workspace','--all-features','--locked','--exclude','penelope-fuzz','--json','--output-path',str(out/'coverage.json')]),('ratchet',['./scripts/check_coverage_ratchet.sh',str(out/'coverage.json')])]:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr);checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
print('completed',flush=True)
