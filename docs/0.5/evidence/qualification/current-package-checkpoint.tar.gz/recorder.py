import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');raw=Path('/tmp/penelope-050-final-packaged-workspace');cov=Path('/tmp/penelope-050-final-coverage');dest=root/'docs/0.5/evidence/qualification';source='c8fda4c994cdcdda075d09648e502a0aa4fe1775';sha=lambda b:hashlib.sha256(b).hexdigest()
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==4 and all(c['exit_code']==0 for c in checks)
new_names=['event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot','event_replay_refuses_wrong_predecessor_model_codec_limits_and_duplicate_revision','event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions'];kill='repeated_sigkill_on_a_growing_journal_preserves_every_prefix_and_exact_retry';observations=[]
for version in ['1.100.0','1.89.0']:
 text=(raw/('tests-'+version+'.stdout')).read_text();reports=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(reports)==96 and sum(int(x[0]) for x in reports)==700 and all(x[1]=='0' and x[2]=='0' for x in reports)
 names=lambda s:collections.Counter(re.findall(r'^test ([^\n]+?) \.\.\.(?: ok)? *$',s,re.M));previous=Path('/tmp/penelope-050-event-replay-packaged-workspace')/('tests-'+version+'.stdout');new=names(text);old=names(previous.read_text());assert not old-new;added=new-old;assert not added;assert all(new[n]==1 for n in new_names);assert len([n for n in new if n.endswith(kill)])==1
 for name in new_names:assert text.count('test '+name+' ... ok')==1
 observations.append({'compiler':version,'harness_summaries':96,'reported_passes':700,'failed':0,'ignored':0,'added_tests':list(added),'comparison_source':'9084239', 'all_previous_test_names_retained':True,'no_previous_test_name_removed':True,'comparison_note':'Started test names handle subprocess-split output; every passing harness summary independently requires zero failures and ignored tests.'})
archives=json.loads((raw/'archives.json').read_text());assert len(archives)==10 and all(p['vcs']['git']['sha1']==source and not p['vcs']['git'].get('dirty',False) for p in archives)
lockdiff=json.loads((raw/'external-lock-diff.json').read_text());assert not lockdiff['added'];assert {r[0] for r in lockdiff['removed']}=={'arbitrary','jobserver','libfuzzer-sys'}
cc=json.loads((cov/'checks.json').read_text());assert len(cc)==3 and all(c['exit_code']==0 for c in cc);data=json.loads((cov/'coverage.json').read_text())['data'][0];lines=data['totals']['lines'];assert lines['covered']==14925 and lines['count']==15860 and lines['percent']>=94.0759
production=json.loads((cov/'source-sha256.json').read_text());assert len(production)==72
for name,h in production.items():assert sha((root/name).read_bytes())==h and (root/name).read_bytes()==subprocess.check_output(['git','show',source+':'+name],cwd=root)
ci=json.loads(Path('/tmp/penelope-050-final-ci.json').read_text());assert ci['headSha']==source and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
cilog=Path('/tmp/penelope-050-final-ci.log').read_text()
for job in ['Stable verification','Minimum supported Rust']:
 for name in new_names:assert sum(line.startswith(job+'\t') and 'test '+name+' ... ok' in line for line in cilog.splitlines())==1,(job,name)
driver=Path('/tmp/penelope-050-final-package-driver')
assert json.loads((driver/'source-before.json').read_text())==json.loads((driver/'source-after.json').read_text())
assert all(c['exit_code']==0 for c in json.loads((driver/'checks.json').read_text()))
for package,name in [('penelope-core','tests/machine_allocations.rs'),('penelope','examples/nested_order.rs')]:
 archive_path=Path('/home/ac/projects/penelope/target/final-package-checks/package')/(package+'-0.5.0.crate')
 with tarfile.open(archive_path) as t:assert t.extractfile(package+'-0.5.0/'+name).read()==(root/'crates'/package/name).read_bytes()
for job in ['Stable verification','Minimum supported Rust']:
 assert sum(line.startswith(job+'\t') and 'Nested example: six decisions and exact staged traces verified' in line for line in cilog.splitlines())==1
files={}
for label,folder in [('packages',raw),('coverage',cov)]:
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for p in Path('/home/ac/projects/penelope/target/final-package-checks/package').glob('*.crate'):files['archives/'+p.name]=p
for name in ['penelope-050-final-run-coverage.py','penelope-050-final-test-packaged-workspace.py','penelope-050-final-package-driver.py','penelope-050-final-ci.json','penelope-050-final-ci.log']:
 files['drivers-and-logs/'+name]=Path('/tmp')/name
for p in Path('/tmp/penelope-050-final-package-driver').iterdir():
 if p.is_file():files['package-driver/'+p.name]=p
files['recorder.py']=Path(__file__)
archive=dest/'current-package-checkpoint.tar.gz';members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in members.items():assert sha(t.extractfile(name).read())==h
m={'source_commit':source,'scope':'All ten clean actual0.5 archives atc8fda4c, including the nested enum allocation fixture and root-policy/leaf-refusal example, after isolated event replay and repeated growing-journal SIGKILL tests. Source CI and fresh coverage included. Full campaigns, performance findings, final normative audit and release reconciliation remain open.','package_checks':checks,'test_observations':observations,'archives':archives,'lock_diff':lockdiff,'coverage':{'checks':cc,'lines':lines,'ratchet':94.0759,'reported_source_files':72,'source_sha256':production,'comparison_to_9084239':{'covered_lines_delta':-2,'changed_file':'crates/penelope-sqlite/src/payloads.rs','old_covered_lines':80,'current_covered_lines':78,'file_lines':91,'note':'All other production file line totals are unchanged. Runtime-dependent branch observations are retained rather than replacing this fresh result with the higher prior one.'}},'ci':{'run_id':43829769107,'url':'https://github.com/STEXS-Technologies/penelope/actions/runs/43829769107','jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']],'all_three_replay_tests_observed_once_in_stable_and_msrv':True},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'member_count':len(files),'members_sha256':members},'limits':['These are debug test/benchmark smoke runs, not comparative release timings.','Line coverage is not branch completeness or a correctness proof.','Both extracted-workspace tests start from genuinely fresh compiled target and verify explicit added test observations; later compiler builds may reuse appropriate dependency artifacts from that fresh target.','MSRV1.89 approval, typed authority boundaries and existing wire formats remain unchanged.','Full9084239 campaign and supplementary augmented-target campaigns retain separate source hashes; no running job is counted complete.','No performance findings are waived; publication/tagging remain separately authorized.']}
(dest/'current-package-checkpoint.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members; ten clean archives,96 summaries/700 passes each compiler,72 exact coverage sources and all7 CI jobs')
