import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');probe=Path('/home/ac/projects/.penelope-050-replay-qualification');raw=Path('/tmp/penelope-050-replay-mutation-fuzz');dest=root/'docs/0.5/evidence/qualification';sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((raw/'manifest.json').read_text());assert len(m['checks'])==14 and all(c['exit_code']==0 for c in m['checks']) and m['status']=='full-rounds-running'
source=['fuzz/fuzz_targets/fuzz_sqlite_machine.rs','scripts/seed-machine-corpus.py']
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==source
for name,h in m['source_hashes'].items():assert sha((probe/name).read_bytes())==h and sha((root/name).read_bytes())==h,name
production=json.loads((dest/'history-partition-checkpoint.json').read_text())['coverage']['source_sha256']
for name,h in production.items():assert sha((root/name).read_bytes())==h
seed_names=m['deterministic_seeds'];assert len(seed_names)==10
for name,h in seed_names.items():assert sha((raw/'seeds/fuzz_sqlite_machine'/name).read_bytes())==h
assert 'Done 1000 runs' in (raw/'smoke.log').read_text()
(raw/'initial-manifest-snapshot.json').write_text(json.dumps(m,indent=2)+'\n')
tools={}
for name,args in [('rustc-nightly',['rustc','+nightly','--version','--verbose']),('cargo-nightly',['cargo','+nightly','--version']),('cargo-fuzz',['cargo','fuzz','--version']),('host',['uname','-a'])]:
 r=subprocess.run(args,cwd=probe,capture_output=True,text=True);assert r.returncode==0;tools[name]={'args':args,'stdout':r.stdout};(raw/(name+'.txt')).write_text(r.stdout)
files={'manifest-snapshot.json':raw/'initial-manifest-snapshot.json','source-pre.json':raw/'source-pre.json','driver.py':Path('/tmp/penelope-050-replay-mutation-fuzz.py'),'recorder.py':Path(__file__)}
for row in m['checks']:files['initial-checks/'+row['label']+'.log']=raw/(row['label']+'.log')
for name in seed_names:files['seeds/'+name]=raw/'seeds/fuzz_sqlite_machine'/name
for name in source:files['source/'+name]=root/name
for name in tools:files['tools/'+name+'.txt']=raw/(name+'.txt')
archive=dest/'replay-mutation-initial.tar.gz';members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in members.items():assert sha(t.extractfile(name).read())==h
result={'status':'bounded_initial_checks_pass_full_rounds_running','base_commit':m['base_commit'],'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Augmented existing SQLite machine fuzz harness and deterministic corpus only. Real historical requests replay in reverse with exact original receipts; future-head admission refuses; checksummed scope/model substitutions decode structurally but fail pinned restore; altered event digest fails payload binding. Existing duplicate-content and contiguous-history arithmetic oracle remain active. No new API/dependency/runtime behavior.','source_sha256':{name:m['source_hashes'][name] for name in source},'production_files_unchanged_from_current_package_checkpoint':len(production),'initial_checks':m['checks'],'deterministic_seed_sha256':seed_names,'binary_sha256':m['binary_sha256'],'tools':tools,'long_campaign':{'status':'running_at_capture','requested_rounds':3,'requested_runs_per_round':100000,'seeds':[1,2,3],'maximum_input_length':96,'source_worktree':str(probe),'manifest':str(raw/'manifest.json'),'scope':'Separate supplementary single-target campaign. Full-target current-production campaign remains independent; no terminal long-campaign claim is made.'},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'limits':['Reverse replay here means idempotent resubmission of exact historical requests; it does not claim an arbitrary external replay-stream interpreter or detection of all malicious journal rewrites.','Recovery-byte hashes do not authenticate a source. Foreign-scope refusal is checked against the explicitly pinned configured scope.','The SQLite fuzz target still uses clean reopens. Actual process-kill model testing remains a separate fixture.','Full campaign completion, final source/harness/artifact reconciliation, performance findings and remaining detailed plan review stay open.']}
(dest/'replay-mutation-initial.json').write_text(json.dumps(result,indent=2)+'\n');print('Archived14 initial checks,10 source-bound seeds,72 unchanged production sources and',len(members),'verified archive members; long campaign remains live.')
