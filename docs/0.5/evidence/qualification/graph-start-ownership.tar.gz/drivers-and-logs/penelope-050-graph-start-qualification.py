from pathlib import Path
import subprocess,os,time,json
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-graph-start-qualification');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/graph-start-ownership'}
commands=[]
for v in ['1.100.0','1.89.0']:
 commands += [('consumer-'+v,['cargo','+'+v,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','decisions','--locked']),('saga-parity-'+v,['cargo','+'+v,'run','--manifest-path','ci/saga-parity/Cargo.toml','--locked']),('executor-tests-'+v,['cargo','+'+v,'test','-p','penelope-executor','--all-targets','--all-features','--locked']),('workspace-example-clippy-'+v,['cargo','+'+v,'clippy','-p','penelope','--example','prepared_decisions','--locked','--','-D','warnings'])]
commands += [('fmt',['cargo','+1.100.0','fmt','--all','--check'])]
checks=[]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
print('completed',flush=True)
