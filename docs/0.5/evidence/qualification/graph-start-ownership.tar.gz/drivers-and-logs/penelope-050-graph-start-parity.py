import subprocess,os,json,time,gzip,hashlib
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-graph-start-qualification');env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/graph-start-ownership'}
manifest=json.loads((root/'ci/saga-parity/baseline/manifest.json').read_text());expected=gzip.decompress((root/'ci/saga-parity/baseline/v0.4.0.jsonl.gz').read_bytes());assert hashlib.sha256(expected).hexdigest()==manifest['output_sha256'];assert hashlib.sha256((root/'ci/saga-parity/src/main.rs').read_bytes()).hexdigest()==manifest['fixture_sha256']
checks=[]
for v in ['1.100.0','1.89.0']:
 label='prepared-parity-'+v;args=['cargo','+'+v,'run','--manifest-path','ci/saga-parity/Cargo.toml','--features','prepared','--locked'];start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True)
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);r.check_returncode();assert r.stdout==expected
 legacy=(out/('saga-parity-'+v+'.stdout')).read_bytes();assert legacy==expected
 checks.append({'label':label,'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'exact_frozen_rows':manifest['rows'],'legacy_and_prepared_equal_frozen_baseline':True});(out/'prepared-parity-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(v,manifest['rows'],'exact observations through both paths',flush=True)
