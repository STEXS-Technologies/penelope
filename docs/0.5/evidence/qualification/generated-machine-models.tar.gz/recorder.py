import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-model-qualification');out=Path('/tmp/penelope-050-generated-model-fuzz');candidate=Path('/home/ac/projects/.penelope-050-candidate');dest=candidate/'docs/0.5/evidence/qualification'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((out/'manifest.json').read_text());assert m['status']=='complete' and m['source_unchanged'] and m['binary_unchanged'];assert [r['seed'] for r in m['rounds']]==[1,2,3]
for seed in [1,2,3]:assert 'Done 100000 runs' in (out/f'round-{seed}.log').read_text()
for p,h in m['source_hashes'].items():assert sha((root/p).read_bytes())==h
assert not subprocess.check_output(['git','diff','cefa55f','--','crates/*/src','Cargo.toml','Cargo.lock','fuzz/Cargo.toml'],cwd=root)
controls=Path('/tmp/penelope-050-generated-model-controls');c=json.loads((controls/'manifest.json').read_text());assert c['production_source_restored'] and all(r['compiled_and_test_failed'] for r in c['controls'])
files={}
for p in out.glob('*.json'):files['fuzz/'+p.name]=p
for p in out.glob('*.log'):files['fuzz/'+p.name]=p
for p in controls.iterdir():files['controls/'+p.name]=p
for p in Path('/tmp').glob('penelope-050-generated-model-*.log'):files['checks/'+p.name]=p
for p in m['source_hashes']:files['source/'+p]=root/p
for p in ['Cargo.toml','Cargo.lock','fuzz/Cargo.toml','rust-toolchain.toml','crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/src/machine/memory.rs']:files['source/'+p]=root/p
files['driver.py']=Path('/tmp/penelope-050-generated-model-fuzz.py');files['recorder.py']=Path(__file__)
corpora=out/'retained-corpora.tar.gz'
with tarfile.open(corpora,'w:gz') as t:
 for directory in [out/'seeds',*[out/f'corpus-{seed}' for seed in [1,2,3]]]:t.add(directory,arcname=directory.name)
files['fuzz/retained-corpora.tar.gz']=corpora
versions={}
for args in [['rustc','+1.100.0','-Vv'],['rustc','+1.89.0','-Vv'],['rustc','+nightly','-Vv'],['cargo','+nightly','fuzz','--version']]:versions[' '.join(args)]=subprocess.check_output(args,cwd=root,text=True)
versionspath=out/'versions.json';versionspath.write_text(json.dumps(versions,indent=2)+'\n');files['versions.json']=versionspath
archive=dest/'generated-machine-models.tar.gz';hashes={n:sha(p.read_bytes()) for n,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as t:
 for n,h in hashes.items():assert sha(t.extractfile(n).read())==h
manifest={'scope':'Plan13.1 generated bounded machine definitions, nested paths and one-level flat equivalence. Test/fuzz strengthening only; production/library/dependency inputs match cefa55f. Separate from the running full-target campaigns and final packaged-source reconciliation.',
'proposal_base_commit':m['base_commit'],'production_source_commit':'cefa55faffe837fe30625205dd8236e9c242fb36','source_hashes':m['source_hashes'],
'checks':{'stable':'One deterministic generated-model test passes on Rust1.100.0.','msrv':'Same test passes on Rust1.89.0.','clippy':'Strict targeted Clippy passes; original lint failures retained.','format':'Workspace rustfmt check passes.','generated_inputs':'512 xorshift64 seeds each produce138 input bytes, plus all-zero/all-255 lengths0..42. Inputs vary8 nodes,4 events, immutable per-run transition tables, bounded acyclic parent forests, initial states and intent budgets. At most96 events per evaluation.','oracle':'Ordinary ancestor lists and membership choose the nearest handler and LCA; independently expected state/revision, transition coordinates, intent origins and exit/action/entry order are checked after each event. Native Table dispatch is compared with a one-level Hierarchical<Table,1>; replay repeats exact captured events and context. Cyclic restored paths and insufficient depth refuse.'},
'negative_controls':c,'negative_mutations':[{'owner':'crates/penelope-core/src/machine/hierarchy.rs','before':'.exit(node, current, &mut next, context, intents)','after':'.enter(node, current, &mut next, context, intents)'},{'owner':'crates/penelope-core/src/machine/hierarchy.rs','before':'HierarchyDecision::Unhandled => {}','after':'HierarchyDecision::Unhandled => return Ok(Transition::Unhandled),'}],
'fuzz':m,'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'member_count':len(files),'members_sha256':hashes},
'limits':['Finite generated models and sanitizer fuzzing are not proof for arbitrary application handlers.','Three100000-run rounds qualify the augmented fuzz_machine target, not every fuzz target or the complete release.','No production behavior, feature, dependency, safety bound or performance waiver changed.','Source/archive/coverage reconciliation after adopting the added test is still required.','Initial syntax/format/lint attempts are retained; only final successful source hashes define the proposal.']}
(dest/'generated-machine-models.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Archived',len(files),'verified members and all300000 completed fuzz executions.')
