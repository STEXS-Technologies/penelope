import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-model-qualification');out=Path('/tmp/penelope-050-generated-model-fuzz');assert not out.exists();out.mkdir()
paths=['crates/penelope-core/tests/generated_machines.rs','crates/penelope-core/tests/support/generated_machine.rs','fuzz/fuzz_targets/fuzz_machine.rs']
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
pre=hashes();(out/'source-pre.json').write_text(json.dumps(pre,indent=2)+'\n')
production=subprocess.check_output(['git','diff','cefa55f','--','crates/*/src','Cargo.toml','Cargo.lock','fuzz/Cargo.toml','fuzz/Cargo.lock'],cwd=root);assert not production,production
seedroot=out/'seeds';seedroot.mkdir()
for seed in range(1,513):
 rng=seed;b=bytearray()
 for _ in range(138):
  rng^=(rng<<13)&((1<<64)-1);rng^=rng>>7;rng^=(rng<<17)&((1<<64)-1);b.append(rng&255)
 (seedroot/str(seed)).write_bytes(b)
binary=Path('/home/ac/projects/penelope/target/generated-model-fuzz/x86_64-unknown-linux-gnu/release/fuzz_machine');binarysha=hashlib.sha256(binary.read_bytes()).hexdigest()
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/generated-model-fuzz'}
manifest={'status':'running','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'production_source':'cefa55f','source_hashes':pre,'binary_sha256':binarysha,'rounds':[],'scope':'Augmented existing fuzz_machine target only; three independent seeded corpora,100000 requested executions per round. Other full-target campaigns retain their original harness/source scopes.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for seed in [1,2,3]:
 corpus=out/f'corpus-{seed}';corpus.mkdir()
 for p in seedroot.iterdir():(corpus/p.name).write_bytes(p.read_bytes())
 args=['taskset','-c','4-7','cargo','+nightly','fuzz','run','fuzz_machine',str(corpus),'--','-runs=100000',f'-seed={seed}','-max_len=256']
 started=time.time()
 with (out/f'round-{seed}.log').open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'seed':seed,'args':args,'exit_code':r.returncode,'seconds':time.time()-started};manifest['rounds'].append(row);print(json.dumps(row),flush=True)
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if r.returncode:break
post=hashes();(out/'source-post.json').write_text(json.dumps(post,indent=2)+'\n');manifest['source_unchanged']=pre==post;manifest['binary_unchanged']=hashlib.sha256(binary.read_bytes()).hexdigest()==binarysha
manifest['status']='complete' if len(manifest['rounds'])==3 and all(r['exit_code']==0 for r in manifest['rounds']) and pre==post and manifest['binary_unchanged'] else 'failed'
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(manifest['status'],flush=True);raise SystemExit(0 if manifest['status']=='complete' else 1)
