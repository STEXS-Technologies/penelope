import os,subprocess,json,shutil
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-machine-failure-checks');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')};checks=[]
for compiler in ['1.100.0','1.89.0']:
 name='sqlite-'+compiler;print(name,flush=True)
 args=['cargo','+'+compiler,'test','--locked','-p','penelope-sqlite','--all-features'];r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);checks.append({'name':name,'argv':args,'exit':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2));r.check_returncode()
for name,args in [('clippy',['cargo','+1.100.0','clippy','--locked','-p','penelope-sqlite','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','+1.100.0','fmt','--all','--','--check']),('diff',['git','diff','--check'])]:
 print(name,flush=True);r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);checks.append({'name':name,'argv':args,'exit':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2));r.check_returncode()
for f in ['crates/penelope-sqlite/src/machine.rs','crates/penelope-sqlite/src/machine/tests.rs','crates/penelope-sqlite/tests/machines.rs']:
 p=out/'source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,p)
print('completed',flush=True)
