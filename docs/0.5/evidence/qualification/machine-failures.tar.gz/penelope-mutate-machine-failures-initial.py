import os,subprocess,json
from pathlib import Path
root=Path('/home/ac/projects/penelope');repo=Path('/tmp/penelope-machine-failure-mutations');out=Path('/tmp/penelope-machine-failure-mutations');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/machine-failure-mutations')}
p=repo/'crates/penelope-sqlite/src/machine.rs';original=p.read_text();checks=[]
mutations=[('skip-transactional-admission','''    let head = match admission(&transaction, batch, payloads)? {
        CommitAdmission::Existing(receipt) => return Ok(receipt),
        CommitAdmission::New(head) => head,
    };''','''    let head = read_head_in::<N>(&transaction, expected.scope, payloads)?
        .ok_or(MachineStoreError::Conflict)?;''',['--lib','machine::tests::commit_revalidates_duplicate_conflict_and_stale_after_preflight_snapshot']),('omit-history-ceiling','''    if count >= limits.max_history_records {
        return Err(MachineStoreError::Capacity);
    }''','',['--test','machines','full_history_refuses_new_events_but_preserves_exact_retries_and_rows'])]
for name,before,after,selection in mutations:
 assert before in original;p.write_text(original.replace(before,after,1));(out/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff'],cwd=repo))
 args=['cargo','+1.100.0','test','--locked','-p','penelope-sqlite',*selection,'--','--exact','--nocapture'];print(name,flush=True);r=subprocess.run(args,cwd=repo,env=env,capture_output=True,text=True);(out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);checks.append({'name':name,'argv':args,'exit':r.returncode,'expected':101});(out/'checks.json').write_text(json.dumps(checks,indent=2));assert r.returncode==101 and 'test result: FAILED' in r.stdout and 'Finished `test`' in r.stderr,(name,r.stderr,r.stdout)
p.write_text(original);print('completed',flush=True)
