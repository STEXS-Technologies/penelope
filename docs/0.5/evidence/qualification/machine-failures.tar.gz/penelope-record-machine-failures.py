import json,hashlib,tarfile,subprocess
from pathlib import Path
root=Path('/home/ac/projects/penelope')
out=root/'docs/0.5/evidence/qualification'
files={}
for directory in ['penelope-machine-failure-checks','penelope-machine-failure-mutation-results']:
 for p in (Path('/tmp')/directory).rglob('*'):
  if p.is_file(): files[str(p.relative_to('/tmp'))]=p
for name in ['penelope-qualify-machine-failures.py','penelope-mutate-machine-failures.py','penelope-mutate-machine-failures-initial.py','penelope-machine-failure-mutations-initial.log','penelope-machine-failure-mutations.log','penelope-machine-failure-checks.log','penelope-preflight-race-first.log','penelope-machine-failure-graph-update.log','penelope-machine-failure-coverage-before.json','penelope-machine-failure-coverage-before.log','penelope-machine-failure-coverage-after.json','penelope-machine-failure-coverage-after.log','penelope-machine-failure-workspace-clean.log','penelope-machine-failure-workspace-coverage.json','penelope-machine-failure-workspace-coverage.log','penelope-machine-failure-workspace-ratchet.log','penelope-record-machine-failures.py']:
 p=Path('/tmp')/name
 assert p.is_file(),p
 files[name]=p
subprocess.run(['./scripts/check_coverage_ratchet.sh','/tmp/penelope-machine-failure-workspace-coverage.json'],cwd=root,check=True)
archive=out/'machine-failures.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name)
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(hashes)
 for m in t:
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==hashes[m.name]
coverage={}
for label,suffix in [('sqlite_before','coverage-before'),('sqlite_after','coverage-after'),('workspace','workspace-coverage')]:
 d=json.loads(Path('/tmp/penelope-machine-failure-'+suffix+'.json').read_text())
 coverage[label]=[entry['totals']['lines'] for entry in d['data']]
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'baseline_commit':'2358e4d','scope':'Development failure-path qualification; not final release certification','coverage':coverage,'ratchet':Path('/tmp/penelope-machine-failure-workspace-ratchet.log').read_text(),'mutation_checks':json.loads(Path('/tmp/penelope-machine-failure-mutation-results/checks.json').read_text()),'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':hashes}
(out/'machine-failures.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(hashes),'coverage':coverage,'ratchet':manifest['ratchet']},indent=2))
