import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-event-replay-qualification');out=Path('/tmp/penelope-050-event-replay-full-fuzz');out.mkdir(exist_ok=False)
base=Path('/home/ac/projects/penelope/target/event-replay-fuzz');binary=base/'x86_64-unknown-linux-gnu/release/fuzz_sqlite_machine';assert binary.is_file()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=subprocess.check_output(['git','ls-files','Cargo.toml','Cargo.lock','rust-toolchain.toml','crates','fuzz/Cargo.toml','fuzz/Cargo.lock','fuzz/fuzz_targets/fuzz_sqlite_machine.rs','scripts/seed-machine-corpus.py'],cwd=root,text=True).splitlines()
def hashes():return {p:sha((root/p).read_bytes()) for p in paths if (root/p).is_file()}
pre=hashes();binary_sha=sha(binary.read_bytes());(out/'source-pre.json').write_text(json.dumps(pre,indent=2)+'\n')
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(base)}
m={'status':'initial-checks','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_hashes':pre,'binary_sha256':binary_sha,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[],'rounds':[],'scope':'Supplementary augmented fuzz_sqlite_machine only; actual SQLite plus isolated event replay, restore boundary/reverse retries/future-head refusal. Clean reopens, not process kills. Existing full-target campaigns retain their original source/harness scopes.'}
def save():(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
def run(label,command):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(['taskset','-c','4-7',*map(str,command)],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'command':list(map(str,command)),'exit_code':r.returncode,'seconds':time.monotonic()-start};m['checks'].append(row);save();r.check_returncode();print(label,'PASS',flush=True)
save()
run('seed-generator',['python3','scripts/seed-machine-corpus.py','--root',out/'seeds'])
seeds=out/'seeds/fuzz_sqlite_machine';selected=sorted(seeds.iterdir());assert len(selected)==10
m['deterministic_seeds']={p.name:sha(p.read_bytes()) for p in selected};save()
for i,p in enumerate(selected):run('seed-'+str(i),[binary,'-runs=1',p])
run('smoke',[binary,seeds,'-runs=1000','-seed=1','-max_len=96'])
run('clippy',['cargo','+1.100.0','clippy','--manifest-path','fuzz/Cargo.toml','--bin','fuzz_sqlite_machine','--locked','--','-D','warnings'])
run('format',['cargo','+1.100.0','fmt','--all','--check'])
assert hashes()==pre and sha(binary.read_bytes())==binary_sha
m['status']='full-rounds-running';save();print('INITIAL_CHECKS_COMPLETE',flush=True)
for seed in [1,2,3]:
 corpus=out/f'corpus-{seed}';corpus.mkdir()
 # Keep independent original corpora; mutations from the smoke run do not seed rounds.
 for name in m['deterministic_seeds']:(corpus/name).write_bytes((seeds/name).read_bytes())
 command=['taskset','-c','4-7',str(binary),str(corpus),'-runs=100000',f'-seed={seed}','-max_len=96'];start=time.monotonic()
 with (out/f'round-{seed}.log').open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 m['rounds'].append({'seed':seed,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});save();r.check_returncode();print('round',seed,'PASS',flush=True)
m['source_after_sha256']=hashes();m['source_unchanged']=m['source_after_sha256']==pre;m['binary_unchanged']=sha(binary.read_bytes())==binary_sha;assert m['source_unchanged'] and m['binary_unchanged'];m['status']='complete';m['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('COMPLETE',flush=True)
