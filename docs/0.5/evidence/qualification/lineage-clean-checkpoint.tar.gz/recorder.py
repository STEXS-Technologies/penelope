import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/home/ac/projects/penelope');SOURCE='238380bd7d90da35495286c9616434ee045033ba';BASE=ROOT/'docs/0.5/evidence/qualification'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ci=read(Path('/tmp/penelope-pre-pr-238380b-ci.json'));assert ci['headSha']==SOURCE and ci['status']=='completed' and ci['conclusion']=='success';assert len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
reconciliation=read(Path('/tmp/penelope-pre-pr-238380b-archive-reconciliation.json'));assert reconciliation['source_commit']==SOURCE
qualified=read(BASE/'lineage-borrow-qualification.json');inputs=qualified['source_inputs_sha256']
for p,digest in inputs.items():assert sha(ROOT/p)==digest
index=read(ROOT/'docs/0.5/evidence/maintenance/plan-review-index.json');assert sha(ROOT/'docs/0.5/plan.md')==index['plan_sha256']
refs=collections.Counter()
for block in index['blocks']:
 for r in block['evidence']:
  p=ROOT/'docs/0.5/evidence/maintenance'/r['file'];assert p.is_file()
  if p.suffix=='.json':
   value=read(p)
   for token in r.get('pointer','').split('/')[1:]:
    token=token.replace('~1','/').replace('~0','~');value=value[int(token)] if isinstance(value,list) else value[token]
   refs['json_pointers']+=1
  else:refs['other_files']+=1
log=Path('/tmp/penelope-pre-pr-238380b-ci.log').read_text();observed={}
for job in ['Stable verification','Minimum supported Rust']:
 lines='\n'.join(s for s in log.splitlines() if s.startswith(job+'\t'))
 for item in index['phase_prose_and_integration_review']['current_named_checks']:assert re.search(r'test (?:[\w]+::)*'+re.escape(item['function'])+r' \.\.\. ok',lines),(job,item)
 observed[job]=len(index['phase_prose_and_integration_review']['current_named_checks'])
files={'recorder.py':Path(__file__),'archive-reconciliation.json':Path('/tmp/penelope-pre-pr-238380b-archive-reconciliation.json'),'ci.json':Path('/tmp/penelope-pre-pr-238380b-ci.json'),'ci.log':Path('/tmp/penelope-pre-pr-238380b-ci.log'),'package-verification.log':Path('/tmp/penelope-pre-pr-238380b-package-checks.log')}
for p in (ROOT/'target/pre-pr-238380b-package-checks/package').glob('*.crate'):files['packages/'+p.name]=p
assert len([n for n in files if n.startswith('packages/')])==10
hashes={n:sha(p) for n,p in files.items()};archive=BASE/'lineage-clean-checkpoint.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
record={'source_commit':SOURCE,'scope':'Clean committed source/artifact checkpoint after timeline borrowing and deterministic native-admission tests. Fresh ten-archive package verification, actual archive-content reconciliation and all seven CI jobs. No performance acceptance or release qualification granted.','ci':ci,'archives':reconciliation,'source_inputs_sha256':inputs,'test_and_coverage_evidence':'lineage-borrow-qualification.json','coverage_scope':'All 72 production hashes and all 449 tracked crate/workspace inputs match the earlier local patch qualification. Retains its 94.0809% result, not a new coverage run.','packaged_test_scope':'Clean archives match the final tested local-patch archives member-for-member except recorded VCS identity and any reconciled internal lock checksums. Actual clean archives retained. This input/content proof does not claim another 700-check extracted run.','requirement_reference_check':{'blocks':len(index['blocks']),'references':dict(refs),'named_ci_observations':observed,'limits':'Reference and test-name validity do not prove semantic completeness; historical reviews retain their original scopes.'},'performance_dispositions':'lineage-performance-followup.json','remaining':['Performance findings require explicit evidence-backed disposition under plan §13.2.','Full immutable-source chaos remains incomplete and excluded from this stabilization pass by the user.','Dated release notes, tag, publication and merge remain deferred.'],'pr_opened':False,'archive':{'file':archive.name,'sha256':sha(archive),'members_sha256':hashes}}
(BASE/'lineage-clean-checkpoint.json').write_text(json.dumps(record,indent=2)+'\n')
print('Clean checkpoint retained:',SOURCE,'seven green CI jobs, ten content-reconciled archives')
