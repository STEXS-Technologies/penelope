import hashlib,json,re,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=root/'docs/0.5/evidence/qualification';raw=Path('/tmp/penelope-050-final-qualified-chaos');retry=Path('/tmp/penelope-050-final-qualified-chaos-pinned');sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((raw/'manifest.json').read_text());r=json.loads((retry/'manifest.json').read_text());log=(raw/'campaign.log').read_text()
assert j['exit_code']==1 and j['source_sha256']==j['source_after_sha256'] and not j['tracked_diff']
assert log.endswith("Error: Rust version string does not start with 'rustc'!\n")
assert len(re.findall(r'^Done 100000 runs in ',log,re.M))==21
assert r['source_sha256']==j['source_sha256'] and r['pinned_worker_smoke_exit_code']==0
assert 'Done 1000 runs in ' in (retry/'pinned-worker-smoke.log').read_text()
files={
 'failed/manifest.json':raw/'manifest.json','failed/campaign.log':raw/'campaign.log','failed/toolchain-diagnosis.json':raw/'toolchain-diagnosis.json',
 'drivers/failed.py':Path('/tmp/penelope-050-run-final-qualified-chaos.py'),'drivers/retry.py':Path('/tmp/penelope-050-run-final-qualified-chaos-pinned.py'),'drivers/cargo':Path('/tmp/penelope-050-final-pinned-tools/cargo'),
 'retry/initial-manifest.json':retry/'manifest.json','retry/pinned-worker-smoke.log':retry/'pinned-worker-smoke.log','drivers/recorder.py':Path(__file__)}
corpus=sorted(f for f in (raw/'corpus-after-diagnostic').rglob('*') if f.is_file());tree=hashlib.sha256()
for f in corpus:
 name='failed/corpus-after-diagnostic/'+f.relative_to(raw/'corpus-after-diagnostic').as_posix();files[name]=f;tree.update(name.encode()+b'\0'+sha(f.read_bytes()).encode()+b'\n')
archive=out/'final-chaos-toolchain-interruption.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,f in files.items():t.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for m in t:
  assert m.isfile();assert t.extractfile(m).read()==files[m.name].read_bytes()
record={'source_commit':j['source_commit'],'disposition':'incomplete_tooling_failure_not_release_qualification','failed_attempt':{'exit_code':j['exit_code'],'start_utc':j['start_utc'],'end_utc':j['end_utc'],'seconds':j['seconds'],'completed_100000_run_fuzz_batches':21,'required_batches':84,'failure_before_target':'fuzz_worker_protocol','terminal_error':"Rust version string does not start with 'rustc'!",'source_before_after_identical':True,'tracked_diff':''},'diagnosis':json.loads((raw/'toolchain-diagnosis.json').read_text()),'retry':{'status_at_recording':r['status'],'pid':r['pid'],'raw_directory':str(retry),'source_sha256_matches_failed_attempt':True,'selection':r['toolchain_selection'],'pinned_worker_smoke_exit_code':r['pinned_worker_smoke_exit_code'],'toolchain_versions':r['toolchain_versions'],'tool_sha256':r['tool_sha256'],'limit':'This start record is not a terminal campaign result. Source and tool identities must be checked again after completion. The failed attempt contributes no completed-round certification.'},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members':len(files),'non_corpus_members_sha256':{n:sha(f.read_bytes()) for n,f in files.items() if not n.startswith('failed/corpus-after-diagnostic/')},'corpus_members':len(corpus),'corpus_tree_sha256':tree.hexdigest(),'corpus_tree_algorithm':'Sorted archive names; hash name UTF8, NUL, lowercase SHA256 of member bytes, newline. Corpus was moved after the subsequent rolling-nightly1000-run worker smoke; its worker entries include that diagnostic and are not misrepresented as failed-run inputs.'},'limits':['The failure is a real terminal nonzero tool invocation, not an observation timeout or an inferred stop.','The rolling nightly file replacement was observed near failure; exact failing subprocess stdout was not captured separately, so causation remains an inference.','Other campaign drivers were left running. No product source or global toolchain was changed for the retry.','The installed dated nightly is mapped only for this qualification invocation through the retained PATH shim; development stable and MSRV policies are unchanged.']}
(out/'final-chaos-toolchain-interruption.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified archived members',len(files),'compressed bytes',archive.stat().st_size)
