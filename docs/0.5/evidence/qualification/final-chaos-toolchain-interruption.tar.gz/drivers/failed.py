import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-final-chaos');out=Path('/tmp/penelope-050-final-qualified-chaos');out.mkdir(exist_ok=False)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert revision=='8dfe89d343f498d58b2e752980b43fa99e20c00d'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
names=subprocess.check_output(['git','ls-files','Cargo.toml','Cargo.lock','rust-toolchain.toml','crates','fuzz','scripts/run_pure_chaos_drill.sh','scripts/run_bounded_fuzz.sh'],cwd=root,text=True).splitlines()
hashes={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if (root/n).is_file()}
args=['taskset','-c','4-7','./scripts/run_pure_chaos_drill.sh']
selected={'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/final-qualified-chaos','PENELOPE_CHAOS_ITERATIONS':'3','PENELOPE_CHAOS_PROPTEST_CASES':'10000','PENELOPE_CHAOS_FUZZ_RUNS':'100000'}
record={'source_commit':revision,'command':args,'environment_overrides':selected,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'seeds':'Runner default: per-round property/fuzz seed 1, 2, 3.','source_sha256':hashes,'status':'running'}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');start=time.monotonic()
with (out/'campaign.log').open('w') as log:r=subprocess.run(args,cwd=root,env={**os.environ,**selected},stdout=log,stderr=subprocess.STDOUT)
record.update(status='completed',exit_code=r.returncode,seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after_sha256={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in hashes},tracked_diff=subprocess.check_output(['git','diff','HEAD','--'],cwd=root,text=True));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['source_after_sha256']==hashes and not record['tracked_diff'];r.check_returncode();print('completed',flush=True)
