import json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-repeated-kill-final');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/repeated-kill'};checks=[]
for version in ['1.100.0','1.89.0']:
 command=['taskset','-c','4-7','cargo','+'+version,'test','-p','penelope-sqlite','--lib','--locked','machine::tests::','--','--nocapture'];start=time.monotonic()
 r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True);label='machine-tests-'+version
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr);checks.append({'label':label,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
 assert r.stdout.count('exact_prefix=true')==48
 assert 'test machine::tests::repeated_sigkill_on_a_growing_journal_preserves_every_prefix_and_exact_retry ... ok' in r.stdout
 print(label,'PASS',flush=True)
command=['taskset','-c','4-7','cargo','+1.100.0','clippy','-p','penelope-sqlite','--lib','--tests','--locked','--','-D','warnings'];r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
(out/'clippy.stdout').write_text(r.stdout);(out/'clippy.stderr').write_text(r.stderr);checks.append({'label':'clippy','command':command,'exit_code':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode();print('clippy PASS',flush=True)
