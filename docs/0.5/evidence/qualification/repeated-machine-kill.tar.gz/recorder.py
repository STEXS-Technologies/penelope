import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-repeated-kill-qualified');dest=root/'docs/0.5/evidence/qualification';source='crates/penelope-sqlite/src/machine/tests.rs';sha=lambda b:hashlib.sha256(b).hexdigest()
checks=json.loads((out/'checks.json').read_text());assert len(checks)==3 and all(c['exit_code']==0 for c in checks)
observations=[]
for version in ['1.100.0','1.89.0']:
 s=(out/('machine-tests-'+version+'.stdout')).read_text();rows=re.findall(r'chain seed=(\d+) event=(\d+) phase=([a-z-]+) signal=9 exact_prefix=true',s)
 assert len(rows)==48 and len(set(rows))==48
 assert {(int(seed),int(event)) for seed,event,_ in rows}=={(seed,event) for seed in [1,2,3] for event in range(1,17)}
 counts=collections.Counter((seed,phase) for seed,_,phase in rows);assert len(counts)==24 and set(counts.values())=={2}
 assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in s
 assert 'test machine::tests::repeated_sigkill_on_a_growing_journal_preserves_every_prefix_and_exact_retry ... ok' in s
 observations.append({'compiler':version,'machine_unit_tests_passed':9,'chain_sigkills':48,'seeds':[1,2,3],'accepted_chain_length_per_database':16,'each_commit_boundary_per_seed':2,'verified_rows':rows})
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert base.startswith('7be5280')
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==[source]
production=json.loads((dest/'history-partition-checkpoint.json').read_text())['coverage']['source_sha256']
for name,h in production.items():assert sha((root/name).read_bytes())==h
fmt=subprocess.run(['cargo','fmt','--all','--check'],cwd=root,capture_output=True,text=True);assert fmt.returncode==0
(out/'fmt.stdout').write_text(fmt.stdout);(out/'fmt.stderr').write_text(fmt.stderr)
files={}
for label,folder in [('qualified',out),('initial-compile-type-error',Path('/tmp/penelope-050-repeated-kill')),('second-compile-type-error',Path('/tmp/penelope-050-repeated-kill-followup')),('passing-tests-before-lint-fixes',Path('/tmp/penelope-050-repeated-kill-final'))]:
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for p in Path('/tmp').glob('penelope-050-repeated-kill*.py'):files['drivers/'+p.name]=p
files['recorder.py']=Path(__file__);files['tests.rs']=root/source
archive=dest/'repeated-machine-kill.tar.gz';members={n:sha(p.read_bytes()) for n,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as t:
 for n,h in members.items():assert sha(t.extractfile(n).read())==h
m={'scope':'Supplementary serialized SQLite crash/model qualification. Three seeded growing journals undergo16 successive real SIGKILLs each, rotating all eight commit boundaries twice per seed. Full history, snapshot, raw event/intent row counts and exact retries are checked after each death and after a second reopen. The accepted-prefix arithmetic and event/intent bytes/identities are checked independently of the journal restore used by the child.','base_commit':base,'source':{'path':source,'sha256':sha((root/source).read_bytes()),'production_change':False,'test_only_unix_module':True},'checks':checks,'format_check_exit_code':0,'observations':observations,'production_files_unchanged_from_current_package_checkpoint':len(production),'initial_attempts':'Retained compiler failures used unsupported SQLite FromSql count types (usize, then u64); corrected to checked u32. First passing test runs preceded three strict-Clippy style fixes; final qualified source was rerun on both compilers and passes strict Clippy. No production failure is inferred.','limits':['This is a seeded crash/model test, not a claim that the clean-reopen libFuzzer target performs process kills. Three seed profiles do not cover arbitrary operation sequences or power loss.','Independent arithmetic/byte expectations still use production preparation to form the exact requested record; retained record equality complements independently checked event/state/intent payload semantics.','The long full-target fuzz campaign retains its older test/harness source scope. This supplements it; it does not restart or silently replace that campaign.','Current all-ten package and coverage checkpoint predates this test addition. Final source/harness/artifact reconciliation, retained performance findings and remaining plan review stay open.'],'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members}}
(dest/'repeated-machine-kill.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified9 machine tests and48 chain SIGKILLs per compiler; all phases twice per seed,72 unchanged production files and',len(members),'archive members.')
