import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');p=root/'crates/penelope-ports/src/machine/recovery.rs';original=p.read_bytes();s=original.decode();out=Path('/tmp/penelope-050-replay-recovery-mutations');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/replay-recovery'}
mutations=[('skip-exact-comparison',s.replace('if prepared.batch.record != self.batch.record','if false && prepared.batch.record != self.batch.record').replace('|| prepared.batch.event != self.batch.event','|| false && prepared.batch.event != self.batch.event').replace('|| prepared.batch.state != self.batch.state','|| false && prepared.batch.state != self.batch.state').replace('|| prepared.batch.intents != self.batch.intents','|| false && prepared.batch.intents != self.batch.intents'),'event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions'),('retain-replayed-effects',s.replace('drop(owner.take_intents());','// negative control: leave replayed effects pending'),'event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot')]
results=[]
try:
 for name,changed,test in mutations:
  assert changed!=s
  p.write_text(changed)
  cmd=['cargo','+1.100.0','test','-p','penelope-ports','--test','machine_preparation','--locked',test,'--','--exact']
  run=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True);(out/(name+'.log')).write_text(run.stdout+run.stderr)
  assert run.returncode!=0 and 'test result: FAILED' in run.stdout and 'could not compile' not in run.stderr,(name,run.stdout,run.stderr)
  results.append({'mutation':name,'command':cmd,'exit_code':run.returncode,'compiled_and_failed_named_test':True})
finally:
 p.write_bytes(original)
 assert p.read_bytes()==original
(out/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original).hexdigest(),'restored_byte_exact':True,'results':results},indent=2)+'\n')
print('both compiled mutations caught; source restored',flush=True)
