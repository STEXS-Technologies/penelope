"""Reconcile current clean packages, source CI and retained requirement evidence.

This records checks, not release acceptance. It does not run a chaos campaign,
create a PR, date release notes, tag, publish, or accept performance exceptions.
"""
import collections
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/ac/projects/penelope')
SOURCE = '7ab93d2cbb426f1e058fb7abc76c42c3f8582178'
DEST = ROOT / 'docs/0.5/evidence/qualification'
RAW = Path('/tmp/penelope-050-pre-pr-packaged-workspace')
DRIVER = Path('/tmp/penelope-050-pre-pr-package-driver')
COVERAGE = Path('/tmp/penelope-050-pre-pr-coverage')
MAINTENANCE = ROOT / 'docs/0.5/evidence/maintenance'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def json_pointer(value, pointer):
    assert pointer == '' or pointer.startswith('/'), pointer
    if pointer:
        for segment in pointer[1:].split('/'):
            segment = segment.replace('~1', '/').replace('~0', '~')
            if isinstance(value, list):
                assert segment.isdigit() and (segment == '0' or not segment.startswith('0'))
                value = value[int(segment)]
            else:
                value = value[segment]
    return value


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
previous = read(DEST / 'graph-start-package-checkpoint.json')
previous_archive = DEST / previous['archive']['file']
assert sha(previous_archive.read_bytes()) == previous['archive']['sha256']
with tarfile.open(previous_archive) as archive:
    members = {m.name: sha(archive.extractfile(m).read()) for m in archive if m.isfile()}
assert members == previous['archive']['members_sha256']

paths = git('ls-files').decode().splitlines()
build_paths = [p for p in paths if p.startswith(('crates/', 'ci/', 'fuzz/'))
               or Path(p).name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml')]
source_hashes = {}
for name in build_paths:
    path = ROOT / name
    content = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
    assert content == git('show', SOURCE + ':' + name), name
    source_hashes[name] = {'git_content_sha256': sha(content),
                           'build_content_sha256': sha(path.read_bytes())}
    if path.is_symlink():
        source_hashes[name]['link_target'] = os.readlink(path)

changed = git('diff', '--name-only', previous['source_commit'], SOURCE, '--',
              'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'ci', 'fuzz').decode().splitlines()
assert changed == ['crates/penelope-sqlite/tests/support/machines.rs'], changed
for name, digest in previous['coverage']['source_sha256'].items():
    assert sha((ROOT / name).read_bytes()) == digest, name

ci = read(Path('/tmp/penelope-pre-pr-ci.json'))
assert ci['headSha'] == SOURCE and ci['status'] == 'completed' and ci['conclusion'] == 'success'
assert len(ci['jobs']) == 7 and all(j['conclusion'] == 'success' for j in ci['jobs'])
ci_log = Path('/tmp/penelope-pre-pr-ci.log').read_text()
index = read(MAINTENANCE / 'plan-review-index.json')
assert sha((ROOT / 'docs/0.5/plan.md').read_bytes()) == index['plan_sha256']
reference_counts = collections.Counter()
for block in index['blocks']:
    for reference in block['evidence']:
        target = MAINTENANCE / reference['file']
        assert target.is_file(), target
        if target.suffix == '.json':
            json_pointer(read(target), reference.get('pointer', ''))
            reference_counts['json_pointers'] += 1
        else:
            reference_counts['other_file_targets'] += 1
named = index['phase_prose_and_integration_review']['current_named_checks']
observed = {}
for job in ('Stable verification', 'Minimum supported Rust'):
    lines = '\n'.join(line for line in ci_log.splitlines() if line.startswith(job + '\t'))
    for item in named:
        assert re.search(r'test (?:[\w]+::)*' + re.escape(item['function']) + r' \.\.\. ok', lines), (job, item)
    observed[job] = len(named)

# Preserve older source scopes. Record every stale hash instead of rewriting old
# audits or implying that a historical review was performed on the current tip.
audit_hashes = []
def check_hash_maps(value, location, record):
    if isinstance(value, dict):
        for key, child in value.items():
            pointer = location + '/' + key.replace('~', '~0').replace('/', '~1')
            if isinstance(child, str) and re.fullmatch('[0-9a-f]{64}', child):
                path = ROOT / key
                if path.is_file():
                    actual = sha(path.read_bytes())
                    audit_hashes.append({'record': record, 'pointer': pointer, 'path': key,
                                         'recorded_sha256': child, 'current_sha256': actual,
                                         'matches': actual == child})
            check_hash_maps(child, pointer, record)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            check_hash_maps(child, location + '/' + str(i), record)
for name in ('invariant-audit', 'core-contract-audit', 'phase-audit',
             'test-layer-audit', 'integration-contract-audit', 'plan-review-index'):
    check_hash_maps(read(MAINTENANCE / (name + '.json')), '', name + '.json')

for observation in audit_hashes:
    name = observation['path']
    if observation['matches']:
        disposition = 'Recorded bytes match the current checkout.'
    elif name in previous['coverage']['source_sha256']:
        disposition = 'Historical production identity retained; current bytes match the later clean-package checkpoint and fresh current-source coverage.'
    elif name.startswith('fuzz/'):
        disposition = 'Historical fuzz input identity retained; current bounded CI passes. Full corrected-source campaign remains unrun.'
    elif name.startswith('docs/'):
        disposition = 'Historical document identity retained. Current plan references resolve; current verification records superseding status. Hash equality is not claimed.'
    elif name.endswith('Cargo.toml'):
        disposition = 'Historical manifest retained; current ten candidate versions, dependency order, source CI and clean archives are independently verified.'
    else:
        disposition = 'Historical source/check identity retained; current bytes are inventoried and checked through current CI and packaged tests within their stated scope. No rerun of the historical experiment is claimed.'
    observation['disposition'] = disposition

package_checks = read(RAW / 'checks.json')
assert len(package_checks) == 8 and all(c['exit_code'] == 0 for c in package_checks)
driver_checks = read(DRIVER / 'checks.json')
assert len(driver_checks) == 3
assert driver_checks[0]['exit_code'] == driver_checks[2]['exit_code'] == 0
assert driver_checks[1]['exit_code'] == 1 and (DRIVER / 'recorder-interruption.json').is_file()
assert read(DRIVER / 'source-before.json') == read(DRIVER / 'source-after.json')
observations = []
for compiler in ('1.100.0', '1.89.0'):
    text = (RAW / ('tests-' + compiler + '.stdout')).read_text()
    reports = re.findall(r'(?m)^(?:test result: )?ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert len(reports) == 97 and sum(int(r[0]) for r in reports) == 700
    assert all(r[1] == r[2] == '0' for r in reports)
    pattern = r'^test ([^\n]+?) \.\.\.(?: ok)? *$'
    previous_names = collections.Counter(re.findall(pattern, (Path('/tmp/penelope-050-graph-start-packaged-workspace') / ('tests-' + compiler + '.stdout')).read_text(), re.M))
    current_names = collections.Counter(re.findall(pattern, text, re.M))
    assert current_names == previous_names, (compiler, current_names - previous_names, previous_names - current_names)
    observations.append({'compiler': compiler, 'harness_summaries': 97,
                         'reported_passes': 700, 'named_observations': sum(current_names.values()), 'named_multiset_matches_previous_checkpoint': True, 'failed': 0, 'ignored': 0})
packages = read(RAW / 'archives.json')
assert len(packages) == 10 and all(p['vcs']['git']['sha1'] == SOURCE
    and not p['vcs']['git'].get('dirty', False) for p in packages)
archive_root = ROOT / 'target/pre-pr-package-checks/package'
for package in packages:
    assert sha((archive_root / package['archive']).read_bytes()) == package['sha256']
with tarfile.open(archive_root / 'penelope-sqlite-0.5.0.crate') as archive:
    assert archive.extractfile('penelope-sqlite-0.5.0/tests/support/machines.rs').read() == (
        ROOT / 'crates/penelope-sqlite/tests/support/machines.rs').read_bytes()
lock_diff = read(RAW / 'external-lock-diff.json')
assert not lock_diff['added']
assert {row[0] for row in lock_diff['removed']} == {'arbitrary', 'jobserver', 'libfuzzer-sys'}

coverage_checks = read(COVERAGE / 'checks.json')
assert len(coverage_checks) == 3 and all(c['exit_code'] == 0 for c in coverage_checks)
assert (COVERAGE / 'source-commit.txt').read_text().strip() == SOURCE
coverage = read(COVERAGE / 'coverage.json')['data'][0]
assert coverage['totals']['lines']['percent'] >= previous['coverage']['ratchet']
worktree = Path('/home/ac/projects/.penelope-pre-pr-7ab93d2')
coverage_hashes = {str(Path(f['filename']).relative_to(worktree)):
                   sha(Path(f['filename']).read_bytes()) for f in coverage['files']}
assert coverage_hashes == previous['coverage']['source_sha256']

metadata = json.loads(subprocess.check_output(['cargo', '+1.100.0', 'metadata',
                    '--locked', '--no-deps', '--format-version=1'], cwd=worktree))
versions = {p['name']: p['version'] for p in metadata['packages'] if p.get('publish') != []}
order = subprocess.check_output(['python3', 'scripts/publish-order.py', '--emit'],
                               cwd=worktree, text=True).splitlines()
assert len(order) == len(versions) == 10 and set(order) == set(versions)
assert set(versions.values()) == {'0.5.0'}
assert not re.search(r'^##\s+\[?0\.5\.0\b', (ROOT / 'CHANGELOG.md').read_text(), re.M)

files = {'recorder.py': Path(__file__), 'ci/run.json': Path('/tmp/penelope-pre-pr-ci.json'),
         'ci/run.log': Path('/tmp/penelope-pre-pr-ci.log')}
for label, folder in (('packages', RAW), ('package-driver', DRIVER), ('coverage', COVERAGE)):
    files.update({label + '/' + p.name: p for p in folder.iterdir() if p.is_file()})
for name in ('package-driver', 'test-packaged-workspace', 'run-coverage'):
    files['drivers/' + name + '.py'] = Path('/tmp/penelope-050-pre-pr-' + name + '.py')
files['drivers/test-packaged-workspace-resume.py'] = Path('/tmp/penelope-050-pre-pr-test-packaged-workspace-resume.py')
files.update({'archives/' + p.name: p for p in archive_root.glob('*.crate')})
archive_path = DEST / 'pre-pr-reconciliation.tar.gz'
members = {name: sha(path.read_bytes()) for name, path in files.items()}
with tarfile.open(archive_path, 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    assert {m.name: sha(archive.extractfile(m).read()) for m in archive if m.isfile()} == members
record = {
    'scope': 'Current immutable source packages, CI, coverage and requirement evidence reconciliation. No release completion or performance exception is declared.',
    'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': SOURCE,
    'source_inputs': source_hashes, 'previous_checkpoint': previous['source_commit'],
    'changed_crate_inputs': changed,
    'change_disposition': 'Only the test support helper changes; non-fuzz tests retain their 10-second deadline and fuzz builds allow 60 seconds. Both packaged compiler suites freshly verify these bytes. Production library inputs match the preceding checkpoint.',
    'previous_archive_verified': {'file': previous_archive.name, 'sha256': sha(previous_archive.read_bytes()), 'members': len(previous['archive']['members_sha256'])},
    'ci': ci, 'named_current_ci_checks': observed,
    'plan_review': {'blocks': len(index['blocks']), 'plan_sha256': index['plan_sha256'],
                    'reference_counts': dict(reference_counts),
                    'audit_hash_observations': audit_hashes,
                    'limits': 'Reference validity and test-name observations supplement the scoped semantic reviews; neither proves requirement completeness. Historical hash differences remain explicit.'},
    'packages': packages, 'package_checks': package_checks, 'driver_checks': driver_checks,
    'test_observations': observations, 'external_lock_diff': lock_diff,
    'coverage': {'checks': coverage_checks, 'lines': coverage['totals']['lines'],
                 'ratchet': previous['coverage']['ratchet'], 'source_sha256': coverage_hashes},
    'release_control': {'versions': versions, 'dependency_order': order,
                        'changelog': 'Unreleased; dated entry intentionally deferred while qualification is incomplete.',
                        'pr_opened': False, 'tag_or_publish_performed': False},
    'open': ['Full immutable-source chaos remains incomplete and was not run at the user\'s request; exclusion is not acceptance or a waiver.',
             'Performance findings require their own evidence-backed disposition; no exception is accepted by this reconciliation.',
             'A complete 0.5 release, dated release entry, tag and publication remain deferred.'],
    'archive': {'file': archive_path.name, 'sha256': sha(archive_path.read_bytes()), 'members_sha256': members},
}
(DEST / 'pre-pr-reconciliation.json').write_text(json.dumps(record, indent=2) + '\n')
print('Reconciled ten clean packages, 700 checks per compiler, current CI, fresh coverage and', len(index['blocks']), 'plan review blocks')
