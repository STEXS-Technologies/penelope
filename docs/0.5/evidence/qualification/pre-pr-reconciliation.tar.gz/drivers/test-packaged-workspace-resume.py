import subprocess,os,json,hashlib,tarfile,time,shutil,tomllib
from pathlib import Path
root=Path('/home/ac/projects/.penelope-pre-pr-7ab93d2')
out=Path('/tmp/penelope-050-pre-pr-packaged-workspace')
unpacked=Path('/home/ac/projects/penelope/target/pre-pr-package-unpacked')
original=tomllib.loads((out/'Cargo.lock-original').read_text())
original_external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in original['package'] if p.get('source')}
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/pre-pr-package-tests'}
# Initial attempt created a genuinely fresh target; resume retains its compiled artifacts and raw outputs.
checks=json.loads((out/'checks.json').read_text())
commands=[('lock-normalization',['cargo','+1.100.0','metadata','--offline','--format-version','1']),('metadata',['cargo','+1.100.0','metadata','--locked','--format-version','1'])]
commands += [('tests-'+v,['cargo','+'+v,'test','--workspace','--all-targets','--all-features','--locked']) for v in ['1.100.0','1.89.0']]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=(subprocess.CompletedProcess(args,0,(out/(label+'.stdout')).read_text(),(out/(label+'.stderr')).read_text()) if any(c['label']==label and c['exit_code']==0 for c in checks) else subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True))
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks[:]=[c for c in checks if c['label']!=label];checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
 if label.startswith('tests-'):
  for name in ['generated_tables_and_hierarchies_match_reference_and_single_level_flat_dispatch','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap','event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot','event_replay_refuses_wrong_predecessor_model_codec_limits_and_duplicate_revision','event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions']:
   assert r.stdout.count('test '+name+' ... ok')==1,(label,name)
  import re
  reports=re.findall(r'(?m)^(?:test result: )?ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',r.stdout)
  assert len(reports)==97 and sum(int(x[0]) for x in reports)==700 and all(x[1]=='0' and x[2]=='0' for x in reports),(label,reports)
 if label=='lock-normalization':
  lock=(unpacked/'Cargo.lock').read_bytes();(out/'Cargo.lock').write_bytes(lock)
  data=tomllib.loads(lock.decode());external={(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in data['package'] if p.get('source')}
  assert external<=original_external,external-original_external
  (out/'external-lock-diff.json').write_text(json.dumps({'added':sorted(external-original_external),'removed':sorted(original_external-external)},indent=2)+'\n')
 if label=='metadata':
  data=json.loads(r.stdout);selected=[p for p in data['packages'] if p['name'].startswith('penelope')]
  assert len(selected)==10 and all(p['version']=='0.5.0' and Path(p['manifest_path']).is_relative_to(unpacked) for p in selected)
# Execute the exact packaged example with both supported compilers.
example=unpacked/'penelope-0.5.0/examples/door_machine.rs'
assert example.read_bytes()==(root/'crates/penelope/examples/door_machine.rs').read_bytes()
expected=json.loads((root/'docs/0.5/evidence/qualification/door-ergonomics.json').read_text())['expected_trace']
for v in ['1.100.0','1.89.0']:
 label='door-'+v;args=['cargo','+'+v,'run','-p','penelope','--example','door_machine','--locked']
 started=time.monotonic();r=(subprocess.CompletedProcess(args,0,(out/(label+'.stdout')).read_text(),(out/(label+'.stderr')).read_text()) if any(c['label']==label and c['exit_code']==0 for c in checks) else subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True))
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks[:]=[c for c in checks if c['label']!=label];checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-started});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 r.check_returncode();assert r.stdout.splitlines()==expected
# The ownership regression consumer is also the exact packaged example.
example=unpacked/'penelope-0.5.0/examples/prepared_decisions.rs'
assert example.read_bytes()==(root/'crates/penelope/examples/prepared_decisions.rs').read_bytes()
assert 'drop(graph_definition);' in example.read_text()
expected_path=Path('/tmp/penelope-050-graph-start-qualification/consumer-1.100.0.stdout')
proof=json.loads((root/'docs/0.5/evidence/qualification/graph-start-ownership.json').read_text())
assert hashlib.sha256(expected_path.read_bytes()).hexdigest()==proof['archive']['members_sha256']['raw/consumer-1.100.0.stdout']
for v in ['1.100.0','1.89.0']:
 label='decisions-'+v;args=['cargo','+'+v,'run','-p','penelope','--example','prepared_decisions','--locked']
 started=time.monotonic();r=(subprocess.CompletedProcess(args,0,(out/(label+'.stdout')).read_text(),(out/(label+'.stderr')).read_text()) if any(c['label']==label and c['exit_code']==0 for c in checks) else subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True))
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks[:]=[c for c in checks if c['label']!=label];checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-started});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 r.check_returncode();assert r.stdout==expected_path.read_text()
assert (out/'Cargo.lock').read_bytes()==(unpacked/'Cargo.lock').read_bytes()
print('completed',flush=True)
