import hashlib,json,re,subprocess,tarfile
from pathlib import Path
r=Path('/home/ac/projects/.penelope-050-candidate');d=r/'docs/0.5/evidence/qualification';sha=lambda b:hashlib.sha256(b).hexdigest();base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
source_names=['scripts/check-nested-example.py','.github/workflows/ci.yml','.github/workflows/release.yml','crates/penelope/examples/nested_order.rs','crates/penelope-core/tests/machine_allocations.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/tests/machine_hierarchy.rs']
checkpoint=json.loads((d/'event-replay-checkpoint.json').read_text());assert len(checkpoint['coverage']['source_sha256'])==72
for p,h in checkpoint['coverage']['source_sha256'].items():assert sha((r/p).read_bytes())==h
for version in ['stable','msrv']:
 assert 'Nested example: six decisions and exact staged traces verified' in Path('/tmp/penelope-050-nested-ci-'+version+'-final.log').read_text()
 s=Path('/tmp/penelope-050-nested-enum-'+version+'-final.log').read_text();assert s.count('10000 iterations, Counts { allocations: 0, reallocations: 0, deallocations: 0, requested_bytes: 0 }')==2
for name in ['penelope-050-nested-enum-msrv-clippy-final.log','penelope-050-nested-ci-workspace-clippy-qualified.log']:
 s=(Path('/tmp')/name).read_text();assert 'Finished' in s and 'error:' not in s
assert 'Ran 75 tests' in Path('/tmp/penelope-050-nested-ci-script-tests.log').read_text() and 'OK' in Path('/tmp/penelope-050-nested-ci-script-tests.log').read_text()
assert 'all GitHub Actions are pinned' in Path('/tmp/penelope-050-nested-ci-action-pins.log').read_text()
assert (r/'.github/workflows/ci.yml').read_text().count('run: python3 scripts/check-nested-example.py')==2
assert (r/'.github/workflows/release.yml').read_text().count('run: python3 scripts/check-nested-example.py')==1
controls=json.loads(Path('/tmp/penelope-050-nested-ci-controls-followup/manifest.json').read_text());assert controls['restored_byte_exact'] and controls['restored_check_exit_code']==0 and len(controls['negative_controls'])==3;assert controls['source_sha256']==sha((r/'crates/penelope/examples/nested_order.rs').read_bytes())
plan=(r/'docs/0.5/plan.md').read_text();block=plan.split('### 9.2 HSM ergonomic profile\n')[1].split('### 9.3')[0];requirements=re.findall(r'^\d+\. (.*)$',block,re.M);assert len(requirements)==8
assessments=[
 'OrderState/Open own the nested state data once and OrderEvent owns event variants once. Node is a separate typed identity key, with explicit leaf/parent mapping; no claim of eliminating that mapping boilerplate.',
 'The model uses Rust matches and typed Node keys, with no string transition tables or reflection registry.',
 'Draft bubbles through Open to the root cancellation policy. Paid and Cancelled explicitly reject it. Removing the paid refusal lets root cancellation run and is caught by the checker.',
 'One checked-in golden verifies all six complete public traces, including ordered hooks, both guards without hooks/state changes, external self-reentry and parent cancellation. Stable/MSRV local runs pass and CI/release are wired to the same checker; remote execution of this new wiring remains pending.',
 'Receipt data exists only in OrderState::Paid; enum layout enforces that structural distinction. Runtime domain validity remains a separate model check.',
 'MemoryMachine::restore calls model validation; Hierarchical validation constructs the bounded StatePath before application validation. Existing malformed/depth/path tests pass in9084239 CI, not inferred from console output.',
 'The existing allocator probe now owns an inline, non-Clone Connection::{Disconnected,Connected::{Idle,Active{messages}}}. Both compilers observe zero allocation/reallocation/deallocation/requested bytes across10000 flat and10000 hierarchical attempts, with independent expected state per step and the existing positive allocator control retained.',
 'The golden contains source state, attempted event and stable guard code for both refusals. Inspection is local; rejected events do not acquire an accepted journal record.'
]
files={'source/'+p:r/p for p in source_names}
for prefix in ['penelope-050-nested-ci-','penelope-050-nested-enum-']:
 for p in Path('/tmp').glob(prefix+'*.log'):files['logs/'+p.name]=p
for label in ['penelope-050-nested-ci-controls','penelope-050-nested-ci-controls-followup']:
 for p in (Path('/tmp')/label).iterdir():files[label+'/'+p.name]=p
 files['drivers/'+label+'.py']=Path('/tmp')/(label+'.py')
files['recorder.py']=Path(__file__);members={n:sha(p.read_bytes()) for n,p in files.items()};archive=d/'nested-ergonomics.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 for name,h in members.items():assert sha(t.extractfile(name).read())==h
v={'scope':'Plan9.2 eight ergonomic criteria: CI trace checker, genuine leaf/root refusal example and actual unboxed nested-enum allocation fixture. Test/example/workflow additions only; all72 production source identities remain byte-identical to9084239. Not all-ten fresh archive qualification or a user ergonomics study.','base_commit':base,'source_sha256':{p:sha((r/p).read_bytes()) for p in source_names},'production_files_unchanged':72,'criteria':[{'id':'9.2.'+str(i),'requirement':req,'assessment':assessment,'status':'supported_in_stated_scope_final_qualification_open'} for i,(req,assessment) in enumerate(zip(requirements,assessments),1)],'checks':{'nested_public_trace_stable_exit':0,'nested_public_trace_msrv_exit':0,'enum_allocation_probe_stable_exit':0,'enum_allocation_probe_msrv_exit':0,'msrv_probe_clippy_exit':0,'stable_workspace_clippy_exit':0,'script_unit_tests':75,'action_pins_exit':0,'format_exit':0},'negative_controls':controls,'retained_failures':'Initial MSRV Clippy rejected an existing unwrap in the allocation fixture. The fixture now returns its typed capacity error; final checks pass. Initial two example controls retain their earlier source hash; follow-up controls bind the current example and add missing-leaf-refusal mutation.','archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'member_count':len(files),'members_sha256':members},'remaining':['New remote CI wiring and final package/source reconciliation retain their own scopes.','Production full-source and supplementary fuzz campaigns remain running; no restart or completion is inferred.','Performance findings and remaining normative plan clauses remain open.','No new public API, mandatory macro, runtime, heap requirement or publication/tag authorization is introduced.']}
(d/'nested-ergonomics.json').write_text(json.dumps(v,indent=2)+'\n');print('Verified',len(files),'archive members; eight criteria, both compilers and three caught semantic controls')
