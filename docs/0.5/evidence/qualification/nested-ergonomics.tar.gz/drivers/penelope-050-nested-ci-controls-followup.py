import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');source=root/'crates/penelope/examples/nested_order.rs';original=source.read_bytes();text=original.decode();out=Path('/tmp/penelope-050-nested-ci-controls-followup');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTUP_TOOLCHAIN':'1.100.0','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/graph-example'};results=[]
try:
 for label,old,new in [('wrong-guard','RejectCode::new(1)','RejectCode::new(9)'),('missing-leaf-refusal','(Node::Paid | Node::Cancelled, OrderEvent::Cancel)','(Node::Cancelled, OrderEvent::Cancel)'),('wrong-effect','Node::AwaitingPayment => OrderEffect::RequestPayment,','Node::AwaitingPayment => OrderEffect::NotifyCancellation,')]:
  assert text.count(old)==1;source.write_text(text.replace(old,new));r=subprocess.run(['python3','scripts/check-nested-example.py'],cwd=root,env=env,text=True,capture_output=True)
  (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
  assert r.returncode==1 and '--- expected nested trace' in r.stderr and '+++ actual nested trace' in r.stderr and r.stdout.count('source=')==6,(label,r.returncode,r.stderr)
  results.append({'mutation':label,'exit_code':r.returncode,'compiled_example_completed_all_six_attempts':True,'checker_rejected_changed_trace':True})
finally:
 source.write_bytes(original);assert source.read_bytes()==original
r=subprocess.run(['python3','scripts/check-nested-example.py'],cwd=root,env=env,text=True,capture_output=True);(out/'restored.stdout').write_text(r.stdout);(out/'restored.stderr').write_text(r.stderr);r.check_returncode()
(out/'manifest.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original).hexdigest(),'restored_byte_exact':True,'restored_check_exit_code':r.returncode,'negative_controls':results},indent=2)+'\n');print('Three semantic mutations detected; restored example passes',flush=True)
