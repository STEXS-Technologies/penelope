import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/penelope');probe=Path('/home/ac/projects/.penelope-pre-pr-borrow-probe');base=root/'docs/0.5/evidence/qualification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
inputs=read(Path('/tmp/penelope-pre-pr-lineage-final-inputs.json'))
for p,digest in inputs['inputs_sha256'].items():assert sha(root/p)==sha(probe/p)==digest
patch=Path('/tmp/penelope-pre-pr-lineage-final-source.patch');assert patch.read_bytes()==subprocess.check_output(['git','diff','HEAD','--','crates'],cwd=probe)
assert set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=probe,text=True).splitlines())=={'crates/penelope-timeline/src/history.rs','crates/penelope-executor/tests/machine_task.rs'}
files={'source/inputs.json':Path('/tmp/penelope-pre-pr-lineage-final-inputs.json'),'source/source.patch':patch,'recorder.py':Path(__file__)}
results={}
for name in ['borrow-workspace-stable','borrow-workspace-msrv','final-machine-task-stable','final-machine-task-msrv','lineage-final-clippy','lineage-final-docs','lineage-reconciled-package-checks','lineage-final-graphify']:
 p=Path('/tmp/penelope-pre-pr-'+name+'.log');assert p.is_file();files['checks/'+name+'.log']=p
 if name in ['lineage-final-clippy','lineage-final-docs']:assert 'Finished' in p.read_text() and 'error:' not in p.read_text()
 if 'workspace' in name or 'machine-task' in name:
  reports=re.findall(r'(?m)^(?:test result: )?ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text());assert reports and all(y=='0' and z=='0' for x,y,z in reports)
  results[name]={'summaries':len(reports),'reported_passes':sum(int(x) for x,y,z in reports)}
  assert results[name]['reported_passes']==(700 if 'workspace' in name else 12)
for folder in ['lineage-packaged-workspace','lineage-final-package-tests','lineage-coverage','lineage-deterministic-coverage','lineage-final-coverage']:
 raw=Path('/tmp/penelope-pre-pr-'+folder)
 for p in raw.rglob('*'):
  if p.is_file():files[folder+'/'+str(p.relative_to(raw))]=p
 checks=read(raw/'checks.json')
 if folder in ['lineage-coverage','lineage-deterministic-coverage']:
  assert checks[-1]['label']=='ratchet' and checks[-1]['exit_code']==1
 else:assert all(c['exit_code']==0 for c in checks)
 if folder=='lineage-packaged-workspace':
  for version in ['1.100.0','1.89.0']:
   text=(raw/('tests-'+version+'.stdout')).read_text();reports=re.findall(r'(?m)^(?:test result: )?ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
   assert len(reports)==97 and sum(int(x) for x,y,z in reports)==700
coverage=read(Path('/tmp/penelope-pre-pr-lineage-final-coverage/coverage.json'))['data'][0];lines=coverage['totals']['lines'];assert lines['percent']>=94.0759
coverage_sources={}
for f in coverage['files']:
 p=Path(f['filename']);assert p.is_relative_to(probe);relative=str(p.relative_to(probe));coverage_sources[relative]=sha(p);assert coverage_sources[relative]==sha(root/relative)
assert len(coverage_sources)==72
for label,target in [('initial-archives','pre-pr-lineage-package-checks'),('final-archives','pre-pr-lineage-reconciled-package-checks')]:
 archives=sorted((root/'target'/target/'package').glob('*.crate'));assert len(archives)==10
 for p in archives:files[label+'/'+p.name]=p
finalpackages=read(Path('/tmp/penelope-pre-pr-lineage-final-package-tests/archives.json'))
assert len(finalpackages)==10
hashes={name:sha(p) for name,p in files.items()};dest=base/'lineage-borrow-qualification.tar.gz'
with tarfile.open(dest,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(dest) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==hashes
record={'scope':'Local source/artifact reconciliation: base 7ab93d2 plus retained timeline borrowing and executor test-only patch. Main worktree and isolated qualification tree match all 449 tracked crate/workspace inputs. This is not clean-commit CI qualification.','base_commit':inputs['base_commit'],'source_patch_sha256':sha(patch),'source_inputs_sha256':inputs['inputs_sha256'],'workspace_checks':results,'packages':finalpackages,'package_checks':'All ten final archives pass Cargo package verification and literal-include checks. Initial timeline-modified extracted workspace passes 700 checks on each compiler plus both examples. Only executor test source changes afterward; final ten archives are extracted and the complete executor library/integration suites pass on both compilers, including forced conflict and unavailable receipt-read assertions.','coverage':{'lines':lines,'ratchet_percent':94.0759,'sources_sha256':coverage_sources,'prior_failed_attempts':[{'coverage_percent':94.06833081190116,'reason':'Race conflict path did not execute; test synchronized launch but not initial reads.'},{'coverage_percent':94.07463439233484,'reason':'Forced conflict passes, but aggregate remains below ratchet. Full LLVM data retained; no unproven attribution of every difference.'}],'test_improvements':'Force both independent native writers to read empty journal before committing and assert exactly one native conflict. Inject a temporary receipt-read failure after recovered native admission, require pending source acceptance and successful same-receipt retry. No ratchet reduction or production adapter change.'},'performance':'../legacy-balanced/lineage-borrow.json','performance_dispositions':'lineage-performance-followup.json','remaining':['New branch-tip CI has not run; no commit or push made.','Performance findings require explicit evidence-backed disposition under plan §13.2; neither rejected probe grants acceptance.','Full immutable-source chaos remains incomplete and deliberately excluded by the user.','Dated release notes, tag and publication remain deferred.'],'pr_opened':False,'archive':{'file':dest.name,'sha256':sha(dest),'members_sha256':hashes}}
(base/'lineage-borrow-qualification.json').write_text(json.dumps(record,indent=2)+'\n')
print('Qualified local timeline/test patch, both compiler scopes and final archives; coverage',lines['percent'])
