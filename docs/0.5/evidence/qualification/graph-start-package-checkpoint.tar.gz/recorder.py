import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
candidate=Path('/home/ac/projects/.penelope-050-candidate');root=Path('/home/ac/projects/.penelope-050-graph-start-packaging');raw=Path('/tmp/penelope-050-graph-start-packaged-workspace');driver=Path('/tmp/penelope-050-graph-start-package-driver');cov=Path('/tmp/penelope-050-graph-start-coverage');dest=candidate/'docs/0.5/evidence/qualification';source='8dfe89d343f498d58b2e752980b43fa99e20c00d';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==8 and all(c['exit_code']==0 for c in checks)
parent_checks=json.loads((driver/'checks.json').read_text());assert len(parent_checks)==2 and all(c['exit_code']==0 for c in parent_checks)
assert json.loads((driver/'source-before.json').read_text())==json.loads((driver/'source-after.json').read_text())
observations=[]
for v in ['1.100.0','1.89.0']:
 text=(raw/f'tests-{v}.stdout').read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(rows)==97 and sum(int(x[0]) for x in rows)==700 and all(x[1]=='0' and x[2]=='0' for x in rows)
 names=lambda s:collections.Counter(re.findall(r'^test ([^\n]+?) \.\.\.(?: ok)? *$',s,re.M))
 assert names(text)==names((Path('/tmp/penelope-050-door-packaged-workspace')/f'tests-{v}.stdout').read_text())
 observations.append({'compiler':v,'harness_summaries':97,'reported_passes':700,'failed':0,'ignored':0,'named_tests_unchanged_from_c0e9997':True})
expected=json.loads((root/'docs/0.5/evidence/qualification/door-ergonomics.json').read_text())['expected_trace']
decisions=Path('/tmp/penelope-050-graph-start-qualification/consumer-1.100.0.stdout').read_text()
proof=json.loads((root/'docs/0.5/evidence/qualification/graph-start-ownership.json').read_text());assert sha(decisions.encode())==proof['archive']['members_sha256']['raw/consumer-1.100.0.stdout']
for v in ['1.100.0','1.89.0']:
 assert (raw/f'door-{v}.stdout').read_text().splitlines()==expected
 assert (raw/f'decisions-{v}.stdout').read_text()==decisions
archives=json.loads((raw/'archives.json').read_text());assert len(archives)==10 and all(p['vcs']['git']['sha1']==source and not p['vcs']['git'].get('dirty',False) for p in archives)
archive_root=Path('/home/ac/projects/penelope/target/graph-start-package-checks/package')
with tarfile.open(archive_root/'penelope-0.5.0.crate') as t:
 for name in ['examples/door_machine.rs','examples/prepared_decisions.rs']:assert t.extractfile('penelope-0.5.0/'+name).read()==(root/'crates/penelope'/name).read_bytes()
with tarfile.open(archive_root/'penelope-executor-0.5.0.crate') as t:assert t.extractfile('penelope-executor-0.5.0/src/saga_machine.rs').read()==(root/'crates/penelope-executor/src/saga_machine.rs').read_bytes()
lockdiff=json.loads((raw/'external-lock-diff.json').read_text());assert not lockdiff['added'];assert {r[0] for r in lockdiff['removed']}=={'arbitrary','jobserver','libfuzzer-sys'}
ci=json.loads(Path('/tmp/penelope-050-graph-start-ci.json').read_text());assert ci['headSha']==source and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
cilog=Path('/tmp/penelope-050-graph-start-ci.log').read_text()
for job in ['Stable verification','Minimum supported Rust']:
 for line in expected:assert sum(s.startswith(job+'\tRun cargo run --manifest-path ci/machine-consumer/Cargo.toml --bin door --locked\t') and s.endswith('Z '+line) for s in cilog.splitlines())==1,(job,line)
 for line in decisions.splitlines():assert sum(s.startswith(job+'\tRun cargo run --manifest-path ci/machine-consumer/Cargo.toml --bin decisions --locked\t') and s.endswith('Z '+line) for s in cilog.splitlines())==1,(job,line)
cc=json.loads((cov/'checks.json').read_text());assert len(cc)==3 and all(c['exit_code']==0 for c in cc)
assert (cov/'source-commit.txt').read_text().strip()==source
data=json.loads((cov/'coverage.json').read_text())['data'][0];lines=data['totals']['lines'];assert lines['covered']==14925 and lines['count']==15860 and lines['percent']>=94.0759
production={str(Path(f['filename']).relative_to(root)):sha(Path(f['filename']).read_bytes()) for f in data['files']};assert len(production)==72
for name,h in production.items():assert sha((candidate/name).read_bytes())==h and (root/name).read_bytes()==subprocess.check_output(['git','show',source+':'+name],cwd=root)
(cov/'source-sha256.json').write_text(json.dumps(production,indent=2)+'\n')
previous=json.loads((dest/'current-package-checkpoint.json').read_text())['coverage']['source_sha256'];changed=[n for n,h in production.items() if h!=previous[n]];assert changed==['crates/penelope-executor/src/saga_machine.rs']
files={}
for label,folder in [('packages',raw),('package-driver',driver),('coverage',cov)]:
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for p in archive_root.glob('*.crate'):files['archives/'+p.name]=p
for name in ['penelope-050-graph-start-test-packaged-workspace.py','penelope-050-graph-start-package-driver.py','penelope-050-graph-start-run-coverage.py','penelope-050-graph-start-ci.json','penelope-050-graph-start-ci.log']:files['drivers-and-logs/'+name]=Path('/tmp')/name
files['recorder.py']=Path(__file__)
archive=dest/'graph-start-package-checkpoint.tar.gz';members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:assert {m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}==members
record={'source_commit':source,'scope':'All ten clean0.5 archives after removing the unnecessary graph-start definition lifetime; full extracted-workspace tests, explicit packaged door/decision example execution, fresh coverage and all seven source CI jobs. Later candidate commits change only review/verification metadata.','package_checks':checks,'test_observations':observations,'archives':archives,'lock_diff':lockdiff,'coverage':{'checks':cc,'lines':lines,'ratchet':94.0759,'reported_source_files':72,'source_sha256':production,'changed_production_paths_from_c8fda4c':changed,'comparison':'Line totals equal the prior c8fda4c measurement; the sole changed production file has the lifetime/documentation-only refinement qualified separately by graph-start-ownership.json.'},'ci':{'run_id':43840278717,'url':'https://github.com/STEXS-Technologies/penelope/actions/runs/43840278717','jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']],'complete_door_and_decision_traces_observed_once_per_compiler':True},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'limits':['All-target test summaries include zero-test example harnesses. Both packaged example mains are separately executed on each compiler and compared with retained expected output.','Fresh compiled package-test and coverage targets were required; later compiler runs may reuse appropriate dependency artifacts from those targets.','Line coverage is not branch completeness or a correctness proof. Debug correctness runs are not comparative performance results.','Existing live full-source campaigns retain their older immutable source identities; this checkpoint does not complete final exact-source chaos qualification.','Legacy performance findings, remaining normative audit, final dated release notes and release reconciliation remain open. Tagging/publication require separate authorization.']}
(dest/'graph-start-package-checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified',len(files),'archive members; ten clean archives,700 checks each compiler,72 fresh coverage sources and all seven CI jobs')
