import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
candidate=Path('/home/ac/projects/.penelope-050-candidate');root=Path('/home/ac/projects/.penelope-050-door-packaging');raw=Path('/tmp/penelope-050-door-packaged-workspace');driver=Path('/tmp/penelope-050-door-package-driver');dest=candidate/'docs/0.5/evidence/qualification';source='c0e99972a7103ea349f78178446b7e19fb0b6ff9';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==6 and all(c['exit_code']==0 for c in checks)
resume=json.loads((driver/'resume-result.json').read_text());assert resume['status']=='passed'
assert json.loads((driver/'source-before.json').read_text())==json.loads((driver/'source-after.json').read_text())
observations=[]
for v in ['1.100.0','1.89.0']:
 text=(raw/f'tests-{v}.stdout').read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(rows)==97 and sum(int(x[0]) for x in rows)==700 and all(x[1]=='0' and x[2]=='0' for x in rows)
 names=lambda s:collections.Counter(re.findall(r'^test ([^\n]+?) \.\.\.(?: ok)? *$',s,re.M))
 assert names(text)==names((Path('/tmp/penelope-050-final-packaged-workspace')/f'tests-{v}.stdout').read_text())
 observations.append({'compiler':v,'harness_summaries':97,'reported_passes':700,'failed':0,'ignored':0,'named_tests_unchanged_from_c8fda4c':True})
expected=json.loads((root/'docs/0.5/evidence/qualification/door-ergonomics.json').read_text())['expected_trace']
for v in ['1.100.0','1.89.0']:assert (raw/f'door-{v}.stdout').read_text().splitlines()==expected
archives=json.loads((raw/'archives.json').read_text());assert len(archives)==10 and all(p['vcs']['git']['sha1']==source and not p['vcs']['git'].get('dirty',False) for p in archives)
archive_root=Path('/home/ac/projects/penelope/target/door-package-checks/package')
with tarfile.open(archive_root/'penelope-0.5.0.crate') as t:assert t.extractfile('penelope-0.5.0/examples/door_machine.rs').read()==(root/'crates/penelope/examples/door_machine.rs').read_bytes()
lockdiff=json.loads((raw/'external-lock-diff.json').read_text());assert not lockdiff['added'];assert {r[0] for r in lockdiff['removed']}=={'arbitrary','jobserver','libfuzzer-sys'}
ci=json.loads(Path('/tmp/penelope-050-door-ci.json').read_text());assert ci['headSha']==source and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
cilog=Path('/tmp/penelope-050-door-ci.log').read_text()
for job in ['Stable verification','Minimum supported Rust']:
 for line in expected:assert sum(s.startswith(job+'\tRun cargo run --manifest-path ci/machine-consumer/Cargo.toml --bin door --locked\t') and s.endswith(line) for s in cilog.splitlines())==1,(job,line)
previous=json.loads((dest/'current-package-checkpoint.json').read_text());production=previous['coverage']['source_sha256'];assert len(production)==72
for name,h in production.items():assert sha((root/name).read_bytes())==h
files={}
for label,folder in [('packages',raw),('package-driver',driver)]:
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for p in archive_root.glob('*.crate'):files['archives/'+p.name]=p
for name in ['penelope-050-door-test-packaged-workspace.py','penelope-050-door-package-driver.py','penelope-050-door-package-resume.py','penelope-050-door-ci.json','penelope-050-door-ci.log']:files['drivers-and-logs/'+name]=Path('/tmp')/name
files['recorder.py']=Path(__file__)
archive=dest/'door-package-checkpoint.tar.gz';members={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:assert {m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}==members
record={'source_commit':source,'scope':'All ten clean0.5 archives including the exact flat-enum door example; explicit execution of that packaged example on both compilers, unchanged external identities and all seven source CI jobs. This precedes the later graph-start lifetime simplification.','package_checks':checks,'test_observations':observations,'archives':archives,'lock_diff':lockdiff,'production_source_match':{'reference':'current-package-checkpoint.json at c8fda4c','checked_files':72,'all_identical':True,'fresh_coverage_run':False},'ci':{'run_id':43837871662,'url':'https://github.com/STEXS-Technologies/penelope/actions/runs/43837871662','jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']],'complete_door_trace_observed_once_per_compiler':True},'initial_validator_failure':resume['initial_attempt'],'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'limits':['All-target test summaries include zero-test example harnesses. The door main is additionally executed and all eight lines independently checked on each compiler.','The first stable suite passed; its recorder expected the previous96 harnesses instead of97. The original failed validator and resumed remaining commands are retained, without rerunning the passing stable suite.','These are correctness/debug runs, not comparative performance measurements.','Coverage retains the prior c8fda4c scope; no new coverage measurement is claimed.','Current graph-start ownership edits and final source campaigns require separate reconciliation. Performance findings, final audit and release qualification remain open.']}
(dest/'door-package-checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified',len(files),'archive members; ten archives,700 passes per compiler, explicit packaged door traces and seven green CI jobs')
