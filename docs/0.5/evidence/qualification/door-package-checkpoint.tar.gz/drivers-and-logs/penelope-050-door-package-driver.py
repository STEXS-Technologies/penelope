import subprocess, os, json, time, hashlib
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-door-packaging')
out=Path('/tmp/penelope-050-door-package-driver')
out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='c0e99972a7103ea349f78178446b7e19fb0b6ff9'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True)
paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
def hashes():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=hashes()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/door-package-checks'}
assert not Path(env['CARGO_TARGET_DIR']).exists()
checks=[]
for label,args in [('package-verification',['./scripts/publish-crates.sh']),('extracted-workspace',['python3','/tmp/penelope-050-door-test-packaged-workspace.py'])]:
 print(label,flush=True)
 started=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 checks.append({'label':label,'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-started})
 (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 r.check_returncode()
after=hashes()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after
print('Package verification and both extracted-workspace compiler suites passed; tracked sources unchanged',flush=True)
