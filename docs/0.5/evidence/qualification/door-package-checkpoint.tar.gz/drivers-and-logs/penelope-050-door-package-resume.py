from pathlib import Path
import subprocess,os,json,time,re,hashlib
root=Path('/home/ac/projects/.penelope-050-door-packaging');unpacked=Path('/home/ac/projects/penelope/target/door-package-unpacked');out=Path('/tmp/penelope-050-door-packaged-workspace');parent=Path('/tmp/penelope-050-door-package-driver')
def reports(label):
 text=(out/(label+'.stdout')).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 assert len(rows)==97 and sum(int(x[0]) for x in rows)==700 and all(x[1]=='0' and x[2]=='0' for x in rows)
 for name in ['generated_tables_and_hierarchies_match_reference_and_single_level_flat_dispatch','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap','event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot','event_replay_refuses_wrong_predecessor_model_codec_limits_and_duplicate_revision','event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions']:
  assert text.count('test '+name+' ... ok')==1
checks=json.loads((out/'checks.json').read_text());assert all(c['exit_code']==0 for c in checks);reports('tests-1.100.0')
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/door-package-tests'}
commands=[('tests-1.89.0',['cargo','+1.89.0','test','--workspace','--all-targets','--all-features','--locked'])]+[('door-'+v,['cargo','+'+v,'run','-p','penelope','--example','door_machine','--locked']) for v in ['1.100.0','1.89.0']]
expected=json.loads((root/'docs/0.5/evidence/qualification/door-ergonomics.json').read_text())['expected_trace']
assert (unpacked/'penelope-0.5.0/examples/door_machine.rs').read_bytes()==(root/'crates/penelope/examples/door_machine.rs').read_bytes()
for label,args in commands:
 print(label,flush=True);started=time.monotonic();r=subprocess.run(args,cwd=unpacked,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-started});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
 if label.startswith('tests-'):reports(label)
 else:assert r.stdout.splitlines()==expected
assert (out/'Cargo.lock').read_bytes()==(unpacked/'Cargo.lock').read_bytes()
before=json.loads((parent/'source-before.json').read_text());after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in before};assert before==after
(parent/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(parent/'resume-result.json').write_text(json.dumps({'status':'passed','harnesses':97,'passes_per_compiler':700,'source_unchanged':True,'initial_attempt':'Stable tests passed. Driver assertion incorrectly retained96 harnesses from c8; new zero-test door example makes97. Resumed only unexecuted MSRV and example runs, retaining the failed validator log.'},indent=2)+'\n')
print('completed',flush=True)
