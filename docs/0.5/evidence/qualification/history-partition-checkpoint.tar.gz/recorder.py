import collections,hashlib,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');raw=Path('/tmp/penelope-050-history-partition-packaged-workspace-followup');cov=Path('/tmp/penelope-050-history-partition-coverage');dest=root/'docs/0.5/evidence/qualification'
sha=lambda b:hashlib.sha256(b).hexdigest();source='ce93ff8a9cae2496ec56b956dffe16a4bac6dad9'
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==4 and all(c['exit_code']==0 for c in checks)
added=['generated_tables_and_hierarchies_match_reference_and_single_level_flat_dispatch','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap'];observations=[]
for version in ['1.100.0','1.89.0']:
 text=(raw/('tests-'+version+'.stdout')).read_text();reports=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 assert len(reports)==96 and sum(int(r[0]) for r in reports)==696 and all(r[1]=='0' and r[2]=='0' for r in reports)
 assert all(text.count('test '+name+' ... ok')==1 for name in added)
 baseline=Path('/tmp/penelope-050-qpsg-packaged-workspace')/('tests-'+version+'.stdout');names=lambda s:collections.Counter(re.findall(r'^test ([^\n]+?) \.\.\.(?: ok)? *$',s,re.M));new=names(text);old=names(baseline.read_text());assert not old-new;assert new-old==collections.Counter(added),(version,new-old)
 observations.append({'compiler':version,'harness_summaries':96,'reported_passes':696,'failed':0,'ignored':0,'new_tests':added,'no_original_test_name_removed':True,'name_comparison_note':'Matches started test names because subprocess output splits one stable result across lines; all harness summaries separately require zero failures and zero ignored.'})
archives=json.loads((raw/'archives.json').read_text());assert len(archives)==10 and all(p['vcs']['git']['sha1']==source and not p['vcs']['git'].get('dirty',False) for p in archives)
lockdiff=json.loads((raw/'external-lock-diff.json').read_text());assert not lockdiff['added'];assert {r[0] for r in lockdiff['removed']}=={'arbitrary','jobserver','libfuzzer-sys'}
cc=json.loads((cov/'checks.json').read_text());assert len(cc)==3 and all(c['exit_code']==0 for c in cc);data=json.loads((cov/'coverage.json').read_text())['data'][0];lines=data['totals']['lines'];assert lines['covered']==14880 and lines['count']==15814 and lines['percent']>=94.0759
production={}
for f in data['files']:
 p=Path(f['filename']);relative=p.relative_to(root);b=p.read_bytes();assert b==subprocess.check_output(['git','show',source+':'+str(relative)],cwd=root);production[str(relative)]=sha(b)
assert len(production)==72 and (cov/'source-commit.txt').read_text().strip()==source
ci=json.loads(Path('/tmp/penelope-050-history-partition-ci.json').read_text());assert ci['headSha']==source and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
cilog=Path('/tmp/penelope-050-history-partition-ci.log').read_text()
for job in ['Stable verification','Minimum supported Rust']:
 for name in added:assert sum(line.startswith(job+'\t') and 'test '+name+' ... ok' in line for line in cilog.splitlines())==1
initial=Path('/tmp/penelope-050-history-partition-packaged-workspace');discard=[]
for version in ['1.100.0','1.89.0']:
 s=(initial/('tests-'+version+'.stdout')).read_text();assert 'test '+added[1]+' ... ok' not in s;discard.append({'compiler':version,'command_exit':0,'harness_summaries':96,'reported_passes':695,'history_test_observed':False,'disposition':'not_qualification_evidence_reused_compiled_test_target'})
files={}
for label,folder in [('packages',raw),('coverage',cov),('discarded-cache-reuse',initial)]:
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for p in Path('/home/ac/projects/penelope/target/history-partition-package-checks/package').glob('*.crate'):files['archives/'+p.name]=p
for p in Path('/tmp').glob('penelope-050-history-partition*.py'):files['drivers/'+p.name]=p
for p in Path('/tmp').glob('penelope-050-history-partition*.log'):files['logs/'+p.name]=p
files['ci.json']=Path('/tmp/penelope-050-history-partition-ci.json');files['recorder.py']=Path(__file__)
archive=dest/'history-partition-checkpoint.tar.gz';members={n:sha(p.read_bytes()) for n,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as t:
 for n,h in members.items():assert sha(t.extractfile(n).read())==h
m={'source_commit':source,'production_source_commit':'cefa55faffe837fe30625205dd8236e9c242fb36','scope':'Fresh all-ten actual0.5 archive and extracted-workspace qualification after generated-machine and exhaustive-history test additions. Production and dependencies unchanged from cefa55f. Full chaos, retained performance findings and final release reconciliation remain open.','package_checks':checks,'test_observations':observations,'archives':archives,'lock_diff':lockdiff,'coverage':{'checks':cc,'lines':lines,'ratchet':94.0759,'reported_source_files':72,'source_sha256':production},'ci':{'run_id':43814541688,'url':'https://github.com/STEXS-Technologies/penelope/actions/runs/43814541688','conclusion':ci['conclusion'],'jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in ci['jobs']],'both_new_tests_observed_once_in_stable_and_msrv_logs':True},'discarded_attempt':{'reason':'Reused qpsg-candidate-package-tests target ran cached13-test SQLite target despite byte-correct new archive. Numeric success alone was rejected because history test name was absent. Repeated with asserted nonexistent compiled target and explicit new-test observations plus retained-name comparison. No production failure inferred.','observations':discard},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'member_count':len(files),'members_sha256':members},'limits':['Debug benchmark smokes are not performance measurements.','Line coverage and696 reported passes are not a universal correctness proof.','The full-target production-source chaos campaigns and augmented-machine supplementary fuzz keep their explicit source/harness scopes.','No performance waiver, publication or tag authorization is recorded.']}
(dest/'history-partition-checkpoint.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified and archived',len(files),'members; all ten clean archives,96 summaries/696 passes on both compilers,72 coverage-source hashes and all seven CI jobs.')
