import csv,json,re
from pathlib import Path
from statistics import median
p=Path('/tmp/penelope-050-capability-performance');meta=json.loads((p/'metadata.json').read_text());assert meta['status']=='completed' and len(meta['validated_runs'])==28
specs={'machine_operations':['kind','state_words','states','events','intents','reject','quota'],'machine_hierarchy':['kind','depth','handler','mode','state_bytes','owner_bytes'],'machine_state_cost':['kind','state_words'],'machine_timeline':['path','state_bytes','horizon','operation']};rows=[]
for name,dimensions in specs.items():
 samples=[list(csv.DictReader((p/f'run-1.100.0-{i}-{name}.stdout').read_text().splitlines())) for i in range(1,4)]
 for index,base in enumerate(samples[0]):
  dims={k:base[k] for k in dimensions};assert all({k:s[index][k] for k in dimensions}==dims for s in samples)
  fields=['p50_ns','p95_ns','p99_ns'] if name=='machine_timeline' else ['batch_mean_p50_ns','batch_mean_p95_ns','batch_mean_p99_ns']
  values={k:[int(s[index][k]) for s in samples] for k in fields};rows.append({'benchmark':name,'dimensions':dims,'reported_quantiles_per_run':values,'median_reported_quantiles':{k:median(v) for k,v in values.items()},'raw_sample_count_per_run':101,'operations_per_sample':1 if name=='machine_timeline' else 32,'allocation_scope':'Measured kernel/hierarchy/owned-state probe checks alloc/realloc/dealloc/requested bytes; timeline probe checks alloc/realloc/requested bytes only. Allocation-free consumer fixtures; fixture setup excluded.'})
for name,dimensions,metrics in [('machine_store',['writers'],['commit','exact_retry','snapshot_read','slowest_stale_per_round','release_to_last_finish']),('machine_backpressure',['queue_capacity','requests_per_round'],['accepted_first_poll','refusal_first_poll','accepted_gated_completion'])]:
 samples=[json.loads((p/f'run-1.100.0-{i}-{name}.stdout').read_text())['profiles'] for i in range(1,4)]
 for index,base in enumerate(samples[0]):
  dims={k:base[k] for k in dimensions};assert all({k:s[index][k] for k in dimensions}==dims for s in samples)
  for metric in metrics:
   if base[metric] is None:assert all(s[index][metric] is None for s in samples);continue
   values={k:[s[index][metric][k] for s in samples] for k in ['p50_ns','p95_ns','p99_ns']};counts=[s[index][metric]['samples'] for s in samples];rows.append({'benchmark':name,'dimensions':dims|{'operation':metric},'reported_quantiles_per_run':values,'median_reported_quantiles':{k:median(v) for k,v in values.items()},'raw_sample_count_per_run':counts,'measured_rounds_per_run':101,'allocation_scope':'Not instrumented.'})
phase_samples={}
for i in range(1,4):
 lines=[line.split(',') for line in (p/f'run-1.100.0-{i}-native_pipeline.stdout').read_text().splitlines() if line.startswith('native_pipeline_')]
 for r in lines:
  if r[0]=='native_pipeline_summary':phase_samples.setdefault(r[1],[]).append({k:int(v) for k,v in zip(['p50_ns','p95_ns','p99_ns'],r[3:6])})
 total=sorted(int(r[3]) for r in lines if r[0]=='native_pipeline_total' and r[-1]=='false');assert len(total)==101
 phase_samples.setdefault('outer_iteration_total',[]).append({'p50_ns':total[50],'p95_ns':total[95],'p99_ns':total[99]})
for phase,samples in phase_samples.items():
 assert len(samples)==3;values={k:[s[k] for s in samples] for k in ['p50_ns','p95_ns','p99_ns']};rows.append({'benchmark':'native_pipeline','dimensions':{'phase':phase},'reported_quantiles_per_run':values,'median_reported_quantiles':{k:median(v) for k,v in values.items()},'raw_sample_count_per_run':101,'allocation_scope':'Not instrumented; one live worker,8-byte input/output, existing64MiB address-space limit. Sequential recovery scenario, not saturation or isolated worker CPU.'})
footprint={}
for label,record in meta['binaries'].items():
 text=(p/('sections-'+label+'.stdout')).read_text();match=re.search(r'\]\s+\.text\s+\S+\s+[0-9a-fA-F]+\s+[0-9a-fA-F]+\s+([0-9a-fA-F]+)',text);assert match;footprint[label]={**record,'elf_text_bytes':int(match[1],16)}
result={'scope':'Current candidate observation summary. Medians of three per-run reported quantiles, not pooled percentiles or equivalence. Batch-mean and individual-call quantiles remain distinct. MSRV run validates correctness only and is excluded from latency aggregation.','source_commit':meta['source_commit'],'metrics':rows,'binary_footprint':footprint,'open':'Does not resolve legacy encoding/timeline findings, establish throughput/saturation bounds or finish full fuzz/release qualification.'};(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('Summarized',len(rows),'metric profiles and',len(footprint),'retained executable footprints')
for r in rows:
 if (r['benchmark']=='machine_store' and r['dimensions']['operation'] in ['commit','release_to_last_finish']) or (r['benchmark']=='native_pipeline' and r['dimensions']['phase']=='outer_iteration_total'):print(r['benchmark'],r['dimensions'],r['median_reported_quantiles'])
