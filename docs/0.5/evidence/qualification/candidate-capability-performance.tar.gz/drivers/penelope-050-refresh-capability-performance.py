import csv,hashlib,json,os,platform,shutil,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-performance');out=Path('/tmp/penelope-050-capability-performance');out.mkdir(exist_ok=False)
target=Path('/home/ac/projects/penelope/target/candidate-capability-performance');target.mkdir(exist_ok=False);data=target/'data';data.mkdir()
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','PENELOPE_BENCH_DIR':str(data),'TMPDIR':str(data)}
specs=[('machine_operations','penelope-core',None,[]),('machine_hierarchy','penelope-core',None,[]),('machine_state_cost','penelope-core',None,[]),('machine_timeline','penelope-timeline',None,[]),('machine_store','penelope-sqlite',None,[]),('machine_backpressure','penelope-sqlite',None,[]),('native_pipeline',None,'ci/machine-consumer/Cargo.toml',['--features','protected'])]
checks=[];binaries={};tracked=subprocess.check_output(['git','ls-files','--','crates','ci','fuzz','scripts','.github','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=root,text=True).splitlines()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in tracked}
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'start_utc':datetime.now(timezone.utc).isoformat(),'status':'running','source_sha256_before':hashes(),'environment_overrides':{k:env[k] for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_JOBS','PENELOPE_BENCH_DIR','TMPDIR']},'toolchains':['1.100.0','1.89.0'],'stable_runs':3,'msrv_runs':1,'build_affinity':'4-7','measurement_affinity':'4 except machine_store4-7','host':platform.platform(),'filesystem':json.loads(subprocess.check_output(['findmnt','-J','-T',str(data)],text=True)),'cache_policy':'Warm/uncontrolled OS and registry caches; no global cache eviction. Shared host; existing chaos sessions on8-15 and16-23 remain active. No isolated-host or arbitrary application claim.','binaries':{}}
def save():
 (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
def run(label,args,environment):
 start=time.monotonic();r=subprocess.run(args,cwd=root,env=environment,capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(label+'.'+suffix)).write_text(text)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});save();r.check_returncode();return r.stdout
try:
 save()
 for version in meta['toolchains']:
  for name,package,manifest,features in specs:
   print('build',version,name,flush=True);build_env={**env,'CARGO_TARGET_DIR':str(target/version)};args=['taskset','-c','4-7','cargo','+'+version,'bench','--locked','--no-run','--message-format=json','--bench',name]
   args+=['-p',package] if package else ['--manifest-path',manifest];args+=features
   stdout=run('build-'+version+'-'+name,args,build_env);records=[json.loads(l) for l in stdout.splitlines()];artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable')];assert len(artifacts)==1
   executable=out/(version+'-'+name+'.bin');shutil.copy2(artifacts[0]['executable'],executable);binaries[(version,name)]=executable
   section=run('sections-'+version+'-'+name,['readelf','--wide','--sections',str(executable)],env);meta['binaries'][version+'-'+name]={'sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),'bytes':executable.stat().st_size,'executable':executable.name};save()
 # All builds precede timing; each process receives the original release fixture.
 for version,rounds in [('1.100.0',3),('1.89.0',1)]:
  for round_index in range(rounds):
   rotated=specs[round_index:]+specs[:round_index]
   for name,_,_,_ in rotated:
    label='run-'+version+'-'+str(round_index+1)+'-'+name;print(label,flush=True);affinity='4-7' if name=='machine_store' else '4';resources=out/(label+'.resources.json')
    stdout=run(label,['/usr/bin/time','-f','{"peak_rss_kib":%M,"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S}','-o',str(resources),'taskset','-c',affinity,str(binaries[(version,name)])],env)
    if name in ['machine_operations','machine_hierarchy','machine_state_cost','machine_timeline']:
     rows=list(csv.DictReader(stdout.splitlines()));assert len(rows)=={'machine_operations':396,'machine_hierarchy':60,'machine_state_cost':12,'machine_timeline':64}[name]
     for row in rows:
      assert int(row['samples'])==101
      if name=='machine_timeline':assert len(row['raw_ns'].split(';'))==101 and all(int(row[k])==0 for k in ['allocations','reallocations','requested_bytes'])
      else:assert int(row['batch'])==32 and row['allocations_per_op']=='0' and len(row['raw_batch_elapsed_ns'].split(';'))==101
    elif name in ['machine_store','machine_backpressure']:
     result=json.loads(stdout);assert result['measurement_mode']=='release-101' and result['journal_mode']=='WAL' and result['synchronous']=='FULL';assert len(result['profiles'])==4
     assert all(p['measured_rounds']==101 and p['warmup_rounds']==8 for p in result['profiles'])
     if name=='machine_store':assert [p['writers'] for p in result['profiles']]==[1,2,8,32]
     else:assert [(p['queue_capacity'],p['requests_per_round']) for p in result['profiles']]==[(1,32),(1,128),(8,32),(8,128)]
    else:
     rows=[line.split(',') for line in stdout.splitlines() if line.startswith('native_pipeline_')];summary=[r for r in rows if r[0]=='native_pipeline_summary'];totals=[r for r in rows if r[0]=='native_pipeline_total'];phases=[r for r in rows if r[0]=='native_pipeline_sample'];assert len(summary)==12 and all(int(r[2])==101 for r in summary);assert len(totals)==109 and len(phases)==109*12;assert sum(r[-1]=='false' for r in totals)==101
    meta.setdefault('validated_runs',[]).append(label);save()
 for (version,name),p in binaries.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['binaries'][version+'-'+name]['sha256']
 meta['source_sha256_after']=hashes();assert meta['source_sha256_after']==meta['source_sha256_before'];subprocess.run(['git','diff','--exit-code','HEAD'],cwd=root,check=True,capture_output=True)
 meta['status']='completed';meta['end_utc']=datetime.now(timezone.utc).isoformat();save();print('completed',flush=True)
except BaseException as error:
 meta['status']='failed';meta['error']=repr(error);meta['end_utc']=datetime.now(timezone.utc).isoformat();save();raise
