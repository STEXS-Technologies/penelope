import subprocess,os,json,hashlib,time
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-native-slot-reuse-qualification');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')}
checks=[]
commands=[('runtime-'+v,['cargo','+'+v,'test','--locked','-p','penelope-process-runtime','--all-features','--test','runtime']) for v in ['1.100.0','1.89.0']]
commands += [('clippy',['cargo','+1.100.0','clippy','--locked','-p','penelope-process-runtime','--all-features','--test','runtime','--','-D','warnings']),('fmt',['cargo','+1.100.0','fmt','--all','--','--check']),('diff',['git','diff','--check'])]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
source=root/'crates/penelope-process-runtime/tests/support/launch_contracts.rs'
(out/'launch_contracts.rs').write_bytes(source.read_bytes())
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/penelope-process-runtime/tests/support/launch_contracts.rs'],cwd=root))
print('completed',flush=True)
