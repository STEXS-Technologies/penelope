import json,tarfile,hashlib,subprocess
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=root/'docs/0.5/evidence/qualification';raw=Path('/tmp/penelope-native-slot-reuse-qualification-final')
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==5 and all(r['exit_code']==0 for r in checks)
source='crates/penelope-process-runtime/tests/support/launch_contracts.rs'
assert (raw/'launch_contracts.rs').read_bytes()==(root/source).read_bytes()
for toolchain in ['1.100.0','1.89.0']:
 assert 'test result: ok. 67 passed; 0 failed;' in (raw/('runtime-'+toolchain+'.stdout')).read_text()
files={}
for directory in ['penelope-native-slot-reuse-qualification','penelope-native-slot-reuse-qualification-rename-failure','penelope-native-slot-reuse-qualification-final']:
 for p in (Path('/tmp')/directory).rglob('*'):
  if p.is_file():files[str(p.relative_to('/tmp'))]=p
for name in ['penelope-qualify-native-slot-reuse.py','penelope-qualify-native-slot-reuse-initial.py','penelope-native-slot-reuse-first.log','penelope-native-slot-reuse-qualification.log','penelope-native-slot-reuse-qualification-rename-failure.log','penelope-native-slot-reuse-qualification-final.log','penelope-native-slot-reuse-graph.log','penelope-native-slot-reuse-graph-final.log','penelope-record-native-slot-reuse.py']:
 files[name]=Path('/tmp')/name
archive=out/'native-slot-reuse.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(hashes)
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source':source,'source_sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'scope':'Expanded existing real Linux runtime admission regression at max_live=1; correctness, not throughput, CPU isolation or general saturation performance qualification','checks':checks,'oracle':'First sleeping worker preserves exact reserved retries and registry identity while a second durably authorized task is refused twice at capacity. After first generation is fenced, the same second TaskStart is admitted, exact retry succeeds, poll is Pending, and fencing prevents its later restart. Failed supervisor remains subject to reconstruction.','development_failures':'Initial strict Clippy rejected a shadowed runtime binding. A partial rename then failed compilation; final source passes both full runtime suites, Clippy, fmt and diff. Failed logs and source copies retained.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':hashes,'open':'Performance policy answer, remaining performance matrix, full chaos and exact final release candidate qualification remain open.'}
(out/'native-slot-reuse.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified archive members:',len(hashes))
