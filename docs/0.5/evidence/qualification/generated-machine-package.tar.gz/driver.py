import hashlib,json,os,subprocess,tarfile,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-generated-model-package-followup');assert not out.exists();out.mkdir()
base=Path('/home/ac/projects/penelope/target/generated-model-package');env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(base)}
checks=[]
def run(label,args,cwd):
 start=time.time()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(['taskset','-c','4-7',*args],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.time()-start});assert r.returncode==0,label
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
run('package',['cargo','+1.100.0','package','-p','penelope-core','--locked'],root)
archive=base/'package/penelope-core-0.5.0.crate';unpacked=out/'unpacked';unpacked.mkdir()
with tarfile.open(archive) as t:
 for member in t.getmembers():assert '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
 t.extractall(unpacked,filter='data')
crate=unpacked/'penelope-core-0.5.0';vcs=json.loads((crate/'.cargo_vcs_info.json').read_text());assert vcs['git']['sha1']==source and not vcs['git'].get('dirty',False)
for p in ['tests/generated_machines.rs','tests/support/generated_machine.rs']:
 assert (crate/p).read_bytes()==(root/'crates/penelope-core'/p).read_bytes()
lock=(crate/'Cargo.lock').read_bytes()
for version in ['1.100.0','1.89.0']:
 env['CARGO_TARGET_DIR']=str(base/('tests-'+version))
 run('tests-'+version,['cargo','+'+version,'test','--test','generated_machines','--all-features','--locked'],crate)
 assert (crate/'Cargo.lock').read_bytes()==lock
 assert '1 passed; 0 failed; 0 ignored' in (out/('tests-'+version+'.log')).read_text()
m={'source_commit':source,'scope':'Actual clean0.5 core archive includes byte-identical generated model test and shared fixture. Extracted-crate targeted test passes on stable and MSRV using the same unchanged normalized Cargo lock. This supplements, not replaces, all-ten archive/full-workspace qualification.','checks':checks,'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'package_vcs':vcs,'extracted_lock_sha256':hashlib.sha256(lock).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m),flush=True)
