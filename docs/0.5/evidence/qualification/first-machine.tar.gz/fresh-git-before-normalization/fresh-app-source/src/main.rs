use penelope::machine::*;

struct Counter;

const DEFINITION: MachineDefinition = MachineDefinition {
    fingerprint: MachineDefinitionId::from_bytes([1; 32]),
    state_schema: 1,
    event_schema: 1,
};

impl Machine for Counter {
    type State = u64;
    type Event = u64;
    type Effect = ();
    type Error = MachineError;

    fn definition(&self) -> MachineDefinition { DEFINITION }

    fn validate(&self, _: &u64) -> Result<(), MachineError> { Ok(()) }

    fn transition<S: IntentSink<()>>(
        &self,
        current: &u64,
        amount: &u64,
        _: &TransitionContext,
        _: &mut S,
    ) -> Result<Transition<u64>, MachineError> {
        Ok(match current.checked_add(*amount) {
            Some(next) => Transition::Accepted {
                next,
                transition: TransitionId::new(1),
            },
            None => Transition::Rejected { reason: RejectCode::new(1) },
        })
    }
}

fn main() -> Result<(), MachineFailure<MachineError>> {
    let scope = MachineScope {
        tenant: MachineTenantId::from_bytes([2; 32]),
        instance: MachineId::from_bytes([3; 32]),
        definition: DEFINITION,
    };
    let mut counter = MemoryMachine::<_, 0>::new(
        Counter,
        scope,
        0,
        IntentLimits { max_intents: 0, max_payload_bytes: 0 },
    )?;
    let event = 3_u64;
    let context = TransitionContext {
        expected: counter.read().0,
        event: MachineEventId::from_bytes([4; 32]),
        event_digest: Digest::of(&event.to_le_bytes()).0,
        logical_time: MachineLogicalTime::new(1),
    };
    let outcome = counter.handle(&event, context)?;
    assert!(matches!(outcome, HandleOutcome::Accepted(_)));
    println!("count = {}", counter.read().1);
    Ok(())
}
