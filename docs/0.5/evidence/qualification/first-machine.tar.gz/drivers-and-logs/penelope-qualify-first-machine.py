import os,subprocess,json,hashlib,shutil
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-first-machine-qualification');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')}
checks=[]
def run(name,args,cwd=root,expected=0,contains=None):
 print(name,flush=True)
 r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 checks.append({'name':name,'argv':args,'cwd':str(cwd),'exit':r.returncode,'expected':expected});(out/'checks.json').write_text(json.dumps(checks,indent=2))
 assert r.returncode==expected,(name,r.returncode,r.stderr[-2000:])
 if contains:assert contains in r.stdout,(name,r.stdout)
 return r
for compiler in ['1.100.0','1.89.0']:
 run('consumer-'+compiler,['cargo','+'+compiler,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','first-machine','--locked'],contains='count = 3\n')
run('clippy',['cargo','+1.100.0','clippy','--manifest-path','ci/machine-consumer/Cargo.toml','--all-targets','--all-features','--locked','--','-D','warnings'])
run('workspace-fmt',['cargo','+1.100.0','fmt','--all','--','--check'])
run('consumer-fmt',['cargo','+1.100.0','fmt','--manifest-path','ci/machine-consumer/Cargo.toml','--','--check'])
run('pins',['./scripts/check-action-pins.sh'])
run('diff',['git','diff','--check'])
fixture=out/'external';app=fixture/'ci/machine-consumer';app.mkdir(parents=True);(fixture/'docs').mkdir()
guide=(root/'docs/getting-started.md').read_bytes();(fixture/'docs/getting-started.md').write_bytes(guide)
for name in ['build.rs','first_machine.rs']:shutil.copyfile(root/'ci/machine-consumer'/name,app/name)
(app/'Cargo.toml').write_text('[package]\nname="penelope-first-machine-check"\nversion="0.0.0"\nedition="2024"\nrust-version="1.89"\npublish=false\n\n[workspace]\n\n[dependencies]\npenelope={path="'+str(root/'crates/penelope')+'"}\n\n[[bin]]\nname="first-machine"\npath="first_machine.rs"\n')
run('external-lock',['cargo','+1.89.0','generate-lockfile','--offline'],cwd=app)
for compiler in ['1.100.0','1.89.0']:
 run('external-'+compiler,['cargo','+'+compiler,'run','--bin','first-machine','--locked','--offline'],cwd=app,contains='count = 3\n')
wrong=guide.replace(b'fn main()',b'fn broken(',1);assert wrong!=guide
(fixture/'docs/getting-started.md').write_bytes(wrong)
r=run('invalid-guide-refused',['cargo','+1.100.0','check','--bin','first-machine','--locked','--offline'],cwd=app,expected=101)
assert 'first_machine.rs' in r.stderr and 'mismatched closing delimiter' in r.stderr,r.stderr
(fixture/'docs/getting-started.md').write_bytes(guide)
run('restored-guide',['cargo','+1.100.0','run','--bin','first-machine','--locked','--offline'],cwd=app,contains='count = 3\n')
files=['.github/workflows/ci.yml','README.md','docs/getting-started.md','crates/penelope/Cargo.toml','ci/machine-consumer/Cargo.toml','ci/machine-consumer/Cargo.lock','ci/machine-consumer/build.rs','ci/machine-consumer/first_machine.rs']
for f in files:
 p=out/'source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,p)
(out/'metadata.json').write_text(json.dumps({'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},'environment':{k:env.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'guide_rust_lines':len(guide.decode().split('```rust\n',1)[1].split('\n```',1)[0].splitlines()),'scope':'Default-feature canonical guide from one source; existing consumer and independent workspace with only a path dependency on the public facade. No new local identity policy or evaluator.'},indent=2))
print('completed',flush=True)
