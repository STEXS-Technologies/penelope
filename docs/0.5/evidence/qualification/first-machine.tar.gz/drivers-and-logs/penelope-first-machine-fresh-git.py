import os,subprocess,json,hashlib,shutil
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-first-machine-fresh-git');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')};checks=[]
def run(name,args,cwd=out,output=None):
 print(name,flush=True);r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 checks.append({'name':name,'argv':args,'cwd':str(cwd),'exit':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2));r.check_returncode()
 if output is not None:assert r.stdout==output,(name,r.stdout)
 return r
expected=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();clone=out/'penelope'
run('clone',['git','clone','--depth','1','--branch','refactor/unified-state-execution','https://github.com/STEXS-Technologies/penelope.git',str(clone)])
revision=run('clone-revision',['git','rev-parse','HEAD'],cwd=clone).stdout.strip();assert revision==expected,(revision,expected)
for compiler in ['1.100.0','1.89.0']:
 run('readme-example-'+compiler,['cargo','+'+compiler,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','first-machine','--locked'],cwd=clone,output='count = 3\n')
assert run('clean-clone',['git','status','--porcelain'],cwd=clone).stdout==''
app=out/'my-app'
run('cargo-new',['cargo','+1.89.0','new',str(app),'--vcs','none'])
run('cargo-add',['cargo','+1.89.0','add','penelope','--git','https://github.com/STEXS-Technologies/penelope','--branch','refactor/unified-state-execution'],cwd=app)
guide=(clone/'docs/getting-started.md').read_bytes();assert guide==(root/'docs/getting-started.md').read_bytes()
code=guide.decode().split('```rust\n',1)[1].split('\n```',1)[0];(app/'src/main.rs').write_text(code+'\n')
for compiler in ['1.100.0','1.89.0']:
 run('fresh-app-'+compiler,['cargo','+'+compiler,'run','--locked'],cwd=app,output='count = 3\n')
metadata=json.loads(run('cargo-metadata',['cargo','+1.89.0','metadata','--locked','--format-version','1'],cwd=app).stdout)
p=[p for p in metadata['packages'] if p['name']=='penelope'];assert len(p)==1 and p[0]['source'].endswith('#'+expected),p
(out/'metadata.json').write_text(json.dumps({'source_revision':revision,'resolved_facade_source':p[0]['source'],'guide_sha256':hashlib.sha256(guide).hexdigest(),'fresh_lock_sha256':hashlib.sha256((app/'Cargo.lock').read_bytes()).hexdigest(),'environment':{k:env.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'scope':'Actual pushed branch: clean shallow README clone command and newly generated app using README Git branch dependency, no workspace patches, copied exact canonical Rust fence, same generated lock tested with both compilers.'},indent=2))
for file in ['Cargo.toml','Cargo.lock','src/main.rs']:
 dest=out/'fresh-app-source'/file;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(app/file,dest)
print('completed',flush=True)
