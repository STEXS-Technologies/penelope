import os,subprocess,json,shutil,hashlib
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-first-machine-line-endings');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')};checks=[]
def run(name,args,cwd=root,expected=0):
 print(name,flush=True);r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);checks.append({'name':name,'argv':args,'cwd':str(cwd),'exit':r.returncode,'expected':expected});(out/'checks.json').write_text(json.dumps(checks,indent=2));assert r.returncode==expected,(name,r.stderr)
 if expected==0 and args[2:3]==['run']:assert r.stdout=='count = 3\n'
 return r
for compiler in ['1.100.0','1.89.0']:
 run('consumer-'+compiler,['cargo','+'+compiler,'run','--manifest-path','ci/machine-consumer/Cargo.toml','--bin','first-machine','--locked'])
run('clippy',['cargo','+1.100.0','clippy','--manifest-path','ci/machine-consumer/Cargo.toml','--all-targets','--all-features','--locked','--','-D','warnings'])
fixture=out/'external';app=fixture/'ci/machine-consumer';app.mkdir(parents=True);(fixture/'docs').mkdir()
original=Path('/tmp/penelope-first-machine-final-qualification/external/ci/machine-consumer')
for f in ['Cargo.toml','Cargo.lock']:shutil.copyfile(original/f,app/f)
for f in ['build.rs','first_machine.rs']:shutil.copyfile(root/'ci/machine-consumer'/f,app/f)
guide=(root/'docs/getting-started.md').read_bytes();assert b'\r' not in guide;guide_path=fixture/'docs/getting-started.md';guide_path.write_bytes(guide.replace(b'\n',b'\r\n'))
for compiler in ['1.100.0','1.89.0']:
 run('crlf-'+compiler,['cargo','+'+compiler,'run','--bin','first-machine','--locked','--offline'],cwd=app)
guide_path.write_bytes(guide.replace(b'fn main()',b'fn broken(',1))
r=run('invalid-guide-refused',['cargo','+1.100.0','check','--bin','first-machine','--locked','--offline'],cwd=app,expected=101);assert 'first_machine.rs' in r.stderr and 'unclosed delimiter' in r.stderr
guide_path.write_bytes(guide)
run('restored-lf',['cargo','+1.100.0','run','--bin','first-machine','--locked','--offline'],cwd=app)
for f in ['ci/machine-consumer/build.rs','docs/getting-started.md']:
 p=out/'source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,p)
(out/'metadata.json').write_text(json.dumps({'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['ci/machine-consumer/build.rs','docs/getting-started.md']},'scope':'Normalize CRLF from checkouts, exercise copied actual guide with both compilers, verify invalid edited guide still fails, then restore LF. No native Windows execution claim.'},indent=2))
print('completed',flush=True)
