import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-graph-example');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/graph-example'}
checks=[]
for version in ['1.100.0','1.89.0']:
 for kind in ['run','clippy']:
  command=['taskset','-c','4-7','cargo','+'+version,kind,'--manifest-path','ci/machine-consumer/Cargo.toml','--bin','decisions','--locked']
  if kind=='clippy':command+=['--','-D','warnings']
  start=time.monotonic();r=subprocess.run(command,cwd=root,env=env,text=True,capture_output=True);label=kind+'-'+version
  (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
  checks.append({'label':label,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
  if kind=='run':
   assert 'graph saga: predecessor=false, planned intents=1' in r.stdout
   assert 'graph saga candidate=Running; atomic admission required' in r.stdout
   assert 'machine remains=0' in r.stdout
  print(label,'PASS',flush=True)
