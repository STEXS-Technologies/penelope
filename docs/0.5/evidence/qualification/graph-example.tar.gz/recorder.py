import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');raw=Path('/tmp/penelope-050-graph-example');dest=root/'docs/0.5/evidence/qualification'
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==4 and all(c['exit_code']==0 for c in checks)
source='crates/penelope/examples/prepared_decisions.rs';sha=lambda b:hashlib.sha256(b).hexdigest()
for version in ['1.100.0','1.89.0']:
 s=(raw/('run-'+version+'.stdout')).read_text()
 for expected in ['machine commit: predecessor=true, planned intents=1','saga: predecessor=false, planned intents=1','graph saga: predecessor=false, planned intents=1','task: predecessor=true, planned intents=0']:assert expected in s
 assert 'graph saga candidate=Running; atomic admission required' in s and 'machine remains=0' in s
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert base.startswith('6132a19')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines();assert changed==[source],changed
coverage=json.loads((dest/'history-partition-checkpoint.json').read_text());production=coverage['coverage']['source_sha256']
for name,h in production.items():assert sha((root/name).read_bytes())==h
fmt=subprocess.run(['cargo','fmt','--all','--check'],cwd=root,capture_output=True,text=True);assert fmt.returncode==0
(raw/'fmt.stdout').write_text(fmt.stdout);(raw/'fmt.stderr').write_text(fmt.stderr)
files={p.name:p for p in raw.iterdir() if p.is_file()};files['driver.py']=Path('/tmp/penelope-050-graph-example.py');files['recorder.py']=Path(__file__);files['prepared_decisions.rs']=root/source
archive=dest/'graph-example.tar.gz';members={n:sha(p.read_bytes()) for n,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as t:
 for n,h in members.items():assert sha(t.extractfile(n).read())==h
m={'scope':'Plan F3 runnable graph-preparation example. Extends the existing prepared-decisions consumer through the same facade and shared inspection helper; no new engine, library API, dependency or commit/dispatch authority. This is targeted source-consumer qualification, not fresh package or full release qualification.','base_commit':base,'source':{'path':source,'sha256':sha((root/source).read_bytes())},'checks':checks,'format_check_exit_code':fmt.returncode,'production_sources_unchanged_from_checkpoint':{'checkpoint':'history-partition-checkpoint.json','verified_files':len(production)},'observed':'Both compilers print all four prepared views, graph Running with one planned intent and explicit atomic-admission requirement, and aborted machine state still0.','limits':['Only graph start/inspection is demonstrated here; graph result routing, foreign-action refusal, unknown outcomes and replay remain independently tested by prepared_lifecycles and frozen saga parity.','The example does not admit or dispatch graph work; no durable receipt is fabricated.','Full chaos, retained performance findings and final source/artifact reconciliation remain open.'],'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members}}
(dest/'graph-example.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified four consumer checks, formatting,72 unchanged production sources and',len(members),'archive members.')
