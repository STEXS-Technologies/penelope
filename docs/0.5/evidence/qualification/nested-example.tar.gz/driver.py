import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');out=Path('/tmp/penelope-050-nested-example-followup');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/graph-example'}
checks=[]
for version in ['1.100.0','1.89.0']:
 for kind in ['run','clippy']:
  command=['taskset','-c','4-7','cargo','+'+version,kind,'--manifest-path','ci/machine-consumer/Cargo.toml','--bin','nested','--locked']
  if kind=='clippy':command+=['--','-D','warnings']
  start=time.monotonic();r=subprocess.run(command,cwd=root,env=env,text=True,capture_output=True);label=kind+'-'+version
  (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
  checks.append({'label':label,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
  if kind=='run':
   blocks=[b.splitlines() for b in r.stdout.split('source=')[1:]]
   expected=[['Exit(Draft)','RequestPayment','Enter(AwaitingPayment)'],[],['Exit(AwaitingPayment)','Exit(Open)','Enter(Paid)'],['Exit(Paid)','Enter(Paid)'],[],['Exit(Draft)','Exit(Open)','NotifyCancellation','Enter(Cancelled)']]
   assert len(blocks)==len(expected),r.stdout
   for block,trace in zip(blocks,expected):
    actual=[line.removeprefix('intent=').removesuffix(' (not dispatched)') for line in block if line.startswith('intent=')]
    assert actual==trace,(block,trace)
   assert 'PaymentConfirmed(0)' in blocks[1][0] and 'Rejected' in blocks[1][1]
   assert 'state=Open(AwaitingPayment)' in blocks[1]
   assert 'RefreshReceipt' in blocks[3][0] and 'state=Paid { receipt: 7 }' in blocks[3]
   assert 'Paid { receipt: 7 } event=Cancel'==blocks[4][0] and 'Rejected' in blocks[4][1]
   assert 'state=Paid { receipt: 7 }' in blocks[4]
   assert 'state=Cancelled' in blocks[5]
  print(label,'PASS',flush=True)
