import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');raw=Path('/tmp/penelope-050-nested-example-followup');dest=root/'docs/0.5/evidence/qualification';source='crates/penelope/examples/nested_order.rs';sha=lambda b:hashlib.sha256(b).hexdigest()
checks=json.loads((raw/'checks.json').read_text());assert len(checks)==4 and all(c['exit_code']==0 for c in checks)
expected=[['Exit(Draft)','RequestPayment','Enter(AwaitingPayment)'],[],['Exit(AwaitingPayment)','Exit(Open)','Enter(Paid)'],['Exit(Paid)','Enter(Paid)'],[],['Exit(Draft)','Exit(Open)','NotifyCancellation','Enter(Cancelled)']]
for version in ['1.100.0','1.89.0']:
 blocks=[b.splitlines() for b in (raw/('run-'+version+'.stdout')).read_text().split('source=')[1:]];assert len(blocks)==6
 for block,trace in zip(blocks,expected):assert [line.removeprefix('intent=').removesuffix(' (not dispatched)') for line in block if line.startswith('intent=')]==trace
 assert blocks[0][1]=='Accepted revision=1 transition=1'
 assert blocks[1][1]=='Rejected guard=1' and 'state=Open(AwaitingPayment)' in blocks[1]
 assert blocks[2][1]=='Accepted revision=2 transition=2'
 assert blocks[3][1]=='Accepted revision=3 transition=4' and 'state=Paid { receipt: 7 }' in blocks[3]
 assert blocks[4][1]=='Rejected guard=2' and 'state=Paid { receipt: 7 }' in blocks[4]
 assert blocks[5][1]=='Accepted revision=1 transition=3' and 'state=Cancelled' in blocks[5]
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert base.startswith('4d537ea')
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==[source]
production=json.loads((dest/'history-partition-checkpoint.json').read_text())['coverage']['source_sha256']
for name,h in production.items():assert sha((root/name).read_bytes())==h
fmt=subprocess.run(['cargo','fmt','--all','--check'],cwd=root,capture_output=True,text=True);assert fmt.returncode==0
(raw/'fmt.stdout').write_text(fmt.stdout);(raw/'fmt.stderr').write_text(fmt.stderr)
files={'final/'+p.name:p for p in raw.iterdir() if p.is_file()}
for p in Path('/tmp/penelope-050-nested-example').iterdir():
 if p.is_file():files['earlier-verbose-output/'+p.name]=p
files.update({'driver.py':Path('/tmp/penelope-050-nested-example-followup.py'),'earlier-driver.py':Path('/tmp/penelope-050-nested-example.py'),'recorder.py':Path(__file__),'nested_order.rs':root/source})
archive=dest/'nested-example.tar.gz';members={n:sha(p.read_bytes()) for n,p in files.items()}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as t:
 for n,h in members.items():assert sha(t.extractfile(n).read())==h
m={'scope':'Plan9.2 public nested-example follow-up. Existing model now demonstrates staged hook traces, invalid-payment guard, leaf-terminal refusal, external self-transition and parent cancellation through the same MemoryMachine owner. Source-consumer qualification only; not new library behavior or fresh all-ten package qualification.','base_commit':base,'source':{'path':source,'sha256':sha((root/source).read_bytes())},'checks':checks,'format_check_exit_code':0,'observations':{'trace_sequences':expected,'events':6,'independent_local_scenarios':2,'guard_codes':[1,2],'accepted_revisions_by_scenario':[[1,2,3],[1]],'receipt_state_retained_on_self_edge':7,'model_hook_logging':False,'trace_effects_staged_until_publication':True,'production_files_unchanged_from_current_package_checkpoint':len(production)},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'limits':['Earlier verbose-output checks are retained separately; final runs validate compact output and final source.','Fixture identities and deterministic one-byte trace metadata demonstrate local preparation, not authentication or durable delivery.','No Clone or heap-backed state is introduced; this run is not an allocator measurement. Existing allocator/hierarchy tests retain their independent source and fixture scopes.','Full chaos, retained performance findings, remaining normative/test review and final artifact reconciliation remain open.']}
(dest/'nested-example.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified final stable/MSRV run+Clippy, six trace/guard/revision scenarios,72 unchanged production files and',len(members),'archive members.')
