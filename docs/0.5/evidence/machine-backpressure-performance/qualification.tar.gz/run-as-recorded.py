import hashlib,json,math,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=Path('/tmp/penelope-machine-backpressure-qualification');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after')}
checks=[]
def run(label,args,expected=0,extra=None):
 started=time.time();result=subprocess.run(args,env={**env,**(extra or {})},text=True,capture_output=True)
 (out/(label+'.stdout')).write_text(result.stdout);(out/(label+'.stderr')).write_text(result.stderr)
 checks.append({'label':label,'args':args,'exit_code':result.returncode,'expected_exit':expected,'seconds':time.time()-started});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 assert result.returncode==expected,(label,result.stderr[-2000:]);print(label,'passed',flush=True);return result
runner=['python3','scripts/benchmark-durable-store.py']
common=['--data-parent',str(root/'target'),'--cpu','4','--benchmark','machine_backpressure']
for toolchain,count in [('1.100.0',3),('1.89.0',1)]:
 run('measure-'+toolchain,runner+[str(out/toolchain),*common,'--runs',str(count),'--toolchain',toolchain])
 for p in (out/toolchain).glob('run-*.json'):
  if 'resources' in p.name:continue
  data=json.loads(p.read_text());assert data['benchmark']=='machine_backpressure' and data['measurement_mode']=='release-101'
  assert [(c['queue_capacity'],c['requests_per_round']) for c in data['profiles']]==[(1,32),(1,128),(8,32),(8,128)]
  for c in data['profiles']:
   assert c['measured_rounds']==101 and c['warmup_rounds']==8 and len(c['rounds'])==101
   assert c['event_rows_including_warmup']==c['intent_rows_including_warmup']==109 and c['integrity_check']=='ok'
   for r in c['rounds']:
    assert 1<=r['admitted']<=c['queue_capacity']+1
    assert r['admitted']+r['refused']==c['requests_per_round'] and r['refused']>=c['requests_per_round']-c['queue_capacity']-1
    assert r['committed']==1 and r['stale']+1==r['admitted']
   for name,count_key in [('refusal_first_poll','refused'),('accepted_first_poll','admitted'),('accepted_gated_completion','admitted')]:
    d=c[name];raw=d['raw_ns'];assert d['samples']==len(raw)==sum(r[count_key] for r in c['rounds']) and min(raw)>0
    ordered=sorted(raw)
    for pct in [50,95,99]:assert d[f'p{pct}_ns']==ordered[math.ceil(len(raw)*pct/100)-1]
 run('debug-'+toolchain,['cargo','+'+toolchain,'test','--locked','-p','penelope-sqlite','--bench','machine_backpressure'])
 run('worker-tests-'+toolchain,['cargo','+'+toolchain,'test','--locked','-p','penelope-sqlite','--lib','worker::tests'])
run('legacy-runner-default',runner+[str(out/'legacy-default'),'--data-parent',str(root/'target'),'--cpu','4','--runs','1'])
result=run('expected-debug-refusal',runner+[str(out/'expected-debug-refusal'),*common,'--runs','1'],expected=1,extra={'CARGO_PROFILE_BENCH_DEBUG_ASSERTIONS':'true'})
assert 'machine measurements require the full release profile' in result.stderr
run('clippy',['cargo','clippy','--locked','-p','penelope-sqlite','--bench','machine_backpressure','--all-features','--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
run('diff',['git','diff','--check'])
metadata={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_diff':subprocess.check_output(['git','diff','HEAD'],text=True),'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['crates/penelope-sqlite/benches/machine_backpressure.rs','crates/penelope-sqlite/tests/support/machines.rs','scripts/benchmark-durable-store.py','Cargo.lock']}}
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print('All counts, bounds, sample ranks and release-mode refusals verified',flush=True)
