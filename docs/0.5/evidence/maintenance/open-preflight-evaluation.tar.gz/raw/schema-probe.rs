use penelope_core::task::runtime::TaskPortError;
use rusqlite::{Connection, TransactionBehavior};
use std::{path::Path, time::Duration};

/// Connection and admission limits. Bounds are checked before copying stored
/// records/blobs into owned memory. Database pages bound aggregate disk growth.
#[derive(Debug, Clone, Copy)]
pub struct SqliteLimits {
    pub max_blob_bytes: u32,
    pub max_record_bytes: u32,
    pub max_history_records: u32,
    pub max_scope_bytes: u64,
    pub max_scopes: u32,
    pub max_database_bytes: u64,
    pub busy_timeout: Duration,
}

impl Default for SqliteLimits {
    fn default() -> Self {
        Self {
            max_blob_bytes: 1024 * 1024,
            max_record_bytes: 16 * 1024,
            max_history_records: 65536,
            max_scope_bytes: 64 * 1024 * 1024,
            max_scopes: 1024,
            max_database_bytes: 1024 * 1024 * 1024,
            busy_timeout: Duration::from_secs(5),
        }
    }
}

// SQLite exposes non-exhaustive external error taxonomies. Unknown codes fail closed.
#[allow(clippy::wildcard_enum_match_arm)]
pub(crate) const fn sql_error(error: &rusqlite::Error) -> TaskPortError {
    match error {
        rusqlite::Error::SqliteFailure(failure, _) => match failure.code {
            rusqlite::ErrorCode::DatabaseCorrupt | rusqlite::ErrorCode::NotADatabase => {
                TaskPortError::Corrupt
            }
            rusqlite::ErrorCode::DiskFull | rusqlite::ErrorCode::TooBig => TaskPortError::Exhausted,
            rusqlite::ErrorCode::ConstraintViolation => TaskPortError::Conflict,
            _ => TaskPortError::Unavailable,
        },
        _ => TaskPortError::Corrupt,
    }
}

// Required single-row writes run inside the caller's transaction. SQLite can
// successfully execute a statement while a trigger suppresses its row change.
pub(crate) fn execute_one(
    connection: &Connection,
    sql: &str,
    params: impl rusqlite::Params,
) -> Result<(), TaskPortError> {
    let changed = connection
        .execute(sql, params)
        .map_err(|error| sql_error(&error))?;
    if changed != 1 {
        return Err(TaskPortError::Corrupt);
    }
    Ok(())
}

pub(crate) fn open(path: &Path, limits: SqliteLimits) -> Result<Connection, TaskPortError> {
    if limits.max_blob_bytes == 0
        || limits.max_record_bytes < 4096
        || limits.max_history_records < 4
        || limits.max_scopes == 0
        || limits.max_scope_bytes == 0
        || limits.max_database_bytes < 65536
        || limits.busy_timeout > Duration::from_secs(60)
    {
        return Err(TaskPortError::Exhausted);
    }
    let mut connection = Connection::open(path).map_err(|error| sql_error(&error))?;
    // Queries bind typed identities and limits. Keep cached plans independent
    // of parameter values instead of recompiling them during journal replay.
    connection
        .set_db_config(
            rusqlite::config::DbConfig::SQLITE_DBCONFIG_ENABLE_QPSG,
            true,
        )
        .map_err(|error| sql_error(&error))?;
    connection
        .busy_timeout(limits.busy_timeout)
        .map_err(|error| sql_error(&error))?;
    let mode: String = connection
        .query_row("PRAGMA journal_mode=WAL", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    if !mode.eq_ignore_ascii_case("wal") {
        return Err(TaskPortError::Unavailable);
    }
    connection
        .pragma_update(None, "synchronous", "FULL")
        .map_err(|error| sql_error(&error))?;
    connection
        .pragma_update(None, "foreign_keys", "ON")
        .map_err(|error| sql_error(&error))?;
    let page_size: u32 = connection
        .query_row("PRAGMA page_size", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    let pages = limits
        .max_database_bytes
        .checked_div(u64::from(page_size))
        .ok_or(TaskPortError::Exhausted)?;
    connection
        .pragma_update(
            None,
            "max_page_count",
            i64::try_from(pages).map_err(|_invalid| TaskPortError::Exhausted)?,
        )
        .map_err(|error| sql_error(&error))?;
    let actual_pages: u32 = connection
        .query_row("PRAGMA max_page_count", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    if u64::from(actual_pages) > pages {
        return Err(TaskPortError::Exhausted);
    }
    // Current schemas need no migration write transaction. Older versions are
    // still re-read under the migration transaction before any schema changes.
    let current_version: u32 = connection
        .query_row("PRAGMA user_version", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    if current_version > 9 {
        return Err(TaskPortError::Corrupt);
    }
    if current_version == 9 {
        return Ok(connection);
    }
    #[cfg(all(test, unix))]
    tests::cut("before-transaction");
    let transaction = connection
        .transaction_with_behavior(TransactionBehavior::Immediate)
        .map_err(|error| sql_error(&error))?;
    #[cfg(all(test, unix))]
    tests::cut("after-begin");
    let version: u32 = transaction
        .query_row("PRAGMA user_version", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    if version > 9 {
        return Err(TaskPortError::Corrupt);
    }
    if version == 0 {
        transaction.execute_batch(
            "CREATE TABLE task_heads (
                scope BLOB PRIMARY KEY CHECK(length(scope)=128),
                next_sequence INTEGER NOT NULL CHECK(next_sequence>0),
                last_digest BLOB NOT NULL CHECK(length(last_digest)=32),
                bytes_used INTEGER NOT NULL CHECK(bytes_used>=0));
             CREATE TABLE task_records (
                scope BLOB NOT NULL, sequence INTEGER NOT NULL CHECK(sequence>=0),
                record BLOB NOT NULL, checksum BLOB NOT NULL CHECK(length(checksum)=32),
                PRIMARY KEY(scope, sequence));
             CREATE TABLE task_blobs (
                scope BLOB NOT NULL, digest BLOB NOT NULL CHECK(length(digest)=32), bytes BLOB NOT NULL,
                PRIMARY KEY(scope, digest));
             CREATE TABLE runtime_generations (
                scope BLOB NOT NULL CHECK(length(scope)=128), generation INTEGER NOT NULL CHECK(generation>0),
                execution BLOB CHECK(execution IS NULL OR length(execution)=32),
                state INTEGER NOT NULL CHECK(state IN (0,1,2)),
                PRIMARY KEY(scope,generation));
             PRAGMA user_version=1;"
        ).map_err(|error| sql_error(&error))?;
    }
    if version < 2 {
        transaction
            .execute_batch(
                "CREATE TABLE task_retirements (
            scope BLOB PRIMARY KEY CHECK(length(scope)=128),
            next_sequence INTEGER NOT NULL CHECK(next_sequence>0),
            last_digest BLOB NOT NULL CHECK(length(last_digest)=32));
            PRAGMA user_version=2;",
            )
            .map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v2");
    if version < 3 {
        transaction.execute_batch("CREATE TABLE process_usage (
            process_key BLOB PRIMARY KEY, bytes_used INTEGER NOT NULL CHECK(bytes_used>=0));
          CREATE TABLE process_heads (
            scope BLOB PRIMARY KEY, process_key BLOB NOT NULL UNIQUE,
            next_sequence INTEGER NOT NULL CHECK(next_sequence>0),
            bytes_used INTEGER NOT NULL CHECK(bytes_used>=0));
          CREATE TABLE process_outcomes (
            scope BLOB NOT NULL, sequence INTEGER NOT NULL CHECK(sequence>=0),
            outcome_id TEXT NOT NULL, record BLOB NOT NULL, checksum BLOB NOT NULL,
            PRIMARY KEY(scope,sequence), UNIQUE(scope,outcome_id));
          CREATE TABLE process_inbox (
            process_key BLOB NOT NULL, input_id TEXT NOT NULL,
            input BLOB NOT NULL, checksum BLOB NOT NULL, commit_digest BLOB,
            committed_through INTEGER,
            PRIMARY KEY(process_key,input_id));
          CREATE TABLE process_sources (
            process_key BLOB NOT NULL, event_id TEXT NOT NULL,
            input_id TEXT NOT NULL,
            PRIMARY KEY(process_key,event_id));
          CREATE TABLE process_commits (
            scope BLOB NOT NULL, first_sequence INTEGER NOT NULL,
            commit_digest BLOB NOT NULL, committed_through INTEGER NOT NULL,
            PRIMARY KEY(scope,first_sequence));
          CREATE TABLE process_actions (
            scope BLOB NOT NULL, action_id TEXT NOT NULL, effect_key BLOB NOT NULL,
            action BLOB NOT NULL, checksum BLOB NOT NULL,
            attempt INTEGER NOT NULL DEFAULT 0, acknowledged INTEGER NOT NULL DEFAULT 0,
            lease BLOB, expires_at INTEGER,
            PRIMARY KEY(scope,action_id), UNIQUE(scope,effect_key));
          CREATE TABLE process_timers (
            scope BLOB NOT NULL, action_id TEXT NOT NULL, timer BLOB NOT NULL,
            checksum BLOB NOT NULL, due_at INTEGER NOT NULL,
            state INTEGER NOT NULL DEFAULT 0, attempt INTEGER NOT NULL DEFAULT 0,
            lease BLOB, expires_at INTEGER,
            PRIMARY KEY(scope,action_id));
          CREATE TABLE lease_counter (singleton INTEGER PRIMARY KEY CHECK(singleton=1), next_token INTEGER NOT NULL CHECK(next_token>0));
          INSERT INTO lease_counter VALUES (1,1);
          PRAGMA user_version=3;").map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v3");
    if version < 4 {
        transaction
            .execute_batch(
                "CREATE TABLE process_payloads (
            scope BLOB NOT NULL, digest BLOB NOT NULL CHECK(length(digest)=32),
            bytes BLOB NOT NULL, PRIMARY KEY(scope,digest));
            PRAGMA user_version=4;",
            )
            .map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v4");
    if version < 5 {
        transaction.execute_batch(
            "CREATE INDEX process_actions_pending ON process_actions(scope,action_id) WHERE acknowledged=0;"
        ).map_err(|error| sql_error(&error))?;
        #[cfg(all(test, unix))]
        tests::cut("after-outbox-index");
        transaction.execute_batch(
            "CREATE INDEX process_timers_due ON process_timers(scope,due_at,action_id) WHERE state=0;
             PRAGMA user_version=5;"
        ).map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v5");
    if version < 6 {
        transaction.execute_batch(
            "CREATE INDEX process_inbox_pending ON process_inbox(process_key,input_id) WHERE commit_digest IS NULL;"
        ).map_err(|error| sql_error(&error))?;
        #[cfg(all(test, unix))]
        tests::cut("after-inbox-index");
        transaction
            .pragma_update(None, "user_version", 6)
            .map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v6");
    if version < 7 {
        transaction.execute_batch(
            "CREATE TABLE machine_heads (
                machine_key BLOB PRIMARY KEY CHECK(length(machine_key)=64),
                scope BLOB NOT NULL CHECK(length(scope)=104),
                revision BLOB NOT NULL CHECK(length(revision)=8),
                genesis BLOB NOT NULL, genesis_digest BLOB NOT NULL CHECK(length(genesis_digest)=32),
                state BLOB NOT NULL, state_digest BLOB NOT NULL CHECK(length(state_digest)=32),
                last_event BLOB CHECK(last_event IS NULL OR length(last_event)=32),
                bytes_used INTEGER NOT NULL CHECK(bytes_used>=0),
                event_count INTEGER NOT NULL CHECK(event_count>=0));
             CREATE TABLE machine_events (
                machine_key BLOB NOT NULL REFERENCES machine_heads(machine_key),
                event BLOB NOT NULL CHECK(length(event)=32),
                revision BLOB NOT NULL CHECK(length(revision)=8),
                record BLOB NOT NULL, event_payload BLOB NOT NULL, state BLOB NOT NULL,
                PRIMARY KEY(machine_key,event), UNIQUE(machine_key,revision));
             CREATE TABLE machine_intents (
                machine_key BLOB NOT NULL, intent BLOB NOT NULL CHECK(length(intent)=32),
                event BLOB NOT NULL CHECK(length(event)=32),
                ordinal INTEGER NOT NULL CHECK(ordinal>=0), payload BLOB NOT NULL,
                PRIMARY KEY(machine_key,intent), UNIQUE(machine_key,event,ordinal),
                FOREIGN KEY(machine_key,event) REFERENCES machine_events(machine_key,event));
             PRAGMA user_version=7;"
        ).map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v7");
    if version < 8 {
        transaction.execute_batch(
            "ALTER TABLE machine_heads ADD COLUMN delivery_bytes INTEGER NOT NULL DEFAULT 0 CHECK(delivery_bytes>=0);
             ALTER TABLE machine_heads ADD COLUMN lease_tick BLOB NOT NULL DEFAULT x'0000000000000000' CHECK(length(lease_tick)=8);
             CREATE TABLE machine_intent_delivery (
                machine_key BLOB NOT NULL, intent BLOB NOT NULL CHECK(length(intent)=32),
                owner BLOB NOT NULL CHECK(length(owner)=32), token INTEGER NOT NULL CHECK(token>0),
                expires BLOB NOT NULL CHECK(length(expires)=8),
                attempt INTEGER NOT NULL CHECK(attempt BETWEEN 1 AND 65535),
                consumer BLOB CHECK(consumer IS NULL OR length(consumer)=32),
                receipt BLOB CHECK(receipt IS NULL OR length(receipt)=32),
                CHECK((consumer IS NULL)=(receipt IS NULL)),
                PRIMARY KEY(machine_key,intent),
                FOREIGN KEY(machine_key,intent) REFERENCES machine_intents(machine_key,intent));
             CREATE INDEX machine_delivery_pending ON machine_intent_delivery(machine_key,expires,intent) WHERE receipt IS NULL;
             PRAGMA user_version=8;"
        ).map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v8");
    if version < 9 {
        transaction.execute_batch(
            "DROP INDEX machine_delivery_pending;
             ALTER TABLE machine_intent_delivery RENAME TO machine_intent_delivery_v8;
             CREATE TABLE machine_intent_delivery (
                machine_key BLOB NOT NULL, intent BLOB NOT NULL CHECK(length(intent)=32),
                owner BLOB NOT NULL CHECK(length(owner)=32), token INTEGER NOT NULL CHECK(token>0),
                expires BLOB NOT NULL CHECK(length(expires)=8),
                attempt INTEGER NOT NULL CHECK(attempt BETWEEN 1 AND 65535),
                consumer BLOB CHECK(consumer IS NULL OR length(consumer)=32),
                receipt BLOB CHECK(receipt IS NULL OR length(receipt)=32),
                CHECK(receipt IS NULL OR consumer IS NOT NULL),
                PRIMARY KEY(machine_key,intent),
                FOREIGN KEY(machine_key,intent) REFERENCES machine_intents(machine_key,intent));
             INSERT INTO machine_intent_delivery SELECT * FROM machine_intent_delivery_v8;
             DROP TABLE machine_intent_delivery_v8;
             CREATE INDEX machine_delivery_pending ON machine_intent_delivery(machine_key,expires,intent) WHERE receipt IS NULL;
             PRAGMA user_version=9;"
        ).map_err(|error| sql_error(&error))?;
    }
    #[cfg(all(test, unix))]
    tests::cut("after-v9");
    #[cfg(all(test, unix))]
    tests::cut("before-commit");
    transaction.commit().map_err(|error| sql_error(&error))?;
    #[cfg(all(test, unix))]
    tests::cut("after-commit");
    Ok(connection)
}

#[cfg(all(test, unix))]
#[path = "schema_tests.rs"]
mod tests;
