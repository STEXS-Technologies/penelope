use penelope_sqlite::{SqliteLeaseClock, SqliteLimits, SqliteProcessStore};
use rusqlite::{Connection, TransactionBehavior};
use std::{sync::Arc, time::Duration};
struct Clock;
impl SqliteLeaseClock for Clock {
    fn now(&self) -> Result<penelope_domain::LogicalTime, penelope_ports::PortError> {
        Ok(penelope_domain::LogicalTime(0))
    }
}

#[test]
fn current_schema_open_needs_no_writer_but_future_schema_is_refused() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("probe.db");
    let limits = SqliteLimits { busy_timeout: Duration::ZERO, ..SqliteLimits::default() };
    drop(SqliteProcessStore::open(&path, limits, Arc::new(Clock), 1, 1).unwrap());
    let mut writer = Connection::open(&path).unwrap();
    let transaction = writer.transaction_with_behavior(TransactionBehavior::Immediate).unwrap();
    drop(SqliteProcessStore::open(&path, limits, Arc::new(Clock), 1, 1).expect("current schema open must not request the writer lock"));
    transaction.rollback().unwrap();
    writer.pragma_update(None, "user_version", 10).unwrap();
    assert!(SqliteProcessStore::open(&path, limits, Arc::new(Clock), 1, 1).is_err());
    let version: u32 = writer.query_row("PRAGMA user_version", [], |row| row.get(0)).unwrap();
    assert_eq!(version, 10);
}
