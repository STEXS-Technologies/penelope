import hashlib,json,tarfile,statistics,subprocess
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');probe=Path('/home/ac/projects/.penelope-050-open-probe');raw=Path('/tmp/penelope-050-open-probe');dest=root/'docs/0.5/evidence/maintenance';sha=lambda b:hashlib.sha256(b).hexdigest()
source='c0e99972a7103ea349f78178446b7e19fb0b6ff9'
assert (raw/'schema-before.rs').read_bytes()==subprocess.check_output(['git','show',source+':crates/penelope-sqlite/src/schema.rs'],cwd=root)
assert (probe/'crates/penelope-sqlite/src/schema.rs').read_bytes()==(raw/'schema-probe.rs').read_bytes()
assert all(x['exit_code']==0 for x in json.loads((raw/'checks.json').read_text()))
assert '59 passed; 0 failed' in (raw/'sqlite-tests.stdout').read_text()
assert '1 passed; 0 failed' in (raw/'restored-probe-lock-test.log').read_text()
assert 'current schema open must not request the writer lock' in (raw/'original-lock-negative-control.log').read_text()
def flatten(j,p=''):
 result={}
 if isinstance(j,dict):
  for k,v in j.items():result.update(flatten(v,p+'/'+k))
 elif isinstance(j,list):
  for i,v in enumerate(j):result.update(flatten(v,p+'/'+str(i)))
 elif p.endswith('_ns') and isinstance(j,(int,float)):result[p]=j
 return result
runs={k:[flatten(json.loads((raw/f'round-{i}-{k}.stdout').read_text())) for i in range(1,8)] for k in ['control','probe']}
keys=set(runs['control'][0]);assert all(set(x)==keys for series in runs.values() for x in series)
metrics=[]
for key in sorted(keys):
 a=[r[key] for r in runs['control']];b=[r[key] for r in runs['probe']]
 changes=[(y/x-1)*100 for x,y in zip(a,b)];metrics.append({'metric':key,'control_median_ns':statistics.median(a),'probe_median_ns':statistics.median(b),'paired_change_percent':changes,'median_paired_change_percent':statistics.median(changes)})
files={'raw/'+p.name:p for p in raw.iterdir() if p.is_file()}
files.update({'driver.py':Path('/tmp/penelope-050-open-probe.py'),'recorder.py':Path(__file__),'lock-test.rs':probe/'crates/penelope-sqlite/tests/open_fast_path_probe.rs'})
archive=dest/'open-preflight-evaluation.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
member_hash={name:sha(p.read_bytes()) for name,p in files.items()}
with tarfile.open(archive) as t:assert {m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}==member_hash
record={'source_commit':source,'decision':'Not adopted. Seven shared-host pairs do not establish a reliable performance fix. Keep the current candidate production bytes unchanged; an isolated larger comparison and migration/concurrency qualification are required before reconsidering.','change':'Diagnostic only: return after a read-only user_version check when the schema is9; old schemas retain transactional revalidation and migration.','conditions':'Rust1.100; both binaries fully built before timing; one unmeasured warmup pair, seven alternating-order measured pairs, CPU4, actual local filesystem WAL/FULL. Other qualification jobs remain active on this shared host; this is not an isolated latency benchmark.','metrics':metrics,'correctness':{'sqlite_unit_tests':59,'focused_lock_test':'Probe opens schema9 with zero busy timeout while another connection holds BEGIN IMMEDIATE, then refuses schema10 without rewriting it. Original production fails the writer-lock oracle; restored probe passes.','limits':'Diagnostic test only; not an exhaustive concurrent schema-change model or final release qualification. Two initial test-authoring compile errors were corrected before the semantic control; they are not treated as model failures.'},'candidate_schema_sha256':sha((root/'crates/penelope-sqlite/src/schema.rs').read_bytes()),'probe_schema_sha256':sha((raw/'schema-probe.rs').read_bytes()),'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':member_hash}}
assert record['candidate_schema_sha256']==sha((raw/'schema-before.rs').read_bytes())
(dest/'open-preflight-evaluation.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified',len(files),'members and',len(metrics),'timing metrics; diagnostic not adopted')
