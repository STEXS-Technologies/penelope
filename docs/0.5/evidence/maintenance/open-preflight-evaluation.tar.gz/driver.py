import subprocess,os,json,time,hashlib,shutil
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-open-probe');out=Path('/tmp/penelope-050-open-probe');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/open-probe','PENELOPE_BENCH_DIR':'/home/ac/projects/penelope/target/open-probe-data'}
Path(env['PENELOPE_BENCH_DIR']).mkdir(exist_ok=True)
checks=[]
def run(label,args):
 start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 checks.append({'label':label,'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode();return r.stdout
p=root/'crates/penelope-sqlite/src/schema.rs';before=p.read_bytes();(out/'schema-before.rs').write_bytes(before)
for label in ['control','probe']:
 if label=='probe':
  needle='    #[cfg(all(test, unix))]\n    tests::cut("before-transaction");'
  replacement='''    // Current schemas need no migration write transaction. Older versions are
    // still re-read under the migration transaction before any schema changes.
    let current_version: u32 = connection
        .query_row("PRAGMA user_version", [], |row| row.get(0))
        .map_err(|error| sql_error(&error))?;
    if current_version > 9 {
        return Err(TaskPortError::Corrupt);
    }
    if current_version == 9 {
        return Ok(connection);
    }
'''+needle
  text=before.decode();assert text.count(needle)==1;p.write_text(text.replace(needle,replacement));(out/'schema-probe.rs').write_bytes(p.read_bytes())
 raw=run('build-'+label,['taskset','-c','4-7','cargo','+1.100.0','bench','-p','penelope-sqlite','--bench','durable_store','--locked','--no-run','--message-format=json'])
 arts=[x['executable'] for line in raw.splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x['target']['name']=='durable_store' and x.get('executable')];assert len(arts)==1
 shutil.copy2(arts[0],out/(label+'.bin'))
(out/'source.patch').write_text(subprocess.check_output(['git','diff'],cwd=root,text=True))
for n in range(8):
 for label in (['control','probe'] if n%2==0 else ['probe','control']):
  print('round',n,label,flush=True)
  raw=run(('warmup' if n==0 else 'round-'+str(n))+'-'+label,['taskset','-c','4',str(out/(label+'.bin'))]);j=json.loads(raw);assert j['journal_mode']=='WAL' and j['synchronous']=='FULL'
run('sqlite-tests',['cargo','+1.100.0','test','-p','penelope-sqlite','--lib','--locked'])
print('completed diagnostic; not adopted',flush=True)
