import collections,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');plan=root/'docs/0.5/plan.md';text=plan.read_text();sha=lambda b:hashlib.sha256(b).hexdigest()
references={
 'baseline':['docs/0.5/baseline.md','docs/0.5/baseline/source-sha256.json','docs/0.5/baseline/packages.json','docs/0.5/evidence/manifest.json','docs/0.5/evidence/baseline-complete-chaos/manifest.json'],
 'contracts':['docs/0.5/architecture.md','docs/0.5/public-api.md','crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/identities.rs','crates/penelope-core/src/machine/memory.rs'],
 'hierarchy':['crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/tests/machine_hierarchy.rs','crates/penelope/examples/nested_order.rs','docs/0.5/evidence/qualification/generated-machine-models.json'],
 'portable':['crates/penelope-core/Cargo.toml','crates/penelope-core/tests/machine_allocations.rs','scripts/check-layer-boundaries.sh','docs/0.5/evidence/packaging/qpsg-candidate-checkpoint.json'],
 'wire':['crates/penelope-core/src/machine/wire.rs','crates/penelope-core/tests/machine_wire.rs','scripts/verify-machine-wire-fixtures.py','docs/0.5/machine-wire.md'],
 'saga':['crates/penelope-executor/src/saga_machine.rs','crates/penelope/tests/prepared_lifecycles.rs','docs/0.5/prepared-adapters.md','docs/0.5/evidence/machine-saga/manifest.json'],
 'examples':['ci/machine-consumer/Cargo.toml','ci/machine-consumer/durable.rs','ci/machine-consumer/workflow.rs','crates/penelope/examples/prepared_decisions.rs','crates/penelope/examples/trade.rs','crates/penelope/examples/trade_compensation.rs','crates/penelope/examples/trade_retry_timer.rs','docs/0.5/evidence/qualification/graph-example.json'],
 'task':['crates/penelope-core/src/task/projection.rs','crates/penelope-core/src/task/control.rs','crates/penelope-ports/src/machine/task.rs','docs/0.5/evidence/machine-task/manifest.json'],
 'timeline':['crates/penelope-timeline/src/machine.rs','crates/penelope-timeline/tests/machine.rs','docs/0.5/timeline-machines.md'],
 'storage':['crates/penelope-ports/src/machine/store.rs','crates/penelope-ports/src/machine/recovery.rs','crates/penelope-sqlite/src/machine.rs','crates/penelope-sqlite/src/machine/read.rs','crates/penelope-sqlite/src/machine/delivery.rs','docs/0.5/machine-storage.md','docs/0.5/evidence/machine-outbox/manifest.json','docs/0.5/evidence/qualification/machine-history-partitions.json'],
 'compatibility':['docs/0.5/compatibility-matrix.md','ci/compat-0.4/README.md','docs/0.5/evidence/maintenance/public-api-audit.json','docs/0.5/evidence/sqlite-upgrade/manifest.json'],
 'maintenance':['docs/0.5/architecture.md','docs/0.5/evidence/maintenance/acceptance-audit.json','docs/0.5/evidence/maintenance/invariant-audit.json','docs/0.5/evidence/maintenance/manifest.json'],
 'onboarding':['README.md','docs/getting-started.md','ci/machine-consumer/build.rs','docs/README.md'],
 'performance':['docs/0.5/evidence/legacy-balanced/versioned-candidate.json','docs/0.5/evidence/sqlite-balanced/qpsg-balanced.json','docs/0.5/evidence/qualification/candidate-capability-performance.json','docs/0.5/verification.md'],
 'qualification':['docs/0.5/evidence/qualification/history-partition-checkpoint.json','docs/0.5/evidence/qualification/generated-machine-models.json','docs/0.5/verification.md','docs/RELEASE.md','CHANGELOG.md']}
# Each tuple applies to one exact Work bullet in order, rather than an inferred phase summary.
rows={
'F0':[
 ('supported','baseline','Original tag/commit, toolchains, metadata, feature inventory and source hashes are frozen; later candidate evidence has a distinct source scope.'),
 ('historical_sequence_not_proven','baseline performance','Baseline checks and completed default chaos exist on unchanged original source, with equivalent-work comparisons. This audit does not prove every profile finished before implementation began; performance conclusions also remain open.'),
 ('supported','baseline','Original advisory failures, interrupted campaign and environment limitations remain recorded; completed unchanged-source chaos supplements the interrupted attempt.'),
 ('supported','baseline compatibility','Baseline semantics map and facade snapshot describe old ownership; independent export traversal reviews retained bindings across14 profiles.'),
 ('supported','compatibility','Independent consumer and frozen old task/timeline/saga observations are retained, with an actual old-writer database fixture.')],
'F1':[
 ('supported','contracts','ADRs settle reducer, hierarchy, consuming publication, separate storage authority and native engine boundaries; API sketches in the imported plan are not presented as compiled API.'),
 ('supported','contracts storage','Rejected/unhandled do not publish; evaluation errors preserve concrete types. CAS conflict, missing commit acknowledgement and unknown external effect remain separate contracts.'),
 ('supported','contracts wire','Typed scopes, definition/schema, native revisions, event/transition identities and provenance are defined without automatic conversion from saga/task/timeline coordinates.'),
 ('supported','contracts hierarchy portable','HSM uses bounded inline StatePath storage with const depth, cycle/depth refusal and no mandatory heap/runtime; hosted facade and portable core profiles are distinguished.'),
 ('historical_sequence_not_proven','examples qualification','Current flat/nested/prepared fixtures compile and run on stable/MSRV. This audit has not reconstructed whether every fixture was compile-tested before its implementation, as the plan requested.'),
 ('supported','wire','Independent Python-generated goldens, bounded versioned metadata and hosted canonical payload binding are implemented; old protocols retain separate versions.')],
'F2':[
 ('supported','contracts','Portable Machine, typed outcomes/errors, IntentSink and consuming MemoryMachine/PreparedTransition are implemented in existing core modules.'),
 ('supported','contracts maintenance','Preparation isolates candidate data and staging, validates before publication and publishes coherent state/head/provenance/intents. Callback purity remains a consumer obligation.'),
 ('supported','portable contracts','Base trait has no Clone/serialization bound; allocator probes cover flat/hierarchical allocation-free consumer types with positive controls.'),
 ('supported','hierarchy qualification','Bounded parent paths, terminal refusals, LCA hooks and internal/self behavior have explicit tests, independent tree/table oracles and stable/MSRV checks.'),
 ('supported','portable','Core dependency manifest and enforced layering keep mandatory runtime/SQLite/saga/task-host/timeline dependencies out of portable machine evaluation.'),
 ('supported','portable qualification','Archived stable/MSRV RISC-V builds and machine-specific allocator probes cover the supported bare/serde profiles; no physical-board or arbitrary callback guarantee follows.')],
'F3':[
 ('supported','saga contracts','Canonical saga namespace exposes native linear/graph preparation with common read-only decision inspection, retaining native state/provenance types.'),
 ('supported','saga maintenance','Preparation delegates to existing engines; common inspection and verified receipt helpers have multiple real callers. Graph protocol/evaluation authority is not replaced by an unnecessary universal graph engine.'),
 ('supported','saga compatibility','Frozen old saga observations cover statuses, compensation, retry/manual-review/unknown outcomes and replay through legacy and prepared paths; independent wire contracts remain unchanged.'),
 ('performance_review_open','saga compatibility performance','Legacy fast functions remain available and preparation delegates once. Measured selected saga profiles do not cross the review threshold, which does not prove universal latency equivalence or close the release performance gate.'),
 ('supported','examples','Trade, compensation and retry use prepare_linear. The shared prepared_decisions example now includes graph preparation using the same inspection helper; durable consumer demonstrates application-machine/native-saga coordination.')],
'F4':[
 ('supported','task contracts','Task prepared record view implements shared inspection while native TaskStatus, record sequence and effect types retain their meanings.'),
 ('supported','task compatibility','One private isolated-candidate evaluator serves propose/apply/prepare. Frozen old projection comparisons and failure tests retain atomic application and native recovery boundaries.'),
 ('supported','task examples storage','Native receiver binds full machine source and host policy; protected consumer verifies actual task output before subsequent machine transition. Admission and source acknowledgement remain distinct.'),
 ('supported','task maintenance examples','Native TaskControl/Supervisor retain journal-first commands, generation/recovery fencing and ambiguity/poisoning. Protected workflow and audited negative tests exercise those boundaries.'),
 ('supported','portable','Pure machine core has no task runtime dependency. The existing hosted facade is not claimed to be no_std.')],
'F5':[
 ('supported','timeline','MachineTimeline implements existing RewindableComputation with captured context, isolated candidate and staged effects; no second correction engine is introduced.'),
 ('supported','timeline maintenance','Native LiveTimeline/history/reservations/replay/head/finality remain authoritative. Adapter storage/provenance wrappers preserve distinct native and timeline coordinates.'),
 ('supported','timeline','Machine adapter tests distinguish native-memory state, live steps, corrected tentative effects and finalized handoff, including finalized-prefix refusal and failure isolation.'),
 ('supported','timeline','Pinned definition/schema mismatch refuses correction. Documentation requires complete deterministic inputs and explains when mutable aliases or uncaptured dependencies make rewind ineligible.'),
 ('supported','timeline storage','Docs explicitly separate in-memory timeline correction from durable machine snapshots; no persistent full-timeline recovery profile is claimed.')],
'F6':[
 ('supported','wire storage','Portable machine metadata and hosted payload/storage contracts use an independent protocol while retaining no_std separation.'),
 ('supported','storage qualification','Authorized bounded journal/CAS, exact retries/receipts, snapshots, migrations, quotas and source-bound delivery are implemented and tested; final full-source chaos remains open.'),
 ('supported','storage maintenance','DatabaseWorker, byte/identity admission and verified receipt helpers are shared. Native transactions/leases remain separate for documented authority and protocol reasons; no blanket absence-of-duplication claim is made.'),
 ('supported','storage saga task examples','Native task/saga receivers bind exact committed source and their own acceptance evidence; source acknowledgement is separately fenced, not a cross-store transaction.'),
 ('supported','storage','Test-only journal peer checks preparation/CAS/receipt behavior and is explicitly not production crash-durable storage.'),
 ('supported','storage compatibility','SQLite profile remains single-host WAL/FULL on supported local disk; neither clustered durability nor exactly-once external execution is inferred.')],
'F7':[
 ('supported','contracts compatibility examples','Canonical namespaces retain checked legacy exports; unchanged old consumer and current examples compile under their distinct dependency profiles.'),
 ('supported','maintenance','Verified shared owners replace repeated admission/candidate/worker/receipt plumbing. Legacy decoders and protocol-specific checks remain; no overall production LoC reduction is claimed.'),
 ('supported','onboarding','Short README starts with branch setup and canonical first-machine tutorial, then links optional durability/task/saga/timeline progression without duplicate model implementations.'),
 ('supported','examples storage','Durable/protected consumer reuses one counter model, refuses overflow, restores state, inspects provenance, loses source acknowledgement, reopens/reclaims and verifies native worker output before later transition/saga admission. Reopen simulation and actual process-kill tests retain distinct scopes.'),
 ('supported','compatibility','Compatibility map covers API/protocol/native history and old-writer upgrade, with quiesced backup/copy validation and explicit backup-only rollback/reconciliation obligations.'),
 ('supported','portable maintenance qualification','Checkout-only architecture tests enforce layer/owner rules; all-ten clean archives and literal include checks pass at recorded revisions. The later example source is separately checked; final package identity reconciliation remains open.'),
 ('performance_review_open','performance maintenance','Maintenance/source/dependency/cost inventories and equivalent-work comparisons exist. Confirmed performance flags remain unresolved; shorter code or passing tests do not waive them.')],
'F8':[
 ('open','qualification performance','Seven source CI jobs, source/package checks and equivalent-work comparisons pass in stated scopes; full immutable-source chaos and retained performance conclusions remain open.'),
 ('open','qualification examples','All-ten clean actual0.5 archives at ce93ff8 pass both compilers with696 reported passes each. Subsequent graph example has source-consumer qualification; final release package/source and release-build reconciliation is still required.'),
 ('supported','wire compatibility','Independent machine goldens, old wire/replay fixtures,14-profile static API review and actual old-writer database upgrade supplement scoped current tests.'),
 ('open','qualification performance','Revision-scoped manifests retain commands, hashes, tools, raw runs/failures and source scopes. One final release manifest cannot be completed before chaos and performance conclusions.'),
 ('authorization_required_after_qualification','qualification','No release tag or publication is authorized or performed. Dependency-first scripts and release contract describe the separately authorized final action.')]
}
phases=[];allfiles={}
for key,paths in references.items():
 for name in paths:
  p=root/name;assert p.is_file(),name
  tracked=subprocess.check_output(['git','show','HEAD:'+name],cwd=root);assert tracked==p.read_bytes(),name
  allfiles[name]=sha(p.read_bytes())
sections=re.split(r'(?=^### F\d —)',text,flags=re.M)[1:]
for section in sections:
 block=section.split('\n### ')[0].split('\n## ')[0];heading=block.splitlines()[0][4:];phase=heading.split(' ')[0]
 bullets=[line[2:] for line in block.splitlines() if line.startswith('- ')];assert len(bullets)==len(rows[phase]),phase
 items=[]
 for i,(requirement,(status,refs,assessment)) in enumerate(zip(bullets,rows[phase]),1):
  groups=refs.split();assert set(groups)<=references.keys()
  items.append({'id':phase+'.'+str(i),'plan_line':text[:text.index('- '+requirement)].count('\n')+1,'requirement':requirement,'assessment':assessment,'status':status,'references':groups})
 gate=re.search(r'^\*\*Gate '+phase+r':\*\* (.*)$',block,re.M);assert gate
 tests=re.search(r'^\*\*Tests:\*\* (.*)$',block,re.M)
 phases.append({'phase':phase,'heading':heading,'work_items':items,'required_tests':tests.group(1) if tests else None,'gate':gate.group(1),'gate_disposition':'Final qualification remains open; work-item support is scoped evidence, not a universal behavior or downstream-compatibility proof.'})
assert len(phases)==9 and sum(len(p['work_items']) for p in phases)==50
checkpoint=json.loads((root/'docs/0.5/evidence/qualification/history-partition-checkpoint.json').read_text());assert checkpoint['coverage']['reported_source_files']==72
for name,h in checkpoint['coverage']['source_sha256'].items():assert sha((root/name).read_bytes())==h
result={'scope':'Implementation-phase Work audit: every one of50 bullets and nine phase gates in plan section11. Sections1–10,12–17 and the named test sets require their own invariant/compatibility/maintenance/release reviews; this is not the complete plan audit or release qualification. A supported work item means the cited implementation/evidence supports its stated assessment, not unrestricted proof of every possible execution.','review_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'plan_sha256':sha(plan.read_bytes()),'counts':{'phases':9,'work_items':50,'phase_gates':9,'source_and_evidence_files_verified':len(allfiles),'production_files_unchanged_from_current_package_checkpoint':72,'work_item_statuses':dict(collections.Counter(i['status'] for p in phases for i in p['work_items']))},'references':references,'reference_file_sha256':allfiles,'phases':phases,'open_audit_obligations':['Historical sequencing of complete baseline profiles and preimplementation compile fixtures is not reconstructed; later immutable-source observations are not rewritten as earlier completion.','Phase required-test paragraphs are retained verbatim, not marked complete by nearby work-item assessments. Match every named behavior to an actual current test/oracle and its passing scope.','Verify section9.2 nested-example requirements, especially runnable hook tracing, self/parent transitions and guarded failures. Existing kernel tests are not by themselves a complete public-example demonstration.','Finish remaining detailed normative clauses outside section11 and reconcile them with the existing15-invariant, seven-maintenance-criterion and12-release-condition reviews.','Complete immutable-source chaos, resolve retained performance findings, reconcile final source/harness/package identities and create dated final release evidence. No tag/publication authorization is inferred.']}
p=root/'docs/0.5/evidence/maintenance/phase-audit.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts'],indent=2))
