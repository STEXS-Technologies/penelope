import json,math
from pathlib import Path
from statistics import median
root=Path('/tmp/penelope-inherited-probe-perf');metadata=json.loads((root/'metadata.json').read_text());cases=['original','retained','rebuilt','probe'];samples={}
for c in cases:
 samples[c]=[json.loads((root/f'run-{i}-{c}.json').read_text())['observations'] for i in range(1,13)]
first=samples['original'][0];assert len(first)==640;rows=[]
for j,observation in enumerate(first):
 dims={k:observation[k] for k in ['operation','state_words','steps','samples']}
 for metric,threshold in [('p50_ns',5),('p95_ns',10),('p99_ns',None)]:
  values={}
  for c in cases:
   assert all(len(s)==640 and {k:s[j][k] for k in dims}==dims for s in samples[c]);values[c]=[s[j][metric] for s in samples[c]]
  mids={c:median(v) for c,v in values.items()};ratios={c:(mids['probe']/mids[c]-1)*100 for c in ['original','retained','rebuilt']}
  rows.append({**dims,'metric':metric,'raw':values,'medians':mids,'probe_delta_percent':ratios,'review_flag_against_original':threshold is not None and ratios['original']>threshold,'review_flag_against_retained':threshold is not None and ratios['retained']>threshold})
memory={c:[l for l in (root/f'run-1-{c}.stdout').read_text().splitlines() if l.startswith('memory,')] for c in cases};assert all(m==memory['original'] for m in memory.values())
result={'rounds':12,'measured_records':48,'warmup_records':4,'metrics':rows,'memory_rows':len(memory['original']),'memory_rows_identical':True,'flag_counts':{comparison:{metric:sum(r['metric']==metric and r['review_flag_against_'+comparison] for r in rows) for metric in ['p50_ns','p95_ns']} for comparison in ['original','retained']},'scope':'Four rotating artifact controls, same frozen640-profile workload. Descriptive findings only; no statistical equivalence or acceptance claim.'}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='metrics'},indent=2))
for r in rows:
 if r['operation'] in ['history_read_all_inherited','history_full_correction_inherited'] and r['state_words']==1 and r['metric']=='p50_ns':print({k:v for k,v in r.items() if k!='raw'})
