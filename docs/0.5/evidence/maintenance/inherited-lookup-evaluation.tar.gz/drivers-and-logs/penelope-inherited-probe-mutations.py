import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-inherited-probe');path=root/'crates/penelope-timeline/src/history.rs';original=path.read_text();out=Path('/tmp/penelope-inherited-probe-mutations');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/inherited-probe'}
start=original.index('    fn resolve_input(');end=original.index('    fn source_input(',start);body=original[start:end]
mutations=[('only-roots','if lineage.parent.is_none() || step > lineage.inherited_through {','if lineage.parent.is_none() {','ancestry_lookup','deep_state_input_and_mixed_corrections_preserve_child_appends'),('skip-override','''            if let Some(record) = lineage.input_override.filter(|record| record.step == step) {
                return self.exact_input(record);
            }
''','','ancestry_lookup','deep_state_input_and_mixed_corrections_preserve_child_appends'),('skip-payload-check','                    self.verify_input(entry)?;\n','','history_lookup','canonical_and_exact_lookups_recheck_content_and_declared_charge')]
checks=[]
try:
 for label,before,after,target,test in mutations:
  assert body.count(before)==1,(label,body.count(before));changed=original[:start]+body.replace(before,after)+original[end:];path.write_text(changed);(out/(label+'.rs')).write_text(changed)
  args=['cargo','+1.100.0','test','-p','penelope-timeline','--all-features','--locked','--test',target,test,'--','--exact'];start_time=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
  for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(label+'.'+suffix)).write_text(text)
  checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start_time,'invariant_test_failed':r.returncode==101 and 'test result: FAILED.' in r.stdout});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert checks[-1]['invariant_test_failed'],label;print(label,'caught',flush=True)
finally:
 path.write_text(original);(out/'restored-sha256.txt').write_text(hashlib.sha256(path.read_bytes()).hexdigest()+'\n')
assert path.read_text()==original
print('source restored',flush=True)
