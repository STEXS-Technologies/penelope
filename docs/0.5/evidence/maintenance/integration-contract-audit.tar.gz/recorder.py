import hashlib,json,re,subprocess,tarfile
from pathlib import Path
r=Path('/home/ac/projects/.penelope-050-candidate');dest=r/'docs/0.5/evidence/maintenance'
source='7d24718f25165e35287965ef2ee1414a76aa5951';sha=lambda b:hashlib.sha256(b).hexdigest()
plan=(r/'docs/0.5/plan.md').read_text();log=Path('/tmp/penelope-050-nested-ci-complete.log').read_text();ci=json.loads(Path('/tmp/penelope-050-nested-ci-complete.json').read_text())
assert ci['headSha']==source and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
S='crates/penelope-executor/src/saga_machine.rs';E='crates/penelope-executor/src/engine.rs';G='crates/penelope-executor/src/graph.rs';T='crates/penelope-core/src/task/projection.rs';C='crates/penelope-core/src/task/control.rs';MT='crates/penelope-executor/src/machine_task.rs';TL='crates/penelope-timeline/src/machine.rs';A='docs/0.5/architecture.md';U='docs/0.5/public-api.md';F='crates/penelope/src/lib.rs'
p='preparation_matches_frozen_record_validation_and_supervisory_decisions';t='shared_and_separate_stores_reconstruct_native_acceptance_after_lost_ack';s='linear_and_graph_bootstrap_replay_and_separate_ack_survive_reopen_in_both_layouts';v='receipt_schema_scope_input_and_tick_substitution_never_acknowledge_the_source';n='native_memory_and_timeline_agree_on_state_provenance_intents_and_failure_isolation';c='corrected_replay_uses_captured_context_and_existing_finality_and_handoff';h='scope_definition_stale_head_exhaustion_and_quota_failures_do_not_publish'
rows={
'6.1':[
('Canonical saga namespace reexports the original engines and types; no replacement evaluator.',[F,'crates/penelope/src/saga.rs'],[s]),
('Prepared linear and graph views delegate to decide/start_graph/apply_graph_result and retain native projections/events/actions. The frozen facade consumer exercises both legacy and prepared routes.',[S,'ci/saga-parity/src/main.rs'],[s]),
('Native saga types and errors remain authoritative. Frozen parity covers selected histories, including retry/compensation/refusal; it is not every possible domain workflow.',[E,G,S,'scripts/check-saga-machine-parity.sh'],[s]),
('Conditional extraction reviewed: HSM uses a bounded active parent path, whereas saga definitions validate graph-wide edges/reachability/result categories. Sharing graph validation would combine different invariants; preserve the native checks.',[E,G,'crates/penelope-core/src/machine/hierarchy.rs',A],['hierarchical_correction_reuses_native_hooks_and_stops_on_ignored_capacity_failure']),
('MAX_GRAPH_TRANSITIONS remains512; native step/visit/replay bounds are not widened by the prepared view. The adapter delegates to the existing checked engine.',[E,G,S],[s]),
('Shared inspection retains native ProcessAction; receiver admission verifies native process commits. No machine record replaces saga wire.',[S,'crates/penelope-executor/src/machine_saga.rs','crates/penelope/src/saga.rs'],[s]),
('Shared inspection/source binding and SQLite worker/receipt helpers remove duplicate plumbing with native engines retained. Final performance acceptance remains open; this item is not fully qualified.',[A,S,'crates/penelope-executor/src/machine_saga.rs'],[s])],
'6.2':[
('PreparedTask retains the exact proposed v1 record and native projection in the shared read-only view.',[T,'crates/penelope/src/task.rs'],[p]),
('apply/propose/prepare use one copied-candidate evaluator. TaskControl retains journal-first runtime issuance and poisoning; preparation itself has no runtime authority.',[T,C],[p]),
('Generation, budgets, checkpoint/effect/recovery gates remain native TaskControl/TaskProjection checks; no generic view can launch or publish task work.',[T,C,'crates/penelope-core/src/machine/view.rs'],[p,'redelivery_of_running_or_faulted_task_never_submits_a_second_intent_or_generation']),
('Pure record evaluation is shared within TaskProjection without changing v1 record identity, fixed-size state or core allocation requirements.',[T,'crates/penelope-core/src/task/contracts.rs'],[p]),
('Source-authorized typed admission verifies native task intent/input. Result-driven consumer verifies output bytes, meaning and provenance before accepting a new machine event; the integration fixtures use a trusted pure worker, not an arbitrary external payment proof.',[MT,'ci/machine-consumer/durable.rs','ci/machine-consumer/workflow.rs','scripts/run-supervised-saga-example.sh'],[v,'damaged_native_blob_never_becomes_verified_receiver_acceptance']),
('Source acknowledgement is separate from native task acceptance; shared/separate database tests reconstruct exact original admission after lost ACK. No cross-store atomicity claim.',[MT,'crates/penelope-ports/src/machine/delivery.rs'],[t,'lost_native_commit_ack_leaves_pending_source_and_reconstructs_the_original_intent'])],
'6.3':[
('MachineTimeline implements the existing RewindableComputation contract with captured input, complete state and tentative intents.',[TL],[n]),
('Adapter introduces no independent owner/history/replay/correction engine; existing LiveTimeline/prepare_live_step/ReplaySession/finality machinery owns publication.',[TL,'crates/penelope-timeline/src/live.rs','crates/penelope-timeline/src/session.rs'],[n,c]),
('Captured context is part of input identity; configuration/random/external dependencies must also be captured by the consumer. Rust cannot enforce callback purity or snapshot alias isolation.',[TL,'docs/0.5/timeline-machines.md'],['content_hash_binds_every_captured_context_role_and_application_payload']),
('Intents remain tentative and use existing independently finalized-prefix handoff. Correction across finalized history is refused by the native timeline.',[TL,'crates/penelope-timeline/src/handoff.rs'],[c]),
('Adapter pins scope and definition/schema; restored or replayed mismatches fail. New schema requires a distinct replay domain or an explicitly reviewed host transformation; no automatic migration is supplied.',[TL,'docs/0.5/timeline-machines.md'],[h]),
('Existing in-memory owned/shared timeline profiles remain separate from SQLite machine snapshots. Complete snapshots and isolation are consumer obligations.',[TL,'docs/0.5/timeline-machines.md',A],['complete_non_clone_state_uses_existing_prepare_live_step_path']),
('Machine/timeline scopes and revisions are distinct and explicitly correlated. Adapter writes no independent durable journal; host integrations must designate one authority for each record.',[TL,'docs/0.5/timeline-machines.md'],[n,'content_hash_binds_every_captured_context_role_and_application_payload'])]}
# Resolve exact existing test definitions, then require both compiler job observations.
tests={}
for f in ['crates/penelope-core/tests/prepared_task.rs','crates/penelope-executor/tests/machine_task.rs','crates/penelope-executor/tests/machine_saga.rs','crates/penelope-timeline/tests/machine.rs']:
 text=(r/f).read_text()
 for match in re.finditer(r'^fn (\w+)\(',text,re.M):tests[match[1]]={'path':f,'line':text[:match.start()].count('\n')+1}
items=[];files={};observed={}
for section,entries in rows.items():
 block=re.search(r'^### '+re.escape(section)+r' .*?\n(.*?)(?=^### |^## |\Z)',plan,re.M|re.S)[1]
 requirements=re.findall(r'^\d+\. (.+)$',block,re.M);assert len(requirements)==len(entries)
 for i,(requirement,(assessment,owners,names)) in enumerate(zip(requirements,entries),1):
  for name in names:
   ref=tests[name];owners=owners+[ref['path']]
   for job in ['Stable verification','Minimum supported Rust']:
    assert any(line.startswith(job+'\t') and 'test '+name+' ... ok' in line for line in log.splitlines()),(job,name)
   observed[name]=ref
  for owner in owners:
   data=(r/owner).read_bytes()
   # The c8fda4c guide amendment is intentionally later than this CI; qualify
   # only the earlier source through this audit, with current docs separately scoped.
   if owner==U:continue
   assert data==subprocess.check_output(['git','show',source+':'+owner],cwd=r),owner
   files[owner]=sha(data)
  items.append({'id':section+'.'+str(i),'plan_line':plan[:plan.index(requirement)].count('\n')+1,'requirement':requirement,'assessment':assessment,'status':'performance_acceptance_open' if section=='6.1' and i==7 else 'scoped_implementation_and_named_checks_supported_release_qualification_open','owners':sorted(set(owners)),'tests':names})
assert len(items)==20
external=['task_result_verified=true amount=1','result_committed=true state=257 revision=2','saga_admitted=true native_actions=1 source_acknowledged=true','Wrong task result refused before machine admission']
for expected in external:
 assert any(line.startswith('Stable verification\tRun ./scripts/run-supervised-saga-example.sh\t') and line.rstrip().endswith(expected) for line in log.splitlines()),expected
assert 'pub const MAX_GRAPH_TRANSITIONS: usize = 512;' in (r/E).read_text()
assert 'pub const MAX_GRAPH_TRANSITIONS: usize = 512;' in subprocess.check_output(['git','show','42ec187:'+E],cwd=r,text=True)
# Preserve actual CI and recorder instead of pointing to an uncommitted temp log.
archive=dest/'integration-contract-audit.tar.gz'
archive_files={'ci.json':Path('/tmp/penelope-050-nested-ci-complete.json'),'ci.log':Path('/tmp/penelope-050-nested-ci-complete.log'),'recorder.py':Path(__file__)}
members={name:sha(path.read_bytes()) for name,path in archive_files.items()}
with tarfile.open(archive,'w:gz') as tar:
 for name,path in archive_files.items():tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 for name,hsh in members.items():assert sha(tar.extractfile(name).read())==hsh
out={'source_commit':source,'scope':'All20 numbered integration work items in plan6.1/6.2/6.3, mapped individually to current native owners and observed stable/MSRV checks. Conditional extraction is assessed against actual semantic differences. Not all plan prose, full qualification or performance acceptance.','plan_sha256':sha((r/'docs/0.5/plan.md').read_bytes()),'items':items,'named_tests':observed,'source_sha256':files,'ci':{'run_id':43828997177,'all_seven_jobs_success':True,'both_compiler_observations_checked':True,'protected_progression_stable_output':external},'archive':{'file':archive.name,'sha256':sha(archive.read_bytes()),'members_sha256':members},'remaining':['Full current-production chaos, final source/package/coverage reconciliation and performance findings stay open.','Plan6.4 example/prose, detailed API/port/maintenance prose and historical sequencing are separate obligations; these20 numbered items do not close them.','Canonical evidence, trusted external worker policy, callback purity and complete snapshot ownership remain explicit host responsibilities.']}
(dest/'integration-contract-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified20 integration clauses,',len(observed),'named tests on both compilers and',len(files),'exact source files')
