import collections,gzip,hashlib,json,re
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');directory=root/'docs/0.5/evidence/maintenance';plan=root/'docs/0.5/plan.md';raw=plan.read_bytes();lines=raw.decode().splitlines();sha=lambda b:hashlib.sha256(b).hexdigest()
blocks=[];buf=[];start=0;section='preamble';kind=None;fence=False

def flush():
 global buf
 if buf:
  text='\n'.join(buf)
  blocks.append({'line':start,'end_line':start+len(buf)-1,'section':section,'kind':kind,'text':text})
  buf=[]
for no,line in enumerate(lines,1):
 if line.startswith('#') and not fence:
  flush();section=line.lstrip('# ').strip();continue
 if line.startswith('```'):
  if fence:
   buf.append(line);flush();kind=None;fence=False
  else:
   flush();fence=True;start=no;kind='code';buf=[line]
  continue
 if fence:buf.append(line);continue
 if not line.strip() or line.strip()=='---':flush();continue
 newkind='table' if line.startswith('|') else 'item' if re.match(r'^(?:- |\d+\. )',line) else 'paragraph'
 if buf and (newkind in ['table','item'] or newkind!=kind):flush()
 if not buf:start=no;kind=newkind
 buf.append(line)
flush();assert not fence
# Verify every nonblank body line belongs to exactly one block. Headings and
# horizontal rules are navigation, not omitted body text; fenced contents count.
covered=collections.Counter(n for b in blocks for n in range(b['line'],b['end_line']+1))
assert all(v==1 for v in covered.values())
for no,line in enumerate(lines,1):
 if line.strip() and not line.startswith('#') and line.strip()!='---':assert covered[no]==1,(no,line)

def normalize(text):
 text=re.sub(r'^- (?:\[ \] )?|^\d+\. ','',text)
 text=re.sub(r'^\*\*Gate F\d+:\*\*\s*','',text)
 return ' '.join(text.split())
paths=['phase-audit.json','test-layer-audit.json','core-contract-audit.json','integration-contract-audit.json','acceptance-audit.json','invariant-audit.json','../qualification/nested-ergonomics.json']
lookup=collections.defaultdict(list);evidence={}
def walk(value,path,source):
 if isinstance(value,dict):
  if isinstance(value.get('requirement'),str):
   lookup[normalize(value['requirement'])].append({'file':source,'pointer':path,'scope_status':value.get('status','see_scoped_assessment')})
  for key,item in value.items():walk(item,path+'/'+key,source)
 elif isinstance(value,list):
  for i,item in enumerate(value):walk(item,path+'/'+str(i),source)
for name in paths:
 p=directory/name;data=p.read_bytes();j=json.loads(data);evidence[name]=sha(data)
 if 'plan_sha256' in j:assert j['plan_sha256']==sha(raw),name
 walk(j,'',name)
 if name=='phase-audit.json':
  for i,phase in enumerate(j['phases']):
   lookup[normalize(phase['gate'])].append({'file':name,'pointer':'/phases/'+str(i)+'/gate_disposition','scope_status':'see_scoped_gate_disposition'})
# Preserve table invariant matches as partial row references: the original row
# also specifies owner/failure behavior, not only the invariant title.
inv=json.loads((directory/'invariant-audit.json').read_text())['invariants']
for b in blocks:
 refs=list(lookup.get(normalize(b['text']),[]))
 if b['section']=='10. Cross-cutting correctness and security contract' and b['kind']=='table':
  cells=[c.strip() for c in b['text'].split('|')[1:-1]]
  for i,item in enumerate(inv):
   if cells and normalize(cells[0])==normalize(item['requirement']):refs.append({'file':'invariant-audit.json','pointer':'/invariants/'+str(i),'scope_status':'invariant_audit_row_requires_full_owner_and_failure_review'})
 text=b.pop('text');b['sha256']=sha(text.encode());b['preview']=text[:110]
 b['evidence']=refs
 if re.fullmatch(r'\|[ :|\-]+',text):b['review_state']='table_layout'
 elif b['section'].startswith('17.'):b['review_state']='historical_source_reference'
 elif b['section'].startswith('15.') and b['kind']=='table':b['review_state']='advisory_pr_breakdown'
 elif text in ['Work:','**Work:**','Required properties:','The conceptual layers are:','Keep these dependency boundaries:','Acceptance criteria:','All these acceptance conditions must hold:','**Unit / model checks**','**Property-based / model-based**','**Fuzzing**','**Concurrency and crash**','**Compatibility**','**Portable and architecture**','**Provisional gates** (approve in F0 after real baseline measurements):','Recommended workload matrix:']:
  b['review_state']='section_label'
 else:b['review_state']='scoped_evidence_indexed' if refs else 'needs_individual_review'
# Explicit positional mapping for the seven maintenance bullets: source audit
# uses clarified wording, so do not silently pretend it was an exact text match.
maintenance=[b for b in blocks if b['section'].startswith('13.3 ') and b['kind']=='item']
criteria=json.loads((directory/'acceptance-audit.json').read_text())['criteria'];assert len(maintenance)==len(criteria)==7
for i,b in enumerate(maintenance):
 ref={'file':'acceptance-audit.json','pointer':'/criteria/'+str(i),'scope_status':'positional_seven_criterion_review_not_exact_text_match'}
 if ref not in b['evidence']:b['evidence'].append(ref)
 b['review_state']='scoped_evidence_indexed'
# Individually reviewed deployment clauses, with current CI observations and
# exact current source identities. Operational duties remain host obligations.
source='c8fda4c994cdcdda075d09648e502a0aa4fe1775'
import subprocess
ci_log=Path('/tmp/penelope-050-final-ci.log').read_text()
checkpoint=json.loads((directory/'../qualification/current-package-checkpoint.json').read_text())
assert checkpoint['source_commit']==source
log_member='drivers-and-logs/penelope-050-final-ci.log'
assert sha(ci_log.encode())==checkpoint['archive']['members_sha256'][log_member]
manual_sources=['docs/0.5/compatibility-matrix.md','docs/reliable-execution-operations.md','scripts/check-sqlite-upgrade.py','ci/sqlite-upgrade/main.rs','crates/penelope-sqlite/src/schema.rs','crates/penelope-sqlite/src/machine.rs','crates/penelope-core/src/task/control.rs','crates/penelope-core/src/task/runtime.rs','crates/penelope-executor/src/task.rs','crates/penelope-ports/src/machine/recovery.rs']
manual_hashes={}
for name in manual_sources:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',source+':'+name],cwd=root);manual_hashes[name]=sha(data)
for name in ['crates/penelope-core/src/task/control.rs','crates/penelope-core/src/task/runtime.rs','crates/penelope-executor/src/task.rs']:
 assert (root/name).read_bytes()==subprocess.check_output(['git','show','42ec187:'+name],cwd=root)
observed=['preparation_matches_frozen_record_validation_and_supervisory_decisions','sigkill_at_schema_migration_boundaries_preserves_records_blobs_and_fences','sigkill_v7_outbox_migration_preserves_populated_machine_journal','sigkill_v8_receiver_migration_preserves_pending_uncertainty_and_accepted_receipts','conflicting_genesis_scope_count_and_exact_scope_bytes_keep_existing_state','every_truncation_mutation_and_trailing_byte_fails_closed']
for job in ['Stable verification','Minimum supported Rust']:
 for expected in ['Upgrade/reopen 1: exact legacy rows, replay and integrity retained','Upgrade/reopen 2: exact legacy rows, replay and integrity retained','Actual 0.4 writer fixture: 15 legacy tables verified']:
  assert any(line.startswith(job+'\tRun python3 scripts/check-sqlite-upgrade.py\t') and line.endswith(expected) for line in ci_log.splitlines()),(job,expected)
 for name in observed:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(name)+r' \.\.\. ok(?:\s|$)',line) for line in ci_log.splitlines()),(job,name)
reviews={
861:'No history conversion is required. The actual0.4-writer fixture preserves all15 legacy table schemas, rows and exact native replay across upgrade and two reopens on both compilers. This bounded fixture is not every deployment.',
862:'Canonical saga/task inspection delegates to the native replay/validation paths; frozen compatibility observations and the old-writer upgrade check retain old record interpretation. No fake machine history is persisted for legacy records.',
863:'Forward-only transactional schema6-to9 upgrade preserves legacy tables. Both compilers observe schema-migration SIGKILL tests, plus populated v7/v8 machine migration recovery. These are process-death cases, not hardware power-loss certification.',
864:'TaskControl, portable runtime contracts and hosted supervisor source are byte-identical to original42ec187. Machine-generated native admission requires explicit use of the new receiver. The prepared-task differential test also passes on both compilers.',
865:'New machine scope pins the definition/schema; mismatched genesis or scope is refused, and replay requires the pinned model/codec. No automatic state/history migration service exists: authenticated transformation and executable availability remain explicit host obligations before changing interpretation.',
866:'Machine wire has an independent tag and tables. Strict mutation decoding refuses unsupported bytes; the retained old-binary upgrade/rollback experiment refuses schema9 without changing it. The deployment guide forbids mixed adapters and requires quiesced rollout. No capability negotiation service is promised.',
867:'Compatibility and operations guides require a quiesced schema6 backup, pinned old deployment, isolated validation and separate restore. They explicitly refuse automatic downgrade or manual user_version changes; external work requires reconciliation. This is a documented operating procedure, not proof that a production operator performed it.'}
assert set(reviews)=={861,862,863,864,865,866,867}
# The earlier old-binary refusal/restore experiment remains independently scoped.
rollback_path=directory/'../sqlite-upgrade/manifest.json';rollback=json.loads(rollback_path.read_text());evidence['../sqlite-upgrade/manifest.json']=sha(rollback_path.read_bytes())
for row in rollback['checks']:
 path=rollback_path.parent/row['log'];data=path.read_bytes();assert sha(data)==row['gzip_sha256'];assert sha(gzip.decompress(data))==row['raw_sha256']
assert any('Original baseline sqlite-upgrade read/refuse' in row['command'] and row['exit_code']==0 for row in rollback['checks'])
evidence['../qualification/current-package-checkpoint.json']=sha((directory/'../qualification/current-package-checkpoint.json').read_bytes())
for b in blocks:
 if b['line'] in reviews:
  assert b['section'].startswith('12.2 ') and b['kind']=='item'
  b['assessment']=reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/current-package-checkpoint.json','pointer':'/ci','scope_status':'current_ci_observations_checked'},{'file':'../sqlite-upgrade/manifest.json','pointer':'/rollback_steps','scope_status':'original_binary_refusal_and_separate_restore_experiment'}]
assert sum(b['review_state']=='individually_reviewed_scoped_support' for b in blocks)==7
# A later local ergonomic example is scoped separately from the c8 deployment review.
door_path=directory/'../qualification/door-ergonomics.json'
door=json.loads(door_path.read_text())
for name,digest in door['source_sha256'].items():assert sha((root/name).read_bytes())==digest
assert all(c['exit_code']==0 for c in door['checks'])
assert len(door['negative_controls'])==4 and all(c['compiled_and_rejected_by_runtime_oracle'] for c in door['negative_controls'])
evidence['../qualification/door-ergonomics.json']=sha(door_path.read_bytes())
door_package=directory/'../qualification/door-package-checkpoint.json'
evidence['../qualification/door-package-checkpoint.json']=sha(door_package.read_bytes())
for b in blocks:
 if b['section'].startswith('9.1 '):
  b['evidence'].append({'file':'../qualification/door-ergonomics.json','pointer':'/scope','scope_status':'local_example_followup_separately_reconciled_at_c0e9997'})
  b['evidence'].append({'file':'../qualification/door-package-checkpoint.json','pointer':'/ci','scope_status':'all_ten_archives_and_seven_CI_jobs_at_c0e9997'})
  b['assessment']='The runnable door example uses the actual API and covers enum-local data, accepted edges, guard refusals and unhandled decisions. It retains explicit local fixture metadata and stages no effects. The separate counter/durable examples cover effects; this link does not certify every clause in this block. The separate c0e9997 checkpoint qualifies all ten archives and source CI; later signature changes retain a separate scope.'
# Individually reviewed API/storage/guarantee/ADR content. These are scoped
# assessments, not an assertion that historical sequencing or release gates pass.
followup_source='8dfe89d343f498d58b2e752980b43fa99e20c00d'
followup_paths=['docs/0.5/public-api.md','docs/0.5/architecture.md','docs/0.5/compatibility-matrix.md','docs/0.5/machine.md','docs/0.5/machine-wire.md','docs/0.5/machine-storage.md','docs/0.5/machine-preparation.md','crates/penelope/src/lib.rs','crates/penelope/src/storage.rs','crates/penelope/src/runtime.rs','crates/penelope/src/integration.rs','crates/penelope/src/diagnostics.rs','crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/src/machine/wire.rs','crates/penelope-ports/src/machine.rs','crates/penelope-ports/src/machine/store.rs','crates/penelope-ports/src/machine/recovery.rs','crates/penelope-ports/src/machine/delivery.rs','crates/penelope-sqlite/src/machine.rs','crates/penelope-sqlite/src/machine/read.rs','crates/penelope-sqlite/src/machine/delivery.rs','crates/penelope-sqlite/src/schema.rs','crates/penelope-sqlite/src/worker.rs']
followup_hashes={}
for name in followup_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);followup_hashes[name]=sha(data)
# Exhaustive legacy authorization operations remain the original enum.
authority='crates/penelope-ports/src/implementation.rs'
enum=lambda data:data.split('pub enum ProcessAuthorizationOperation',1)[1].split('\n}\n',1)[0]
assert enum((root/authority).read_text())==enum(subprocess.check_output(['git','show','42ec187:'+authority],cwd=root,text=True))
door_checkpoint=directory/'../qualification/door-package-checkpoint.json'
door_ci=json.loads(Path('/tmp/penelope-050-door-ci.json').read_text());door_log=Path('/tmp/penelope-050-door-ci.log').read_text()
door_record=json.loads(door_checkpoint.read_text())
assert door_ci['headSha']==door_record['source_commit']=='c0e99972a7103ea349f78178446b7e19fb0b6ff9'
assert sha(door_log.encode())==door_record['archive']['members_sha256']['drivers-and-logs/penelope-050-door-ci.log']
followup_tests=['codec_reference_rejects_wrong_type_trailing_bytes_and_preserves_non_clone_values','every_byte_limit_and_input_digest_is_enforced_before_local_publication','event_replay_reconstructs_every_prefix_without_pending_effects_and_can_resume_from_snapshot','event_replay_refuses_wrong_predecessor_model_codec_limits_and_duplicate_revision','event_replay_refuses_validly_rechecksummed_transition_and_event_substitutions','snapshot_restore_refuses_scope_codec_lossy_decoding_and_model_invariant_substitution','authorization_precedes_existence_duplicates_and_all_reads','lost_ack_reopen_exact_duplicate_and_pending_payload_recovery','simultaneous_independent_workers_admit_one_competing_head','concurrent_reader_sees_one_coherent_state_head_receipt_tuple','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap','claim_is_source_bound_and_reopen_preserves_uncertainty_and_fencing','policy_denies_claim_read_validation_and_duplicate_ack_before_receipt_lookup']
for job in ['Stable verification','Minimum supported Rust']:
 for name in followup_tests:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(name)+r' \.\.\. ok(?:\s|$)',line) for line in door_log.splitlines()),(job,name)
for path in ['../qualification/door-package-checkpoint.json','../qualification/graph-start-ownership.json','../qualification/event-replay-fuzz-complete.json','../maintenance/integration-contract-audit.json','../maintenance/invariant-audit.json','../machine-performance/state-cost.json']:
 evidence[path]=sha((directory/path).read_bytes())
content_reviews={
299:'Navigation label for the following canonical namespace diagram; actual facade exports are reviewed with that diagram.',
301:'All eight canonical namespaces exist in the facade. Timeline is feature-gated; integration::statechronicle is the retained typed evidence bridge. Internal packages remain deployment/dependency boundaries rather than separate competing public lifecycle APIs.',
312:'Facade root saga exports, executor alias, task, ports, statechronicle and optional timeline remain. The compatibility matrix provides the requested old-to-canonical import table. Frozen consumer/export checks retain their original scope; the approved Rust1.89 change is explicit.',
316:'Local usage label; the following sketch is explicitly pseudocode, not a literal signature.',
318:'The sketch is implemented by MemoryMachine::new/handle with explicit scope/context/limits and borrowed events. Accepted publication is coherent; rejected/unhandled outcomes preserve the owner. Canonical tutorial and exact packaged examples use the actual signatures.',
324:'Durable usage label; the following sketch is explicitly pseudocode, not a literal signature.',
326:'The actual lifecycle is load_head plus prepare_machine_commit, MachineStore::commit and consuming PreparedMachineCommit::publish after exact receipt checks. Pending unknown ACKs resolve by authoritative lookup/retry; authentication of receipt source remains a host duty.',
334:'Private borrow-bound prepared handles consume on publish or abort on drop. Low-level preparation, batch access, receipt verification and storage ports remain public and separately exercised. No extra high-level durable convenience method is required by this paragraph.',
338:'Diagnostic-view introduction; the following field list is reviewed as stage-specific evidence rather than one universal execution record.',
340:'PreparedDecision retains native before/candidate/provenance/intents; machine records carry scope, exact predecessor/next revision, event digest, transition and causation. Runtime paths derive from typed state. Commit disposition, outbox admission and native verified outcomes are inspected at their separate authoritative stages, as mapped in public-api.md. Proposed views alone never assert commitment or success.',
352:'There is no synthetic universal StateChanged history. Native legacy projections/events remain typed, with missing legacy fields explicitly absent. Local refusal leaves the head unchanged; the nested example logs source/event/reason outside evaluation. A separate bounded refusal-audit service is optional and is not implemented or promised.',
425:'Machine wire uses its own literal penelope.machine.v1 tag and decoder; saga/task/timeline protocols remain independent.',
427:'The proposed field inventory is finalized by the following actual metadata mapping; it is a contract sketch rather than a demand for identically named Rust fields.',
429:'MachineCommitHeader/Record bind complete tenant/instance/definition+schemas, expected/next revisions, event identity/type/digest, prior/next state digests, transition, optional causation and ordered intent metadata. Final SHA256 binds every preceding encoded byte. Exact event/state/intent payloads are retained separately in the same accepted batch; metadata alone cannot authenticate them.',
445:'Prepared batches retain exact event bytes, and stored decoding checks all payload hashes/counts/charges before owned copies. History is explicitly count/byte bounded and contiguous. Traits/docs identify canonical codecs and authentic storage as consumer/host obligations; a rewritten payload plus checksum is not treated as authenticated evidence.',
449:'The atomicity introduction is implemented by the store transaction and read-only preflight with mandatory transactional revalidation. The ten numbered obligations retain their separate core/invariant audits.',
464:'The new ports live in machine.rs with narrow store/recovery/delivery/task submodules. This split preserves the requested namespace without requiring one oversized file.',
466:'MachineStore exposes bootstrap, commit, load_head, exact event lookup and bounded history. Stored commits/receipts verify structural coordinates; source authentication and authorization remain explicit, not properties of a DTO constructor.',
467:'MachineCodec separates bounded application canonical state/event/effect encoding and decoding from core. It pins a full definition and typed event code and imposes no Clone/Serde bound. Implementations must refuse noncanonical/unknown schemas; generic code cannot enforce arbitrary application purity or a decoder predicate.',
468:'MachineIntentOutbox bounds claim/read/validate/ack operations and binds scope, source, receiver policy and fenced lease metadata. Native acceptors own execution/reconciliation; acknowledgement means admission, not external completion. Shared DatabaseWorker is reused; domain-specific leases are intentionally retained.',
469:'MachineAuthorizer has host-owned associated context and domain-specific operations, checked before reads/duplicate existence. A caller-supplied scope/digest never authenticates itself. Native receiver policies keep their separate authority.',
471:'The original ProcessAuthorizationOperation enum is text-identical to42ec187; machine operations use a new enum. Frozen task/timeline and saga observations preserve original protocol interpretation, within their bounded corpus scopes.',
475:'SQLite machine implementation and forward-only schema migrations exist at the target paths. Schema7 journal,8 delivery and9 receiver pinning preserve old tables; migration and old-writer reopen evidence remain independently scoped.',
477:'Suggested logical table introduction; the plan permits finalized names and layout, so separate payload/snapshot tables are not mandatory.',
479:'machine_heads retains genesis/current coherent snapshot, machine_events retains exact records/event/state payloads, machine_intents retains ordered payloads and machine_intent_delivery retains delivery/receiver state. Payloads and snapshots are inline with their authoritative rows rather than duplicate digest tables. All accepted fields share one local transaction.',
487:'The real bounded DatabaseWorker and WAL/FULL open path are shared with existing stores, along with bounded column reads, error mapping and single-row write checks. Machine query/receipt semantics stay domain-specific; no whole saga SQL engine is copied or universal transaction protocol introduced.',
489:'Async port methods authorize then enqueue bounded blocking work; synchronous open/migration is explicitly documented outside latency-sensitive reactors. Competing-head, coherent-reader, lost-ACK/reopen and migration-kill tests are retained. Optional SQLite does not enter the portable core dependency graph.',
493:'Both persistence profiles are documented in machine-storage.md and use distinct restore/replay entry points; delivery recovery remains separate.',
495:'StoredCommit::replay consumes an isolated owner, decodes the original event, reuses normal preparation and compares the complete regenerated record and every payload before returning it. Pending intents are discarded. Original model/codec, trusted genesis/history and deterministic pure callbacks are required; final full-source campaign qualification is still open.',
496:'MachineSnapshot/StoredCommit restoration verifies exact scope/head, schema/definition, canonical re-encoding and model invariants. SQLite head reads use coherent snapshots and validate the indexed last event/receipt/state. There is no automatic retention/eviction that deletes event deduplication evidence, or implicit migration to a changed definition.',
498:'Documentation refuses durable timeline correction claims and separates unknown external-effect reconciliation from replay/snapshot restoration. Host deployments must retain executable/model versions and refuse unavailable interpretation; the library supplies no automatic executable registry or migration service.',
502:'The integration facade retains independently verified canonical event/commit correlation. A local machine receipt is local history evidence only. Cross-store outbox/source acknowledgements are separate recoverable transactions; pinned signed-source conformance retains its own upstream revision and does not establish a new universal authority.',
633:'public-api.md documents the required three tiers together with the limits of each.',
635:'The compile-time tier covers associated types, enum-local data, exhaustive application matches and consuming borrowed handles. No general typestate workflow API is supplied or required; dynamic domain legality is not claimed unrepresentable.',
636:'The runtime tier documents guards/invariants, terminal refusal versus bubbling, one selected transition, explicit HSM order and bounded staging/path depth. Arbitrary callback runtime and determinism remain consumer duties; capacity is not a CPU bound.',
637:'The durable tier explicitly requires configured journal authority, exact event/revision/receipt verification, replay without dispatch and native outbox/admission/reconciliation. Local publication does not inherit these guarantees.',
639:'The public API guide explicitly refuses universal invalid-transition unrepresentability and identifies hidden I/O, mutable aliases, nondeterminism and incorrect predicates as consumer hazards.',
1026:'ADR05001 records reference-based input and owned candidates without Clone. Large-state representation remains application-owned; retained state-cost profiles separately measure8B through64KiB copying and owner work. These are bounded workload observations, not a large-state latency promise. Historical pre-migration sequencing remains unproven.',
1027:'ADR05002 defines a bounded single active path, stable model IDs, leaf-to-parent Unhandled fallback, terminal refusal and exact external/internal hook order. Parent selection does not change the exit domain; orthogonal regions and implicit completion loops are unsupported. Historical sequencing remains unproven.',
1028:'ADR05003 records private consuming borrow-bound preparation, exact head/scope/event/intents, coherent publication before destructor cleanup and no live mutable accessor. Durable publication requires independently authenticated exact receipts. Historical sequencing remains unproven.',
1029:'ADR05004 plus machine-wire.md specify independent protocol tag/layout, model/schema identities, event/state/intent digest binding and complete batch receipts. Golden fixtures are independent of Rust encoding. Historical sequencing remains unproven.',
1030:'ADR05005 and storage guide specify accepted history authority, coherent head snapshots, local atomicity, immutable event/state/intent retention, isolated event replay and snapshot restore. External effect authority remains native. Historical sequencing remains unproven.',
1031:'ADR05006 lists concrete shared helpers/owners and intentionally separate saga correlation, task generations, timeline finality and domain transactions. Inventory documents source growth and limited clone scope; it does not claim universal deduplication. Historical sequencing remains unproven.',
1032:'ADR05007 records host context and machine-specific authorization operations, denial before scoped existence/duplicate reads and preserved legacy enum semantics. It does not authenticate pure reducers or arbitrary caller assertions. Historical sequencing remains unproven.',
1033:'ADR05008 retains facade defaults, optional timeline/SQLite/runtime composition and allocation-free/no_std qualification at core. There is no mandatory macro. Feature/dependency and portable checks remain independent gates. Historical sequencing remains unproven.',
1034:'ADR05009 requires pinned interpretation, explicit authenticated migration when changing it and separately restored old backups for rollback. No automatic downgrade or unsupported schema reinterpretation is offered. Historical sequencing remains unproven.',
1035:'ADR05010 records same-work baseline, variance-informed tolerances, retained unsuccessful/raw evidence and explicit review of sustained findings. This policy does not mean performance acceptance is achieved; flagged workloads remain release blockers. Historical sequencing remains unproven.'}
assert len(content_reviews)==47,len(content_reviews)
for b in blocks:
 if b['line'] in content_reviews:
  b['assessment']=content_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/door-package-checkpoint.json','pointer':'/ci','scope_status':'c0_source_tests_observed_unchanged_storage_and_core_owners'},{'file':'../qualification/graph-start-ownership.json','pointer':'/production_change','scope_status':'later_graph_signature_change_separately_scoped'}]
 if b['line']==1024:
  b['assessment']='The ADR content exists and is individually reviewed below, but the strict before-code-migration temporal requirement is not proven by present-day documents. It cannot be retroactively certified.'
  b['review_state']='historical_sequence_unproven'
assert sum(b['line'] in content_reviews for b in blocks)==len(content_reviews)
# Commit topology proves a narrower temporal statement than the literal clause.
initial_adr=subprocess.check_output(['git','rev-parse','6555ce2'],cwd=root,text=True).strip()
kernel_start=subprocess.check_output(['git','rev-parse','cce1217'],cwd=root,text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor',initial_adr,kernel_start],cwd=root,check=True)
initial_text=subprocess.check_output(['git','show',initial_adr+':docs/0.5/architecture.md'],cwd=root)
initial_changes=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',initial_adr],cwd=root,text=True).splitlines()
assert 'docs/0.5/architecture.md' in initial_changes and 'crates/penelope/src/lib.rs' in initial_changes
chronology={'initial_adr_commit':initial_adr,'initial_adr_sha256':sha(initial_text),'first_kernel_commit':kernel_start,'adr_commit_precedes_kernel':True,'same_commit_changes_facade':True,'limit':'ADRs existed before the new kernel, wire and SQLite implementation, but the first ADR commit also changes facade code. Commit topology does not establish authoring order within it or satisfy the strict before-any-code-migration clause.'}
for b in blocks:
 if b['line']==1024:
  b['assessment']+=' The initial ADR commit6555ce2 precedes kernel commitcce1217, but also modifies the facade; commit topology cannot prove within-commit authoring order.'

# File-map review records actual owners and deliberate path refinements instead
# of inventing files just to mirror the proposal's draft filenames.
refactor_paths=['crates/penelope-core/src/lib.rs','crates/penelope-core/src/__private.rs','crates/penelope-core/src/task/projection.rs','crates/penelope-executor/src/lib.rs','crates/penelope-executor/src/machine_task.rs','crates/penelope-executor/src/machine_saga.rs','crates/penelope-executor/src/saga_machine.rs','crates/penelope-timeline/src/machine.rs','crates/penelope-timeline/src/effects.rs','crates/penelope-sqlite/src/async_tasks.rs','ci/compat-0.4/tests/architecture.rs','scripts/check-layer-boundaries.sh','scripts/publish-order.py','crates/penelope/Cargo.toml','Cargo.toml','Cargo.lock','README.md','docs/RELEASE.md','CHANGELOG.md']
refactor_hashes={}
for name in refactor_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);refactor_hashes[name]=sha(data)
refactor_reviews={
507:'The section is a proposed responsibility/file map. Refined module names are identified below rather than asserted to exist under the sketch names.',
509:'Table header; the following rows map actual owners and retained protocol boundaries.',
511:'Portable core exports machine as a module. Kernel ownership stays in penelope-core, without a new published machine package.',
512:'TaskProjection preparation shares its private record evaluator and PreparedDecision view. TaskControl/runtime and hosted supervisor remain their native recovery owners; no task-wire rewrite or generic Machine publication is introduced.',
513:'Machine/timeline codecs reuse bounded byte cursors. Timeline branch/revision/finality, record decoding and recovery semantics retain their own owners. Other identity/model validation is shared only where actual semantics match.',
514:'The finalized modules are contracts.rs, memory.rs, identities.rs, hierarchy.rs, view.rs and wire.rs. memory replaces draft decision/projection filenames; identities replaces identity. These are implementation-layout refinements, not missing additional evaluators.',
515:'Legacy saga DTOs/identifiers and wire stay in domain. The new machine types are in core. Thin shared effect-key encoding forwards preserve typed domain APIs; compatibility corpus/export evidence retain their scopes.',
516:'Linear engine remains authoritative. saga_machine prepares and exposes its native decisions through the facade; legacy functions and root reexports remain.',
517:'Graph validation/result/replay stay native. Its reachability and outcome-category semantics do not match bounded active-parent-path HSM validation, so no forced generic graph validator is extracted. Conditional shared extraction is not a requirement to merge unlike checks.',
518:'Hosted task supervisor retains native journal/generation/poison semantics. Typed machine-to-task admission is implemented in machine_task.rs, not mixed into task.rs; it does not bypass journal-first launch or effect reconciliation.',
519:'The proposed executor/machine.rs umbrella was not created. Local owner/publication is in portable core; canonical durable preparation is backend-neutral in ports::machine; hosted native composition lives in executor::{machine_task,machine_saga}. The facade composes these owners. An extra forwarding module/interpreter would duplicate the canonical surface without owning a distinct protocol. This is an explicit implementation-path refinement, not a claim that the proposed file exists.',
520:'Original process ports and legacy exhaustive authorization operations retain their definitions and facade reexports. Machine-specific types/operations are separate; shared receipt proof is private and native.',
521:'Machine codec/preparation, store/history/recovery, authorization, delivery and native task contracts are implemented under ports::machine and narrow submodules.',
522:'DatabaseWorker<State> is shared by process, machine and async task adapters. Native task journal still owns its connection/cache/SQL; WAL/FULL, bounded column reads, quotas and transactional write checks are reused without replacing native record interpretation.',
523:'SQLite machine.rs plus read/delivery submodules implement journal, atomic CAS, exact lookup/history, snapshots and fenced outbox. It is a local single-host adapter; full release qualification is still open.',
524:'timeline::MachineTimeline adapts the Machine model to the existing RewindableComputation path. Existing live/session/step/effect/handoff engines own correction and finality; there is no parallel machine rewind evaluator.',
525:'Facade supplies all canonical namespaces and compatibility imports. Independent consumers compile exact public examples through the facade; internal modules remain implementation/deployment boundaries.',
526:'Facade retains default=[] and only the optional timeline feature. SQLite/protected worker composition is separately selected. The facade is hosted; no_std/no-alloc support belongs to the portable core/timeline profiles.',
527:'All ten library versions are candidate0.5; patched dependencies and MSRV1.89 are explicit approved changes. Locked package/feature checks retain exact external identities. Versioning is not evidence of release qualification or publication.',
528:'The exact allowlisted dependency guard remains; separate checks keep SQLite/conformance dependencies dev-only where required. CI runs it along with architecture/feature/portable checks. The allowed topology is not replaced with a broad wildcard.',
529:'Publish order is derived from cargo metadata with deterministic dependency-first ordering, including verification dependencies and excluding unpublished members. No second manually maintained release sequence is added.',
530:'README is short with executable branch setup and one canonical tutorial; RELEASE preserves commands and history remains in CHANGELOG. The0.5 entry is intentionally Unreleased while campaigns/performance/final audit remain open. Final dated release notes are not yet achieved.',
532:'Ten publishable library packages remain. No penelope-machine or mandatory macro package is added; pure core machines require neither SQL nor macro expansion.',
536:'The extraction acceptance introduction applies to the concrete owners reviewed in the following six clauses; it is not a blanket equivalence claim.',
538:'Bounded intent admission has machine and timeline callers; wire cursors have two protocol callers; DatabaseWorker serves process/machine/native task adapters; source binding serves task and saga receivers. Each extraction has real current callers.',
539:'These helpers centralize admission/cursor/worker/receipt/source-binding semantics, not only callback-shaped matches. The maintenance inventory separately records unchanged thin forwarders and rejects an overall production-LOC reduction claim.',
540:'Native supervisors, effect reconciliation, finality and receipt authority remain with their original owners. Shared inspection supplies no admission capability. Model/codec purity and host authentication were already explicit application boundaries, not checks silently removed by a shared trait.',
541:'Frozen task/timeline/saga observations and wire goldens retain original meaning, errors and bounded interpretation. New machine wire is independent. This is bounded differential evidence, not every possible history.',
542:'Core machine/HSM/staging paths remain generic and inline without mandatory boxes or allocation. Allocation probes cover configured non-Clone enum paths. Hosted existing worker/async trait boundaries retain their distinct costs; aggregate performance acceptance remains open.',
543:'Exact dependency allowlist and repository architecture checks remain executed CI gates. Any direct back-edge or moved production adapter dependency violates that declared graph; declaration-only and explicit newtype-fuzz inventory tests remain separate checks.',
545:'The common PreparedDecision interface only inspects native before/candidate/provenance/intents. Task record phases and timeline speculative revisions remain different typed protocols; there is no generic publication operation.',
549:'Canonical public names teach machine handle/prepare/publish, saga, task, storage and integration. No string-named transition table, mandatory scheduler or builder macro is introduced. Native legacy engine/graph APIs remain compatibility paths.',
551:'The two-category API label is implemented by the following canonical and retained-legacy policy; it does not imply identical execution engines.',
553:'Canonical modules have trait-based runnable facade examples and explicit guarantee boundaries. New convenience does not manufacture authorized receipts or hide external-effect uncertainty.',
554:'Legacy facade/root/executor/ports/statechronicle paths remain, with an old-to-canonical migration table. No breaking rename is used as evidence of consolidation.',
556:'No new legacy deprecation is introduced by this refactor. Native alternatives retain their original decision/wire/recovery semantics; future deprecation requires an explicit compatibility policy, not this performance work.'}
assert len(refactor_reviews)==36,len(refactor_reviews)
for b in blocks:
 if b['line'] in refactor_reviews:
  b['assessment']=refactor_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'acceptance-audit.json','pointer':'/criteria','scope_status':'shared_owner_and_retained_boundary_review_with_recorded_revision_scope'},{'file':'../qualification/graph-start-ownership.json','pointer':'/production_change','scope_status':'later_ownership_signature_simplification_separately_qualified'}]
  if b['line']==519:b['review_state']='implementation_path_refinement_reviewed'
  if b['line']==530:b['review_state']='individually_reviewed_release_notes_open'
assert sum(b['line'] in refactor_reviews for b in blocks)==len(refactor_reviews)
# Adoption is explicit opt-in, not a second migration engine. This review binds
# the already documented steps and host duties without claiming a live rollout.
adoption_paths=['docs/0.5/compatibility-matrix.md','docs/reliable-execution-operations.md','docs/getting-started.md','docs/0.5/public-api.md','docs/0.5/machine-storage.md','ci/machine-consumer/durable.rs','scripts/run-supervised-saga-example.sh']
adoption_hashes={}
for name in adoption_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);adoption_hashes[name]=sha(data)
adoption_reviews={
871:'The compatibility guide retains old imports and original history decoders without machine conversion. Frozen external consumers, task/timeline and saga corpora, plus the actual old-writer upgrade fixture supply bounded support; they do not certify arbitrary downstream applications.',
872:'The old-to-canonical import table and public API map expose the same native saga/task implementations and shared read-only PreparedDecision inspection. Native publication and runtime authority are preserved; changing imports does not substitute one universal evaluator.',
873:'The first-machine tutorial introduces one isolated Counter domain with a pure transition, checked arithmetic and in-memory publication. Flat and nested examples add guards and domain-local enum data. Callback purity and absence of mutable aliases remain application duties; the library cannot automatically prove arbitrary user code pure.',
874:'The journal guide explicitly requires a pinned scope/model/codec, bounded payload/history/storage quotas and host-owned MachineAuthorizer context. Persistence and outbound intents are optional adoption steps; no default allow-all policy or inferred authenticated caller is promised.',
875:'The public API and journal guide distinguish typed native task/saga receiver admission from verified execution results. The separately protected Linux consumer exercises machine-to-task-to-verified-result-to-machine-to-saga on both compilers in current CI; the plain durable consumer demonstrates admission without certifying task completion. Timeline stays opt-in and delegates bounded speculation/correction to its native engine; final performance and full chaos acceptance remain open.',
876:'No automatic conversion of arbitrary imperative state is offered. The model owns transition validation and invariants; callers explicitly choose identities, schema, canonical bytes and migration/recovery policy. Existing adapters expose native evidence without persisting fake machine histories.',
880:'The upgrade/restore procedures require a consistent prior database and matching deployment/registry, quiesced authority, isolated replay/integrity checks and external-effect reconciliation before dispatch. An old binary refuses the new schema. Restoring an older backup cannot erase later external effects or establish exclusive authority; forward reconciliation or explicit domain compensation remains a host operation, not an automated rollback guarantee.'}
assert len(adoption_reviews)==7
for b in blocks:
 if b['line'] in adoption_reviews:
  b['assessment']=adoption_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/graph-start-package-checkpoint.json','pointer':'/','scope_status':'current_all_ten_archive_consumer_and_compatibility_checks_with_host_duties_separate'}]
assert sum(b['line'] in adoption_reviews for b in blocks)==len(adoption_reviews)
adoption_ci=Path('/tmp/penelope-050-graph-start-ci.log').read_bytes()
adoption_record=json.loads((directory/'../qualification/graph-start-package-checkpoint.json').read_text())
assert sha(adoption_ci) in adoption_record['archive']['members_sha256'].values()
for job in ['Stable verification','Minimum supported Rust']:
 for expected in ['task_result_verified=true amount=1','result_committed=true state=257 revision=2','saga_admitted=true native_actions=1 source_acknowledged=true','Wrong task result refused before machine admission']:
  assert any(line.startswith(job+'\tRun ./scripts/run-supervised-saga-example.sh\t') and line.endswith(expected) for line in adoption_ci.decode().splitlines()),(job,expected)
adoption_checkpoint=directory/'../qualification/graph-start-package-checkpoint.json'
evidence['../qualification/graph-start-package-checkpoint.json']=sha(adoption_checkpoint.read_bytes())
# Compatibility matrix: preserve each protocol's actual validation scope.
compatibility_paths=['crates/penelope/Cargo.toml','crates/penelope/src/lib.rs','ci/compat-0.4/README.md','ci/compat-0.4/src/lib.rs','ci/compat-0.4/src/protocols.rs','ci/compat-0.4/baseline/manifest.json','ci/saga-parity/README.md','ci/saga-parity/src/main.rs','ci/saga-parity/baseline/manifest.json','scripts/check-saga-machine-parity.sh','docs/0.5/architecture.md']
compatibility_hashes={}
for name in compatibility_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);compatibility_hashes[name]=sha(data)
compatibility_tests=['independent_goldens_bind_endianness_causation_order_and_full_width_counters','independently_assembled_v1_golden_records_are_canonical','checkpoint_restoration_preserves_authority_finality_and_consumed_branch_ids','delayed_dispatch_cannot_revive_a_generation_fenced_by_reconstruction','checkpoint_upgrade_requires_explicit_application_authorized_import','ignored_process_commit_writes_cannot_return_partial_success']
for job in ['Stable verification','Minimum supported Rust']:
 for name in compatibility_tests:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(name)+r' \.\.\. ok(?:\s|$)',line) for line in adoption_ci.decode().splitlines()),(job,name)
 for expected in ['Task/timeline parity passed: 33278 frozen observations match 0.4','Saga parity passed: 3136 observations match 0.4 through both facade paths']:
  assert any(line.startswith(job+'\t') and line.endswith(expected) for line in adoption_ci.decode().splitlines()),(job,expected)
compatibility_reviews={
843:'The unchanged external import fixture and frozen linear saga observations pass through both legacy and canonical prepared facade paths on stable/MSRV. Existing exports remain aliases/reexports of the native contracts; the new graph-start lifetime relaxation is separately qualified.',
844:'The graph adapter delegates to the native engine. The frozen corpus covers196 deterministic linear/graph histories,3136 observations and successful-prefix replay; native graph definition/action/scope tests remain. The plan wording exhaustive graph parity is bounded by these finite input models, not a claim that all possible graphs and downstream programs are enumerated.',
845:'Legacy process wire/outcome interpretation remains independent of machine wire. Both saga facade paths reproduce exact original bytes, errors and replay observations. This is bounded cross-version compatibility evidence, not equivalence for every hypothetical serialized input.',
846:'The frozen33278-observation task/timeline corpus checks original history bytes, selected exhaustive enum matches, recovery policies and checkpoint restoration. Current tests separately reject unauthorized checkpoint migration and substitution. New machine schemas do not reinterpret task v1.',
847:'TaskControl and native supervisor authorities remain at their original source owners. Stable/MSRV observe delayed-dispatch generation-fencing and checkpoint-authorized-import tests; process-death and model evidence retains its separate scope. New machine admission does not supersede fencing or certify remote exactly-once effects.',
848:'Timeline metadata keeps its independent v1 decoder and finality/frontier rules. Original task/timeline observations remain frozen, and independently assembled golden records plus checkpoint/finality restoration checks pass on both compilers. Machine adaptation does not reuse the timeline protocol tag for durable machine commits.',
849:'LiveTimeline remains the native implementation, reexported only when the facade timeline feature is selected. The optional adapter delegates correction/replay to that engine. External consumers and current CI cover both feature selections; timeline performance findings remain open.',
850:'AtomicProcessCommit remains a saga-specific exported storage contract. Existing process conformance and suppressed-write checks remain current tests; machine commit/receipt types are independent. Shared SQLite helpers do not merge process authority with machine publication.',
851:'The actual0.4-writer fixture preserves15 legacy tables and native replay through schema6-to9 plus two reopens. Transactional migration/process-kill checks and old-binary refusal retain their scope; no automatic downgrade or every-real-database claim is made.',
852:'Machine metadata has its own penelope.machine.v1 tag, strict decoder and independently assembled full-width/endianness/causation goldens. Mutation/truncation checks and bounded fuzz are separate evidence. The final full-source three-round campaign is still required before release.',
853:'The StateChronicle integration retains independently verified canonical evidence and exact commit correlation. Current CI succeeds against pinned upstreamae3d94bc with seven selected signed-source tests. This does not transfer upstream authority to local hashes or certify unpinned future upstream revisions.',
854:'Facade default features are empty; timeline is the only declared optional facade feature. Core machine exports are available without timeline, runtime or SQLite dependencies. Existing hosted facade dependencies mean this is not a promise that the entire umbrella crate is no_std; portable core remains a separately checked profile.',
855:'The optional process runtime retains the supported Linux x86-64 isolation/fencing profile. Current supervised worker progression passes on stable/MSRV with verified task output and wrong-result refusal. No portability to other host profiles, distributed fencing or arbitrary process-level memory bound is inferred.',
857:'The documented source compatibility decision explicitly records the approved Rust1.85-to1.89 minimum increase for patched SQLite. Original consumer sources and old baseline dependencies remain frozen; current consumers run at the new minimum. Static API review and negative controls retain bounded host-only scope; pre1.0 versioning is not used to waive those checks.'}
assert len(compatibility_reviews)==14
for b in blocks:
 if b['line'] in compatibility_reviews:
  b['assessment']=compatibility_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/graph-start-package-checkpoint.json','pointer':'/ci','scope_status':'current_CI_parity_and_named_tests_observed_both_compilers_with_finite_scope'}]
assert sum(b['line'] in compatibility_reviews for b in blocks)==len(compatibility_reviews)
# Reconcile the existing twelve-condition release table with the plan instead
# of generating a second completion certificate. Preserve every open gate.
acceptance_document=root/'docs/0.5/verification.md'
acceptance_text=acceptance_document.read_text()
acceptance_section=acceptance_text.split('### Release acceptance review',1)[1].split('The §13.2',1)[0]
acceptance_rows=[line for line in acceptance_section.splitlines() if line.startswith('| ')][2:]
assert len(acceptance_rows)==12
acceptance_blocks=[b for b in blocks if b['section'].startswith('14.') and b['kind']=='item']
assert len(acceptance_blocks)==12
acceptance_names=['Unified programming model','No mandatory extras','Real integration','No new rewind engine','Durability exists','No effect guessing','Proven compatibility','One public API','Reduced fragmentation','Portable and bounded','Qualification complete','Release controlled']
acceptance_reviews=[]
for i,(b,row,name) in enumerate(zip(acceptance_blocks,acceptance_rows,acceptance_names)):
 cells=[c.strip() for c in row.split('|')[1:-1]]
 assert len(cells)==2 and cells[0]==name,(i,cells)
 expected='Refactor actually reduces fragmentation' if i==8 else name
 assert '**'+expected+':**' in lines[b['line']-1],(i,b['line'])
 status='release_condition_open' if i in [10,11] else 'implemented_with_qualification_open' if i==4 else 'scoped_implementation_support'
 if i in [10,11]:assert '**Open:**' in cells[1]
 if i==4:assert 'chaos remains open' in cells[1]
 if i==2:assert 'protected Linux consumer' in cells[1]
 b['assessment']=cells[1]
 b['review_state']='release_condition_open' if i in [10,11] else 'individually_reviewed_qualification_open' if i==4 else 'individually_reviewed_scoped_support'
 b['evidence']+=[{'file':'../../verification.md','pointer':'Release acceptance review/'+name,'scope_status':status}]
 acceptance_reviews.append({'plan_line':b['line'],'condition':name,'disposition':status,'review_row_sha256':sha(row.encode())})
# The warning and opening paragraph constrain the whole release, not only one
# implementation row. Neither can be discharged by a successful example.
for b in blocks:
 if b['line'] in [976,993]:
  b['review_state']='release_condition_open'
  b['assessment']='The candidate remains explicitly unreleased and not release-qualified. Native integration and durable protocols exist, but immutable full chaos, performance acceptance and final release reconciliation remain open. No advertised scope reduction or completion claim is made.'
  b['evidence']+=[{'file':'../../verification.md','pointer':'Open release gates','scope_status':'explicit_open_release_disposition'}]
acceptance_hash=sha(acceptance_document.read_bytes())
evidence['../../verification.md']=acceptance_hash
# Review the type/guard boundary directly against dispatch and refusal paths.
guard_paths=['crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/tests/machine.rs','crates/penelope-core/tests/machine_hierarchy.rs','crates/penelope/examples/door_machine.rs','docs/0.5/public-api.md']
guard_hashes={}
for name in guard_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);guard_hashes[name]=sha(data)
guard_tests=['decisions_prepare_without_publishing_and_drop_aborts','ignored_staging_errors_validation_and_panics_preserve_the_entire_publication','rejection_and_fault_are_terminal_but_unhandled_walks_the_entire_path','leaf_to_parent_selection_and_lca_exit_action_entry_order_are_exact','each_hook_failure_bad_candidate_and_invariant_failure_discards_the_whole_attempt']
for job in ['Stable verification','Minimum supported Rust']:
 for name in guard_tests:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(name)+r' \.\.\. ok(?:\s|$)',line) for line in adoption_ci.decode().splitlines()),(job,name)
guard_reviews={
223:'Machine uses ordinary associated State/Event types; the door example uses non-Clone enum variants with state-local key data and one trait implementation. Hierarchy remains optional. No repeated string registry, reflection or proc macro is required.',
225:'The illustrative order enum is a type-model sketch, not a literal compiling tutorial. The actual door/nested examples demonstrate variant-local fields; the checked first-machine tutorial uses the implemented signature. This sketch is not silently advertised as a separate API.',
246:'Enum variants prevent fields from belonging to the wrong state variant, but legal event edges and guard predicates remain runtime checks. The public API states this limit. No general workflow typestate guarantee is claimed.',
250:'Model transition receives immutable published state, the supplied event/context and a bounded staging sink. Callback determinism, absence of external effects and mutable-alias discipline are explicit application duties; these are not properties Rust or the library can prove for arbitrary model code.',
252:'Allow is the conceptual continuation into Transition::Accepted, not a second public guard evaluator. The candidate still passes complete invariants, revision checks and staged-intent limits before a consuming handle can publish.',
253:'Transition::Rejected carries a bounded typed RejectCode and returns without assigning state/head/provenance or transferring staged intents. A poisoned staging sink takes precedence and returns a kernel failure even when the callback ignores the sink error; refusal does not clear a resource violation.',
254:'Only Transition::Unhandled permits bounded leaf-to-parent fallback. Explicit child rejection and typed faults are terminal; flat unhandled events leave publication unchanged. Both compilers observe the terminal-rejection/fault versus fallback test.',
255:'Typed model faults remain MachineFailure::Model and hierarchical model faults remain distinct from kernel hierarchy errors. They do not become business denial codes or accepted records. Hook failure/panic tests retain the complete previous publication and discard staged candidate effects.',
257:'Hierarchy traversal order is an explicit bounded leaf-to-root path; selected hooks run exit/action/entry order. Model-local guard ordering remains written application code, not a registry iteration policy. Refusal exposes typed bounded codes without persisting arbitrary messages; application logs still must avoid secrets. Transition IDs and durable authorization operations are typed separately.',
277:'Structural enum and exhaustive-match safety is available now. A general typestate transition builder is optional in the plan and is not implemented or claimed. Runtime validation and durable authority remain required even for structurally typed state.'}
assert len(guard_reviews)==10
for b in blocks:
 if b['line'] in guard_reviews:
  b['assessment']=guard_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/graph-start-package-checkpoint.json','pointer':'/ci','scope_status':'named_guard_and_failure_isolation_tests_observed_both_compilers'},{'file':'../qualification/door-ergonomics.json','pointer':'/negative_controls','scope_status':'enum_guard_example_mutations_with_original_source_scope'}]
assert sum(b['line'] in guard_reviews for b in blocks)==len(guard_reviews)
# Top-level promises and exclusions are reviewed against the actual public
# boundaries, rather than treating a conceptual shared pipeline as one evaluator.
executive_paths=['crates/penelope/src/lib.rs','crates/penelope/src/saga.rs','crates/penelope/src/runtime.rs','crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/hierarchy.rs','docs/0.5/public-api.md','docs/0.5/machine-storage.md','docs/0.5/timeline-machines.md','docs/0.5/architecture.md','scripts/check-layer-boundaries.sh']
executive_hashes={}
for name in executive_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);executive_hashes[name]=sha(data)
executive_reviews={
16:'Canonical facade namespaces and facade-only runnable consumers provide one documented entry point; internal crates remain modular. Portable-core consumers may deliberately depend on the internal core profile. Static API/import compatibility is separately checked.',
17:'The shared conceptual operation separates evaluation, publication and execution. MemoryMachine returns an exclusive prepared candidate without changing published values; durable publication additionally requires a scope/batch-bound receipt. A local event is not automatically authenticated or durably admitted, and specialized native protocols retain their authority.',
18:'Typed flat and single-path hierarchical models support explicit refusal, enum-owned local data, bounded entry/exit order and provenance. The core can run independently; the hosted facade is not the portable no_std target. Application callback work, allocations and purity are outside the internal capacity guarantee.',
19:'Saga and task adapters expose PreparedDecision inspection and native outcomes without replacing the original engines or rewriting v1 histories. Shared staging, identity and storage helpers have explicit owners; native compensation, fencing and finality remain distinct. Inventory alone does not certify all possible semantic duplication absent.',
20:'MachineTimeline delegates to RewindableComputation/LiveTimeline and existing finality/correction. Ordinary MemoryMachine/durable journal paths do not instantiate a speculative timeline owner or require Clone. Eligible timeline models must still supply isolated deterministic computation; full timeline persistence is not introduced.',
21:'MachineStore, independently versioned machine records and the SQLite journal implement their own CAS/receipt/outbox protocol. AtomicProcessCommit remains saga-specific. Packages, migrations and focused crash checks pass, but qualified in the release sense is still open pending the final campaign and performance disposition.',
22:'Task/saga effect uncertainty, generation fencing and reconciliation remain native authorities. Outbox acknowledgement certifies receiver admission, not execution success; the protected consumer admits only verified task output. No transport ACK or timeout is promoted to remote exactly-once completion.',
23:'Portable core defaults are empty and no allocator/database/runtime/macro is required for its checked profiles. Timeline is the facade optional feature; SQLite and process runtime are separately selected adapters. Arbitrary application types or callbacks can still allocate and the umbrella facade remains hosted.',
24:'The public API map teaches one canonical namespace family and explicitly distinguishes local publication, durable admission, speculative finality and native recovery. Legacy paths remain compatibility reexports. Shared-owner inventory and rejected simplifications are retained; this does not waive the remaining maintenance audit or require erasing meaningful protocol distinctions.',
25:'Existing CI, conformance, compatibility, crash models and comparative performance remain gates. Current source packages/coverage/CI pass, while full-source chaos and sustained performance findings remain open. No line-deletion target substitutes for those obligations.',
29:'The supplied profile is a library with optional local SQLite and supported Linux worker integration. It does not advertise a broker, distributed scheduler/database or hosted durable-execution service. Deployment coordination and external-system authority remain host responsibilities.',
30:'Enum variants and exhaustive matches provide structural data ownership; legal runtime event/state combinations remain transition/guard checks. No universal compile-time proof of runtime legality or optional general typestate API is claimed.',
31:'The rollback procedure explicitly requires external-effect reconciliation or domain compensation. Native saga compensation coordinates declared operations; it cannot reverse arbitrary direct application mutations or prove an external effect was undone.',
32:'Machine/HierarchyModel are ordinary traits; door/nested examples need no proc macro, reflection registry or generated per-model SQL. State is privately owned by MemoryMachine with no mutable state accessor; arbitrary user aliases are an explicit model contract, not intercepted field mutation.',
33:'The timeline guide distinguishes captured in-memory correction from machine journal persistence and states that full timeline persistence is not provided. No machine snapshot or journal receipt is advertised as a durable image of speculative timeline history.',
34:'Hierarchy supports one bounded active path. Parallel regions and SCXML compatibility are not supplied; machine-to-native receiver handoff uses recoverable admission/acknowledgement across stores, not a distributed transaction with StateChronicle or external systems.'}
assert len(executive_reviews)==16
for b in blocks:
 if b['line'] in executive_reviews:
  b['assessment']=executive_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  if b['line']==21:b['review_state']='individually_reviewed_qualification_open'
  if b['line']==25:b['review_state']='release_condition_open'
  b['evidence']+=[{'file':'../../verification.md','pointer':'Release acceptance review','scope_status':'current_implemented_vs_open_release_dispositions'},{'file':'acceptance-audit.json','pointer':'/criteria','scope_status':'recorded_shared_owners_and_native_boundaries_not_universal_duplication_proof'}]
assert sum(b['line'] in executive_reviews for b in blocks)==len(executive_reviews)
# Baseline descriptions are immutable0.4 observations, not claims that the
# current candidate lacks the machine/storage features added since then.
baseline_source='42ec187c9adfc7403b06215f405f2575f53c35c2'
assert subprocess.check_output(['git','rev-parse','v0.4.0^{}'],cwd=root,text=True).strip()==baseline_source
baseline_paths=['Cargo.toml','.github/workflows/ci.yml','crates/penelope-executor/src/engine.rs','crates/penelope-executor/src/graph.rs','crates/penelope-core/src/lib.rs','crates/penelope-core/src/task/contracts.rs','crates/penelope-core/src/task/projection.rs','crates/penelope-core/src/task/control.rs','crates/penelope-core/src/task/runtime.rs','crates/penelope-core/src/timeline/wire.rs','crates/penelope-timeline/src/contracts.rs','crates/penelope-timeline/src/step.rs','crates/penelope-timeline/src/live.rs','crates/penelope-timeline/src/session.rs','crates/penelope-timeline/src/handoff.rs','crates/penelope-ports/src/implementation.rs','crates/penelope-sqlite/src/schema.rs','crates/penelope-sqlite/src/process.rs','crates/penelope-sqlite/src/tasks.rs','crates/penelope-sqlite/src/worker.rs','crates/penelope-process-runtime/src/lib.rs','crates/penelope-statechronicle/src/lib.rs','crates/penelope/src/lib.rs','crates/penelope/Cargo.toml','crates/penelope-core/Cargo.toml','crates/penelope-timeline/Cargo.toml','scripts/check-layer-boundaries.sh']
baseline_blobs={name:subprocess.check_output(['git','show',baseline_source+':'+name],cwd=root) for name in baseline_paths}
baseline_hashes={name:sha(data) for name,data in baseline_blobs.items()}
import tomllib
baseline_manifest=tomllib.loads(baseline_blobs['Cargo.toml'].decode())
assert len(baseline_manifest['workspace']['default-members'])==10 and len(baseline_manifest['workspace']['members'])==11
assert baseline_manifest['workspace']['package']['rust-version']=='1.85'
assert 'pub mod machine' not in baseline_blobs['crates/penelope-core/src/lib.rs'].decode()
assert 'let mut candidate = *self;' in baseline_blobs['crates/penelope-core/src/task/projection.rs'].decode()
assert 'Each call commits at most one history record.' in baseline_blobs['crates/penelope-core/src/task/control.rs'].decode()
assert 'PRAGMA journal_mode=WAL' in baseline_blobs['crates/penelope-sqlite/src/schema.rs'].decode()
assert '"FULL"' in baseline_blobs['crates/penelope-sqlite/src/schema.rs'].decode()
baseline_reviews={
42:'This paragraph describes the proposal-time0.4 checkout. Local tagv0.4.0 resolves to42ec187; its workspace has ten default library packages plus fuzz, version0.4.0 and Rust1.85. It is not a current candidate inventory. Later baseline compile/benchmark evidence was collected separately; its timing before every refactor remains unproven.',
44:'Historical baseline table header. The rows below describe0.4 subsystem boundaries, not missing0.5 implementations.',
46:'The original linear engine has pinned definitions, typed decisions, retries, compensation and replay for executable steps. Current canonical saga APIs retain that native contract rather than treating it as the arbitrary application-machine evaluator.',
47:'The original graph engine keys edges by GraphTransitionOutcome and checks active actions, replay and visit limits. Graph topology is not a hierarchical active-state path. Current HSM remains a separate portable helper with its own path validation.',
48:'Original TaskProjection/TaskControl govern task execution state, generation, recovery and checkpoints. They remain native authorities beneath the new inspection view; this baseline row does not describe the later general business-state machine.',
49:'Original timeline computation supplies scratch correction, anchors, exact-head publication and separate effect finality. Full persistent timeline recovery is not inferred from existing checkpoint metadata or the new durable machine journal.',
50:'Original process ports bind saga outcomes, actions, inbox/outbox, timers and authorization. AtomicProcessCommit remains saga-specific in the candidate; new machine ports have independent wire and receipt coordinates.',
51:'Original SQLite schema configures WAL/FULL and reaches schema6 with process/task stores and a bounded hosted queue. The candidate adds an independently scoped machine journal through forward-only migrations; the statement no machine journal is historical only.',
52:'The original protected-process runtime is an optional supported Linux profile with generation enforcement and bounded IPC. It is not a portable-core scheduler or a distributed termination guarantee.',
53:'The original StateChronicle facade exposes verified-event correlation, not inherited external authority. Current signed-source conformance is separately pinned and qualified; local hashes remain content identities.',
54:'The original facade reexports native subsystem APIs with optional timeline. The current canonical namespaces are additions preserving those old paths, so this row records the starting organization rather than current onboarding.',
58:'The baseline GraphTransition has from_step/on/to_step and three result categories. ProcessGraphDefinition validation checks bounded references/reachability; native graph replay and action identity remain separate from HSM dispatch. Frozen parity is finite evidence, not all possible graphs.',
59:'The baseline apply method copies TaskProjection, applies into the candidate and assigns only on success. Candidate preparation now shares that private evaluator while retaining the same publication rule and native status set; frozen observations check old behavior.',
60:'The baseline TaskControl contract explicitly commits at most one record per advance and poisons after ambiguous journal/runtime outcomes. Current source is separately checked byte-identical for this authority; machine inspection does not weaken reconstruction requirements.',
61:'Baseline prepare_live_step documents isolated scratch and an opaque ReadyStep; ReplaySession has explicit abort/promotion. LiveTimeline owns coherent publication and effect handoff distinguishes eligibility/admission/execution. The adapter reuses these authorities rather than creating another correction engine.',
62:'The original timeline v1 namespace remains independent of saga/task v1 contracts. New penelope.machine.v1 metadata, goldens and strict decoding were added without assigning new meaning to old records.',
63:'This is the original CI/feature policy: empty core/timeline defaults, optional facade timeline, Rust1.85 and RISC-V checks. The approved candidate minimum is1.89 with current CI; original1.85 evidence is not relabeled as a candidate guarantee.',
64:'The original dependency allowlist is explicit. Current architecture checks deliberately encode the new permitted owners and dev-only composition edges; they retain exact dependency constraints rather than removing the gate.'}
assert len(baseline_reviews)==18
for b in blocks:
 if b['line'] in baseline_reviews:
  b['assessment']=baseline_reviews[b['line']];b['review_state']='reviewed_historical_baseline'
  b['evidence']+=[{'file':'../manifest.json','pointer':'/baseline_commit','scope_status':'original_source_and_later_baseline_evidence_not_historical_order_proof'}]
assert sum(b['line'] in baseline_reviews for b in blocks)==len(baseline_reviews)
evidence['../manifest.json']=sha((directory/'../manifest.json').read_bytes())
# Performance coverage and acceptance are separate. Recommended profile names
# cannot turn batch means into event percentiles or waive sustained findings.
performance_records=['../qualification/candidate-capability-performance.json','../legacy-balanced/versioned-candidate.json','../sqlite-balanced/versioned-candidate.json','../sqlite-balanced/qpsg-balanced.json','manifest.json','../machine-performance/manifest.json','../machine-performance/hierarchy.json','../machine-performance/state-cost.json']
performance_hashes={}
for name in performance_records:
 data=(directory/name).read_bytes();performance_hashes[name]=sha(data);evidence[name]=sha(data)
capability=json.loads((directory/performance_records[0]).read_text())
assert len(capability['profiles'])==7
assert 'batch means' in capability['sample_scope']['core']
assert '101 races' in capability['sample_scope']['sqlite']
assert 'quadratic' in capability['profiles']['machine_hierarchy']
performance_reviews={
936:'The same-work legacy comparison uses original0.4 fixtures and independently locked binaries; new machine capabilities are measured separately. Timeline native/adapter and QPSG variant comparisons preserve their own revision/guarantee scopes. Historical measurements and unsuccessful diagnostics remain retained; no pure-versus-durable ratio is used as a release result.',
940:'Recommended workload table header; row assessments below identify measured scope and differences from the suggested reports, not a promise that every possible payload/environment was measured.',
942:'The retained core matrix covers2/8/32 states/events, guard acceptance/refusal, four owned widths and0/1/8/32 intents. Quantiles are101 chronological elapsed batch means of32 operations, not individual-call latency percentiles. Allocation probes and throughput are scoped to those fixtures.',
943:'The hierarchy matrix covers depth1/2/4/8/16 and leaf/parent/root handling,32-byte state and no intents, including internal/external/refusal/unhandled paths. Workspace is bounded by configured depth; prefix cycle validation is quadratic in depth, not a claim of constant/linear total work.',
944:'The state-cost fixture separates owned copy/counter work, consumer transition and MemoryMachine publication at8/256/4096/65536-byte state with capacity0. These are fixture costs, not a bound on arbitrary user computation, heap behavior or aliasing.',
945:'The flat matrix measures0/1/8/32 staged intents and quota refusal at fixed capacity32, including staging/publication and the allocation probe. Capacity remains32 even in the0-intent rows; it is not a layout comparison of all const-generic capacities.',
946:'Original frozen saga fixtures, including parallel variants, are retained in the31-pair legacy comparison. Their timings are process loop means and measured resource context; they are not individual saga event p50/p95 distributions. Frozen semantic observations remain independent of timing. This report-shape refinement does not waive open comparative findings or final exact-source qualification.',
947:'Legacy task poll/checkpoint/restart/replay workloads and frozen results remain measured with memory/resource observations. Same-work loop-mean comparisons do not establish event-tail latency or equivalence. Startup, supervision and protected end-to-end profiles retain distinct scopes.',
948:'The adapter/native timeline matrix covers live input and correction horizons1/8/32/128 at four state widths with101 individual-call samples and separate allocation probes. Adapter provenance/context/ownership costs differ; this is not a claim of equivalence to an independently built original0.4 binary.',
949:'The SQLite fixture covers1/2/8/32 independent writers, one accepted CAS/intent per race, exact retries and separate coherent head-snapshot reads, with integrity checks. Every commit requires complete next-state bytes; no unsupported snapshot-free commit is invented. The refresh retains101 races, WAL/database sizes and process I/O/RSS context. Race quantiles are not distributions of individual refusal latency or exact physical disk writes.',
950:'The protected native pipeline measures109 complete sequential workflows per process,101 retained after warmup, with12 phases across commit, admission, lost ACK/reopen, real worker, verified result and subsequent saga admission. Saga action remains undispatched. Separate queue-capacity/burst fixtures cover intentionally gated backpressure; these do not establish throughput/saturation at arbitrary concurrency.',
954:'Pure core fixtures show zero internal allocations for the checked allocation-free types, with an enabled allocation positive control. Bare/serde portable builds are separate compile gates. Neither result bounds arbitrary user allocations or demonstrates timing on physical bare-metal hardware.',
955:'This gate remains open:31-pair comparisons retain encoding/timeline regressions and database findings. Diagnosis, a patched dependency attribution, a noisy control or an interval spanning zero is not explicit regression acceptance. No acceptance has been recorded.',
956:'Configured active paths bound dispatch and cycle checks; traversal does not scan unrelated machine instances. Measurements cover finite depths and include failure/refusal paths. Cycle detection is quadratic in configured depth; bounded scaling is not silently advertised as a linear latency guarantee.',
957:'Database comparisons retain actual WAL/FULL transaction work, cache/filesystem/shared-host conditions and original versus patched-dependency/QPSG variants. The setting addresses observed recompilation, while reopen/append-tail findings remain open. Additional safety work is described rather than subtracted or hidden by changing expected data.',
958:'Maintenance evidence retains separate empty-target artifact-cold build/test observations, dependency/doc/LOC inventories, peak RSS and boilerplate examples. Registry/OS caches were warm or uncontrolled and empty rlib inventories supply no size evidence. The capability refresh retains14 actual benchmark executables; these are not linked application size or fresh-install/cold-boot measurements. Pure core has no mandatory hosted dependency. All measurements retain original source scopes; final reconciliation remains open.'}
assert len(performance_reviews)==16
for b in blocks:
 if b['line'] in performance_reviews:
  b['assessment']=performance_reviews[b['line']];b['review_state']='individually_reviewed_measurement_scope'
  if b['line'] in [955,957]:b['review_state']='performance_acceptance_open'
  b['evidence']+=[{'file':'../qualification/candidate-capability-performance.json','pointer':'/profiles','scope_status':'recorded_new_capability_fixture_scope_not_final_performance_acceptance'},{'file':'../legacy-balanced/versioned-candidate.json','pointer':'/measurement_limits','scope_status':'original_comparator_and_report_shape_retained'}]
assert sum(b['line'] in performance_reviews for b in blocks)==len(performance_reviews)
# Cross-file architecture prose/diagrams describe shared principles and typed
# composition. They do not introduce an undocumented universal interpreter.
system_paths=['crates/penelope/src/lib.rs','crates/penelope/src/diagnostics.rs','crates/penelope/src/storage.rs','crates/penelope/src/runtime.rs','crates/penelope/src/integration.rs','crates/penelope-core/src/machine/view.rs','crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-timeline/src/machine.rs','crates/penelope-executor/src/machine_task.rs','crates/penelope-executor/src/machine_saga.rs','docs/0.5/public-api.md','docs/0.5/timeline-machines.md','docs/0.5/architecture.md','scripts/check-layer-boundaries.sh']
system_hashes={}
for name in system_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);system_hashes[name]=sha(data)
system_reviews={
3:'This is the immutable proposal metadata and original baseline/policy, not current release status. The approved Rust1.89 exception and implemented source are tracked in architecture/compatibility/verification; no final release qualification is claimed by this historical status text.',
10:'The central decision is implemented as one canonical facade and shared inspection/primitives with explicit native authorities. It does not require sagas, tasks and timeline to execute through one evaluator. Maintenance evidence records actual consolidation and retained boundaries; full qualification remains open.',
68:'PreparedDecision unifies read-only inspection while saga/task adapters retain their original native decisions and wire. MachineTimeline delegates to RewindableComputation. Consumer coherence is provided by canonical namespaces and shared examples, without pretending all native state owners are interchangeable.',
70:'Shared helpers have explicit primitive owners and equivalence/negative controls in the maintenance audit. Machine scope/revision, task generation/ticks and timeline branch/frontiers remain distinct typed coordinates. Similar validation text alone is not proof that extraction is safe or all duplication absent.',
72:'The public API distinguishes proposed candidate, committed batch, receiver admission, dispatch and verified/reconciled external outcome. PreparedDecision supplies no generic commit/dispatch authority; native task/saga bridges validate their own receipts. Admission is not completion.',
74:'The new machine metadata codec, accepted payload batch, MachineStore and SQLite journal provide independent scoped durable admission. Snapshot restore/event replay and outbox are implemented. Release-qualified durability remains subject to final campaign/performance gates.',
76:'The public diagnostics map answers evaluation, refusal, commit, causation, downstream admission and execution-success questions from their corresponding native evidence. Refusals are separate from accepted history and legacy missing coordinates remain absent. This is a read-only contract, not a built-in telemetry backend or authenticated audit service.',
78:'The short README, source-checked first-machine tutorial and canonical public API map provide facade-first onboarding. Optional SQLite/process runtime are selected for their own profiles; pure-core users can deliberately select the portable internal crate. No knowledge of old subsystem paths is required by the basic machine tutorial.',
82:'Domain-specific action/result identities, generations, tick/logical-time types, timeline frontiers, compensation ordering and external canonical correlation are retained. Shared inspection keeps native associated types and cannot issue a universal admission receipt. SQLite retains the documented WAL/FULL single-host profile.',
90:'The diagram describes the staged conceptual pipeline. Local events need not have durable admission; host authentication precedes hosted operations, accepted candidates are still tentative before publication, and dispatch/outcome reconciliation occurs separately. It is not an executable orchestrator or a cross-store atomic transaction.',
123:'MachineScope pins definition fingerprint and state/event schemas; in-memory restore and durable preparation validate the supplied model. Identity does not establish authenticity or executable availability; authenticated migrations and retained codecs/models remain host duties.',
124:'Evaluation borrows immutable published state and supplied context, with an isolated owned candidate and bounded staging. Rejection/unhandled/faults do not publish. Purity and absence of mutable aliases into live state remain application contracts; arbitrary Rust callback side effects are not automatically sandboxed.',
125:'MemoryMachine moves the coherent state/head/provenance/intents tuple through a consuming handle. Durable publication separately verifies the exact complete batch receipt before consuming its handle. Neither a decoded record nor a PreparedDecision implementation can manufacture admission authority.',
126:'The core stages intents only. Explicit host services and native receivers perform later task/saga/timer work under their own journal and fencing contracts. Evaluation itself does not start workers, dispatch I/O or infer effect success.',
127:'Machine revisions and events are ordered in the journal; snapshots and isolated original-event replay are separate supported recovery paths. Timeline branches/correction are optional and have independent finality, eligibility and restoration requirements.',
128:'Provenance and native receipts expose structured transition/effect stages. Rejected attempts remain typed refusals against the unchanged state rather than accepted journal records. Host telemetry can use bounded redacted views but is not a new source of truth.',
132:'Concept table header; the following rows map conceptual roles to separate native owners and retained guarantees.',
134:'machine is the general typed application transition API with bounded local ownership, using no required hosting or history engine in its portable-core profile.',
135:'saga is a specialized coordinating lifecycle exposed through canonical native functions and prepared views. Compensation, retries, action correlation, manual review and v1 process records retain their original semantics; it is not a general order-enum interpreter.',
136:'task is a specialized recoverable lifecycle whose prepared view does not start work. TaskControl/native supervisor retain journal-first launch, generation fencing, checkpoint and reconciliation authority.',
137:'timeline is an optional compatible-computation mode. MachineTimeline chooses the existing timeline owner and preserves captured context; it does not nest a MemoryMachine publisher or duplicate replay/finality machinery.',
138:'storage reexports backend-neutral protocol-specific ports. Process, task and machine commits keep different coordinates/receipts and authorization boundaries; snapshots do not imply persistent speculative timeline history.',
139:'runtime exposes the existing task runtime/clock/reservation contracts. Protected Linux execution is a separately selected adapter, not a compulsory host executor for the portable machine core.',
140:'integration::statechronicle retains verified external canonical-event correlation. A locally committed machine state or matching digest does not acquire StateChronicle authority or prove remote resource ownership.',
142:'Specialized lifecycle semantics are intentional: common PreparedDecision inspection cannot replace task-generation control, saga recovery or timeline effect finality. Their associated types and missing legacy coordinates remain explicit.',
146:'Facade-first use is implemented by canonical modules and runnable external consumers. The following snippet is a namespace illustration, not a claim that all feature selections expose timeline.',
148:'The machine/saga/task paths exist. The timeline import is available only with the timeline feature; comment placeholders are illustrative and not a standalone runnable tutorial. The checked first-machine source supplies the actual complete program.',
155:'The plan labels the imports as a proposal-time sketch. Current public-api/getting-started documentation supplies implemented names and compiling consumers; experienced users may still select internal crates for portable or adapter-specific profiles.',
159:'This responsibility diagram is deliberately not a literal Cargo dependency graph. The checked allowlist is authoritative: domain remains independent, intent depends on domain, core is portable, and adapter composition edges can be dev-only. No diagram arrow waives those constraints.',
174:'The kernel is in core::machine, ports in ports::machine and SQLite in sqlite::machine; no new published machine package was created. The draft executor::machine filename is deliberately refined to native machine_task/machine_saga and saga_machine owners, as reviewed at planline519. An extra umbrella module/evaluator is not required to duplicate that responsibility.',
1071:'The final position is a shared conceptual deterministic transition/admission/execution model with separate native guarantees. Callback determinism and source authenticity remain explicit application responsibilities; the candidate is not yet advertised as a complete qualified release.',
1073:'The introductory path starts with a local Machine and explicitly adds saga/task/native runtime or eligible timeline as needed. Existing users can retain old APIs/history without mandatory conversion; cross-component handoffs are typed and durably admitted rather than hidden mutation.',
1075:'Coherence is assessed through canonical onboarding, common inspection, explicit owners, native typed handoffs and compatibility evidence. Feature count, code-count reduction or green examples alone do not close the remaining qualification/performance/release conditions.'}
assert len(system_reviews)==33
for b in blocks:
 if b['line'] in system_reviews:
  b['assessment']=system_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  if b['line']==3:b['review_state']='reviewed_historical_proposal_metadata'
  if b['line'] in [90,148,159]:b['review_state']='illustrative_architecture_reviewed'
  if b['line']==174:b['review_state']='implementation_path_refinement_reviewed'
  b['evidence']+=[{'file':'../../verification.md','pointer':'Release acceptance review','scope_status':'shared_conceptual_pipeline_and_separate_native_authorities_with_open_release_gates'},{'file':'integration-contract-audit.json','pointer':'/','scope_status':'recorded_native_adapter_and_composition_checks_with_original_revision_scope'}]
assert sum(b['line'] in system_reviews for b in blocks)==len(system_reviews)
# Reconcile adversarial cases with actual observed invariant tests. Conformance
# is a separate stable-only job, not silently counted as workspaceMSRV coverage.
invariant_record=json.loads((directory/'invariant-audit.json').read_text())
adversarial_tests={};adversarial_owners=set()
for item in invariant_record['invariants']:
 adversarial_owners.update(item['owners'])
 for test in item['negative_and_boundary_tests']:
  adversarial_tests[(test['path'],test['function'])]=test
assert len(invariant_record['invariants'])==15
assert len(adversarial_tests)==29 and sum(len(x['negative_and_boundary_tests']) for x in invariant_record['invariants'])==33
adversarial_observations=[]
for (name,function),test in adversarial_tests.items():
 assert re.search(r'\bfn\s+'+re.escape(function)+r'\b',(root/name).read_text()),(name,function)
 jobs=['Optional StateChronicle signed-event conformance'] if name.startswith('scripts/conformance/') else ['Stable verification','Minimum supported Rust']
 for job in jobs:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(function)+r' \.\.\. ok(?:\s|$)',line) for line in adoption_ci.decode().splitlines()),(job,function)
 adversarial_observations.append({'path':name,'function':function,'jobs':jobs})
adversarial_paths=sorted(adversarial_owners|{t[0] for t in adversarial_tests}|{'docs/0.5/public-api.md','docs/0.5/machine-storage.md','docs/reliable-execution-operations.md','crates/penelope-ports/src/machine/recovery.rs'})
adversarial_hashes={}
for name in adversarial_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);adversarial_hashes[name]=sha(data)
for line_number in [217,224]:
 assert any(line.startswith('Stable verification\tRun cargo test --workspace --doc') and f'machine::memory::PreparedTransition (line {line_number}) - compile fail ... ok' in line for line in adoption_ci.decode().splitlines()),line_number
adversarial_reviews={
645:'All15 listed invariants have explicit owner paths and33 negative/boundary references representing29 distinct tests. Current CI observes the workspace cases on stable/MSRV and the signed-source case in its separate stable conformance job. The later replay path has separate qualification evidence; this reconciliation does not prove every possible adversarial input or finish full chaos.',
667:'Scope/model/codec/event/batch and every receipt coordinate are checked by owner/preparation/store boundaries, with substitution tests. Authorization precedes scoped reads/retries. In-memory IDs/digests remain caller assertions and hashes cannot authenticate hostile source bytes; the hosted principal and external evidence must be independently authenticated.',
668:'Checked revisions refuse wraparound/stale heads; strict records and bounded history reject truncation, gaps/reordering and payload substitutions, while exact duplicates compare complete content. Independent history-partition and event-replay tests supplement the invariant corpus. Authenticated source/model availability remains required for recovery.',
669:'Only Unhandled bubbles to a parent. The current terminal child-rejection/fault test checks unchanged state/head and the exact visited path. Guard selection has no staging sink; a parent is not tried after explicit denial.',
670:'Supplied TransitionContext has no clock/RNG/host service, but arbitrary application callbacks can still access ambient or aliased state. The supported contract requires captured dependencies and deterministic callbacks; the existing uncaptured-dependency test documents detection only with same-baseline verification enabled. No automatic purity sandbox or proof is claimed.',
671:'Bounded staging poisons on count/byte/identity failure even if the callback ignores the error or catches a payload-destructor panic. Model/hook errors after staging discard the whole tentative attempt. These checks preserve the previous publication; arbitrary callback side effects remain unsupported.',
672:'Lost commit ACK retains/retries exact content or resolves it from authoritative storage, competing writers revalidate under transactional CAS, and native generations fence delayed results. Native receiver/source acknowledgement tests cover recovery after downstream acceptance; neither a timeout nor admission receipt proves external completion.',
673:'Snapshot restore checks exact scope/model/codec, canonical bytes and invariants; malformed/checksummed substitutions fail. Existing task checkpoint migration requires explicit authorized import. There is no general automatic machine-schema migration service; changing interpretation requires a separate authenticated host decision.',
674:'Unwind/drop and codec panic checks preserve publication; cleanup panic after a successful publish observes the coherent committed tuple. The owner-bound exclusive borrow and stable compile-fail doctests prevent simultaneous safe access/republication while a prepared handle lives. This does not promise prevention of arbitrary deadlocks or side effects through unsupported callback aliases.',
675:'Existing timeline effect-finality and handoff remain authoritative through MachineTimeline; correction cannot roll back an admitted/finalized external effect. Native integration tests exercise captured context and finality. They do not reverse an actual bank payment or certify external settlement; application reconciliation still applies.',
676:'Machine and native receiver stores commit independently. Source-bound durable intent identity, exact native admission receipts and retryable acknowledgement recover the gap; lost-ACK/reopen tests observe idempotent downstream admission. The protected consumer checks verified results before a follow-up machine event. No cross-store atomicity or automatic external compensation is claimed.',
680:'The pure model is not an authenticator. Hosted MachineAuthorizer uses an application-owned context and operation-specific policy before scoped reads/duplicates/admission; native receiver policies remain mandatory. The operations/API guides place principal authentication, privileged override policy and secret-safe logging with the host. A digest or scope string supplies none of those authorities.',
684:'MachineStore is authoritative for its own admitted machine history only. StateChronicle/domain facts require independently verified canonical evidence; local receipts/hashes cannot prove remote ownership or execution. Current stable signed-source conformance checks exact binding under a pinned upstream, with no inherited authority.'}
assert len(adversarial_reviews)==13
for b in blocks:
 if b['line'] in adversarial_reviews:
  b['assessment']=adversarial_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'invariant-audit.json','pointer':'/invariants','scope_status':'fifteen_owners_and33_references_reobserved_in_current_CI_with_conformance_scope_separate'},{'file':'../qualification/graph-start-package-checkpoint.json','pointer':'/ci','scope_status':'current_CI_log_identity_bound_to_archive'}]
 if b['line'] in [647,665]:b['review_state']='section_label';b['assessment']='Invariant table header or adversarial-case label; obligations are reviewed in the numbered invariant record and following individual cases.'
assert sum(b['line'] in adversarial_reviews for b in blocks)==len(adversarial_reviews)
# Remaining core sketches, extraction criteria and ergonomic prose are checked
# against implemented APIs; illustrative code is not passed off as compilable.
core_followup_paths=['crates/penelope-core/src/__private.rs','crates/penelope-core/src/machine/contracts.rs','crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/hierarchy.rs','crates/penelope-core/src/machine/identities.rs','crates/penelope-core/src/machine/wire.rs','crates/penelope-core/src/machine/view.rs','crates/penelope-core/src/task/identities.rs','crates/penelope-core/src/timeline/identities.rs','crates/penelope-core/src/timeline/wire.rs','crates/penelope-timeline/src/effects.rs','crates/penelope-timeline/src/machine.rs','crates/penelope-ports/src/machine/recovery.rs','crates/penelope/examples/door_machine.rs','crates/penelope/examples/nested_order.rs','crates/penelope/examples/support/counter.rs','crates/penelope/examples/prepared_decisions.rs','docs/getting-started.md','docs/0.5/public-api.md','docs/0.5/architecture.md']
core_followup_hashes={}
for name in core_followup_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',followup_source+':'+name],cwd=root);core_followup_hashes[name]=sha(data)
for name in ['crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/wire.rs','crates/penelope-timeline/src/effects.rs']:
 assert 'admit_intent::<' in (root/name).read_text(),name
core_followup_reviews={
182:'The proposal sketch was refined into the current compile-tested trait and external fixtures. Current API names/generics are documented; the stricter temporal demand for fixtures before all implementation remains part of the unproven historical sequence, not certified by present-day compilation.',
184:'The implemented Machine retains the sketched associated types and reference-based generic-sink transition. It additionally requires definition/validate and Accepted carries a typed transition ID. This fenced sketch is illustrative, not a second supported signature; runnable source consumers check the actual API.',
207:'TransitionContext supplies expected MachineHead including scope/definition/schema, event identity/digest and logical time. It contains no ambient service. Local coordinates are caller assertions until independently bound by a durable codec/store; arbitrary callback I/O or mutable aliases cannot be automatically prevented.',
219:'The trait has no blanket Clone or serialization bound. Owned-state8B-to64KiB fixtures separate copying, consumer transition and publication. No general zero-copy or delta-edit extension is promised, and optional timeline convenience Clone requirements do not leak into the base contract.',
261:'Hierarchy is one bounded active path with model-owned leaf/parent IDs. Leaf-to-root dispatch, terminal denial/faults, selected exit/action/entry order, explicit self/internal semantics and poisoned staging are tested. Cyclic parent paths fail rather than looping; sequential events may recur under caller budgets. Orthogonal regions are explicitly unsupported.',
273:'Hierarchical implements the same Machine contract and uses the same MemoryMachine/port publication paths. Flat models implement the trait directly, without reflection, registration, hierarchy workspace or an extra evaluator. Measurements retain their finite profile and open comparative limits.',
281:'Extraction follows the reviewed maintenance criteria: identify equivalent semantics, preserve errors/order/bounds, compare native behavior and reject slower or weaker alternatives. Similar-looking native recovery/finality code is deliberately retained when contracts differ; counts alone do not prove all semantic duplication absent.',
283:'Local and durable preparation share the same consuming candidate; durable preparation adds canonical payload binding and verified receipt checks. PreparedDecision shares inspection but has no universal publish/commit operation. Native task and timeline publication remain distinct authorities.',
284:'The internal admit_intent helper centralizes count-before-identity-before-byte preflight. Memory/wire/timeline call it with their native error categories. Adapters pre-poison before payload destruction; timeline retains its StepContext, retained-batch ordering and public EffectSink semantics.',
285:'Rejected/Unhandled are explicit dispositions and model faults remain concrete typed variants. Storage conflict/corruption/quota/authorization and native ambiguity/recovery have their own typed categories. The documentation relates lifecycle stages without inventing a universal error enum that erases native distinctions or changes error precedence.',
286:'Identity construction/checked counter and bounded byte primitives are shared internally while MachineRevision, task ticks/generations, saga steps and timeline branches retain different public newtypes. The private helpers are not an unchecked universal identity conversion API.',
287:'Native saga/task/timeline replay retain protocol-specific sequence and rejection rules. Machine snapshot restoration shares its own native restore helper, and original-event replay reuses normal preparation with complete regenerated-batch comparison. Generic replay is not forced across incompatible histories; frozen and independent model tests retain scope.',
288:'Definitions/schemas are pinned at construction/preparation/recovery and mismatches are refused. Legacy migration admission and new machine host-authenticated interpretation policy remain separate. No automatic general model migration or old-wire reinterpretation is added merely to centralize a helper.',
289:'PreparedDecision supplies machine, linear/graph saga and task candidate inspection with native associated types. Timeline state/intents retain the shared machine TransitionRecord while native timeline steps/sessions keep their own API; no PreparedDecision implementation for timeline is claimed. Legacy absent coordinates remain absent, and proposed provenance is not a committed receipt. Diagnostics map lifecycle questions to native evidence.',
291:'Domain distinctions remain intentional: no blanket StepId/TaskTick/TimelineRevision integer alias or implicit cross-protocol conversion was introduced. Explicit timeline intent correlation assigns bytes under that adapter contract, without converting authority or merging frontier/revision meaning.',
564:'The actual door example uses one non-Clone state enum with variant-local key data, one event enum and one Machine implementation. No SQL, scheduler, string registry or duplicate graph table is required. Stable/MSRV source/package consumers and independent eight-event oracle/mutations check this profile; explicit fixture metadata remains visible.',
566:'This illustrative door sketch predates definition/validate/transition-ID requirements and is not copied into the compiling tutorial. The actual door source uses the implemented trait, guards, state-local data and stable refusal codes. Current package/source checks validate that exact example on both compilers.',
612:'Door demonstrates legal/illegal edges, stable guarded refusals and Unhandled; nested/counter examples add staged effects and ordered hooks, and durable progression handles verified task-result errors/ambiguity. The flat door itself stages no effects, so it is not misrepresented as an external-effect demonstration.',
616:'The checked nested-order example supplies typed parent/leaf events, explicit override/fallback, guard refusals and deterministic exit/entry traces. Its six complete traces and three compiled semantic negative controls cover the stated ergonomic profile; allocation probes separately use a non-Clone enum with local fields.',
629:'Hierarchy uses ordinary Rust traits/enums with no required proc macro and explicitly excludes orthogonal/parallel regions. No Statig/SCXML equivalence or syntax compatibility is claimed; optional macro sugar is not a missing mandatory feature.'}
assert len(core_followup_reviews)==20
for b in blocks:
 if b['line'] in core_followup_reviews:
  b['assessment']=core_followup_reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  if b['line'] in [184,566]:b['review_state']='illustrative_API_refinement_reviewed'
  if b['line']==182:b['review_state']='API_supported_historical_sequence_unproven'
  b['evidence']+=[{'file':'core-contract-audit.json','pointer':'/','scope_status':'recorded_core_contract_tests_and_owner_scope'},{'file':'acceptance-audit.json','pointer':'/criteria','scope_status':'shared_helper_and_retained_protocol_boundary_review'},{'file':'../qualification/graph-start-package-checkpoint.json','pointer':'/ci','scope_status':'current_archive_and_CI_consumer_checks_not_historical_sequence_proof'}]
assert sum(b['line'] in core_followup_reviews for b in blocks)==len(core_followup_reviews)
result={'scope':'Full source-plan block inventory for remaining review. Includes prose, every list/table row and all13 fenced examples/diagrams. Blocks are not atomic semantic requirements: one paragraph can impose several obligations. Indexed evidence retains its own revision and limits; no block is certified complete by matching text.','plan':'../../plan.md','plan_sha256':sha(raw),'line_count':len(lines),'manual_source_commit':source,'manual_source_sha256':manual_hashes,'manual_ci_named_tests':observed,'api_storage_review':{'source_commit':followup_source,'source_sha256':followup_hashes,'ci_source_commit':door_ci['headSha'],'named_tests_observed_both_compilers':followup_tests,'reviewed_blocks':len(content_reviews),'chronology':chronology,'scope':'API, durable contracts, guarantee tiers and ADR content; historical sequencing and release/performance gates remain open.'},'refactor_map_review':{'source_commit':followup_source,'source_sha256':refactor_hashes,'reviewed_blocks':len(refactor_reviews),'scope':'Actual module owners, proposed path refinements and shared-extraction criteria; final release/dated notes and performance gates remain open.'},'adoption_review':{'source_commit':followup_source,'source_sha256':adoption_hashes,'reviewed_blocks':len(adoption_reviews),'scope':'Six explicit adoption steps and rollback/reconciliation documentation; no production rollout, automatic state conversion or external-effect rollback is certified.'},'compatibility_matrix_review':{'source_commit':followup_source,'source_sha256':compatibility_hashes,'reviewed_blocks':len(compatibility_reviews),'named_tests_observed_both_compilers':compatibility_tests,'scope':'Thirteen compatibility surfaces and the explicit source-change policy. Frozen finite corpora and supported host profiles are not universal compatibility proof; full campaign and performance acceptance remain open.'},'release_acceptance_review':{'production_source_commit':followup_source,'review_document':'../../verification.md','review_document_sha256':acceptance_hash,'conditions':acceptance_reviews,'scope':'Positional twelve-condition reconciliation with the existing human-readable review. Implemented capability is distinct from release qualification; no gate is closed solely by this index.'},'type_guard_review':{'source_commit':followup_source,'source_sha256':guard_hashes,'reviewed_blocks':len(guard_reviews),'named_tests_observed_both_compilers':guard_tests,'scope':'Enum data ownership, runtime guard dispositions, terminal refusal/fault and explicit purity boundaries; no automatic callback purity or universal typestate guarantee.'},'executive_scope_review':{'source_commit':followup_source,'source_sha256':executive_hashes,'reviewed_blocks':len(executive_reviews),'scope':'Ten executive decisions and six explicit non-goals. Shared conceptual semantics do not imply identical native evaluators; qualification and performance gates remain open.'},'historical_baseline_review':{'source_commit':baseline_source,'source_sha256':baseline_hashes,'reviewed_blocks':len(baseline_reviews),'scope':'Immutable0.4 source facts, starting subsystem boundaries and original policies. Current features and approvedMSRV are reviewed separately; chronology before every refactor is not proven.'},'performance_method_review':{'records_sha256':performance_hashes,'reviewed_blocks':len(performance_reviews),'scope':'Same-work methodology, nine recommended workload rows and five provisional gates. Report shape, revision and environment limits remain explicit; no sustained regression is accepted and final exact-source qualification remains open.'},'system_model_review':{'source_commit':followup_source,'source_sha256':system_hashes,'reviewed_blocks':len(system_reviews),'scope':'Debt/removal rationale, conceptual pipeline, native subsystem roles, facade/dependency sketches and final architectural position. Illustrative arrows/imports are not literal dependency or feature guarantees; release qualification remains open.'},'adversarial_review':{'source_commit':followup_source,'source_sha256':adversarial_hashes,'reviewed_blocks':len(adversarial_reviews),'current_test_observations':adversarial_observations,'compile_fail_doctests_stable':[217,224],'scope':'Ten adversarial cases, invariant ownership and two host-authority policies. Callback purity/authentication/remote authority remain explicit host duties, and signed-source conformance is stable-only.'},'core_sketch_and_extraction_review':{'source_commit':followup_source,'source_sha256':core_followup_hashes,'reviewed_blocks':len(core_followup_reviews),'scope':'Actual trait refinements, context/owned-state boundaries, shared-helper extraction and flat/nested ergonomics. Illustrative sketches are distinct from compiling public fixtures; pre-implementation chronology remains unproven.'},'counts':{'blocks':len(blocks),'by_kind':dict(collections.Counter(b['kind'] for b in blocks)),'by_review_state':dict(collections.Counter(b['review_state'] for b in blocks))},'evidence_sha256':evidence,'blocks':blocks,'limits':['This is a navigation/review inventory, not a new test, guarantee, semantic completeness proof or release qualification.','Every remaining normative clause must still be assessed against current source and adequately scoped evidence; a link or matching heading does not establish completion.','Historical references and advisory PR breakdown remain present and distinct from release deliverables.','Existing audit statuses are preserved, including performance, campaign, historical sequencing and publication obligations.','Plan examples marked as illustrative/pseudocode need semantic review; they are not silently treated as literal public signatures.'],'generator':'plan-review-index.py.gz'}
(directory/'plan-review-index.json').write_text(json.dumps(result,indent=2)+'\n');(directory/'plan-review-index.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print(json.dumps(result['counts']))
