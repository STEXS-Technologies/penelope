import collections,gzip,hashlib,json,re
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');directory=root/'docs/0.5/evidence/maintenance';plan=root/'docs/0.5/plan.md';raw=plan.read_bytes();lines=raw.decode().splitlines();sha=lambda b:hashlib.sha256(b).hexdigest()
blocks=[];buf=[];start=0;section='preamble';kind=None;fence=False

def flush():
 global buf
 if buf:
  text='\n'.join(buf)
  blocks.append({'line':start,'end_line':start+len(buf)-1,'section':section,'kind':kind,'text':text})
  buf=[]
for no,line in enumerate(lines,1):
 if line.startswith('#') and not fence:
  flush();section=line.lstrip('# ').strip();continue
 if line.startswith('```'):
  if fence:
   buf.append(line);flush();kind=None;fence=False
  else:
   flush();fence=True;start=no;kind='code';buf=[line]
  continue
 if fence:buf.append(line);continue
 if not line.strip() or line.strip()=='---':flush();continue
 newkind='table' if line.startswith('|') else 'item' if re.match(r'^(?:- |\d+\. )',line) else 'paragraph'
 if buf and (newkind in ['table','item'] or newkind!=kind):flush()
 if not buf:start=no;kind=newkind
 buf.append(line)
flush();assert not fence
# Verify every nonblank body line belongs to exactly one block. Headings and
# horizontal rules are navigation, not omitted body text; fenced contents count.
covered=collections.Counter(n for b in blocks for n in range(b['line'],b['end_line']+1))
assert all(v==1 for v in covered.values())
for no,line in enumerate(lines,1):
 if line.strip() and not line.startswith('#') and line.strip()!='---':assert covered[no]==1,(no,line)

def normalize(text):
 text=re.sub(r'^- (?:\[ \] )?|^\d+\. ','',text)
 text=re.sub(r'^\*\*Gate F\d+:\*\*\s*','',text)
 return ' '.join(text.split())
paths=['phase-audit.json','test-layer-audit.json','core-contract-audit.json','integration-contract-audit.json','acceptance-audit.json','invariant-audit.json','../qualification/nested-ergonomics.json']
lookup=collections.defaultdict(list);evidence={}
def walk(value,path,source):
 if isinstance(value,dict):
  if isinstance(value.get('requirement'),str):
   lookup[normalize(value['requirement'])].append({'file':source,'pointer':path,'scope_status':value.get('status','see_scoped_assessment')})
  for key,item in value.items():walk(item,path+'/'+key,source)
 elif isinstance(value,list):
  for i,item in enumerate(value):walk(item,path+'/'+str(i),source)
for name in paths:
 p=directory/name;data=p.read_bytes();j=json.loads(data);evidence[name]=sha(data)
 if 'plan_sha256' in j:assert j['plan_sha256']==sha(raw),name
 walk(j,'',name)
 if name=='phase-audit.json':
  for i,phase in enumerate(j['phases']):
   lookup[normalize(phase['gate'])].append({'file':name,'pointer':'/phases/'+str(i)+'/gate_disposition','scope_status':'see_scoped_gate_disposition'})
# Preserve table invariant matches as partial row references: the original row
# also specifies owner/failure behavior, not only the invariant title.
inv=json.loads((directory/'invariant-audit.json').read_text())['invariants']
for b in blocks:
 refs=list(lookup.get(normalize(b['text']),[]))
 if b['section']=='10. Cross-cutting correctness and security contract' and b['kind']=='table':
  cells=[c.strip() for c in b['text'].split('|')[1:-1]]
  for i,item in enumerate(inv):
   if cells and normalize(cells[0])==normalize(item['requirement']):refs.append({'file':'invariant-audit.json','pointer':'/invariants/'+str(i),'scope_status':'invariant_audit_row_requires_full_owner_and_failure_review'})
 text=b.pop('text');b['sha256']=sha(text.encode());b['preview']=text[:110]
 b['evidence']=refs
 if re.fullmatch(r'\|[ :|\-]+',text):b['review_state']='table_layout'
 elif b['section'].startswith('17.'):b['review_state']='historical_source_reference'
 elif b['section'].startswith('15.') and b['kind']=='table':b['review_state']='advisory_pr_breakdown'
 elif text in ['Work:','**Work:**','Required properties:','The conceptual layers are:','Keep these dependency boundaries:','Acceptance criteria:','All these acceptance conditions must hold:','**Unit / model checks**','**Property-based / model-based**','**Fuzzing**','**Concurrency and crash**','**Compatibility**','**Portable and architecture**','**Provisional gates** (approve in F0 after real baseline measurements):','Recommended workload matrix:']:
  b['review_state']='section_label'
 else:b['review_state']='scoped_evidence_indexed' if refs else 'needs_individual_review'
# Explicit positional mapping for the seven maintenance bullets: source audit
# uses clarified wording, so do not silently pretend it was an exact text match.
maintenance=[b for b in blocks if b['section'].startswith('13.3 ') and b['kind']=='item']
criteria=json.loads((directory/'acceptance-audit.json').read_text())['criteria'];assert len(maintenance)==len(criteria)==7
for i,b in enumerate(maintenance):
 ref={'file':'acceptance-audit.json','pointer':'/criteria/'+str(i),'scope_status':'positional_seven_criterion_review_not_exact_text_match'}
 if ref not in b['evidence']:b['evidence'].append(ref)
 b['review_state']='scoped_evidence_indexed'
# Individually reviewed deployment clauses, with current CI observations and
# exact current source identities. Operational duties remain host obligations.
source='c8fda4c994cdcdda075d09648e502a0aa4fe1775'
import subprocess
ci_log=Path('/tmp/penelope-050-final-ci.log').read_text()
checkpoint=json.loads((directory/'../qualification/current-package-checkpoint.json').read_text())
assert checkpoint['source_commit']==source
log_member='drivers-and-logs/penelope-050-final-ci.log'
assert sha(ci_log.encode())==checkpoint['archive']['members_sha256'][log_member]
manual_sources=['docs/0.5/compatibility-matrix.md','docs/reliable-execution-operations.md','scripts/check-sqlite-upgrade.py','ci/sqlite-upgrade/main.rs','crates/penelope-sqlite/src/schema.rs','crates/penelope-sqlite/src/machine.rs','crates/penelope-core/src/task/control.rs','crates/penelope-core/src/task/runtime.rs','crates/penelope-executor/src/task.rs','crates/penelope-ports/src/machine/recovery.rs']
manual_hashes={}
for name in manual_sources:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',source+':'+name],cwd=root);manual_hashes[name]=sha(data)
for name in ['crates/penelope-core/src/task/control.rs','crates/penelope-core/src/task/runtime.rs','crates/penelope-executor/src/task.rs']:
 assert (root/name).read_bytes()==subprocess.check_output(['git','show','42ec187:'+name],cwd=root)
observed=['preparation_matches_frozen_record_validation_and_supervisory_decisions','sigkill_at_schema_migration_boundaries_preserves_records_blobs_and_fences','sigkill_v7_outbox_migration_preserves_populated_machine_journal','sigkill_v8_receiver_migration_preserves_pending_uncertainty_and_accepted_receipts','conflicting_genesis_scope_count_and_exact_scope_bytes_keep_existing_state','every_truncation_mutation_and_trailing_byte_fails_closed']
for job in ['Stable verification','Minimum supported Rust']:
 for expected in ['Upgrade/reopen 1: exact legacy rows, replay and integrity retained','Upgrade/reopen 2: exact legacy rows, replay and integrity retained','Actual 0.4 writer fixture: 15 legacy tables verified']:
  assert any(line.startswith(job+'\tRun python3 scripts/check-sqlite-upgrade.py\t') and line.endswith(expected) for line in ci_log.splitlines()),(job,expected)
 for name in observed:
  assert any(line.startswith(job+'\t') and re.search(r'\btest (?:\S+::)?'+re.escape(name)+r' \.\.\. ok(?:\s|$)',line) for line in ci_log.splitlines()),(job,name)
reviews={
861:'No history conversion is required. The actual0.4-writer fixture preserves all15 legacy table schemas, rows and exact native replay across upgrade and two reopens on both compilers. This bounded fixture is not every deployment.',
862:'Canonical saga/task inspection delegates to the native replay/validation paths; frozen compatibility observations and the old-writer upgrade check retain old record interpretation. No fake machine history is persisted for legacy records.',
863:'Forward-only transactional schema6-to9 upgrade preserves legacy tables. Both compilers observe schema-migration SIGKILL tests, plus populated v7/v8 machine migration recovery. These are process-death cases, not hardware power-loss certification.',
864:'TaskControl, portable runtime contracts and hosted supervisor source are byte-identical to original42ec187. Machine-generated native admission requires explicit use of the new receiver. The prepared-task differential test also passes on both compilers.',
865:'New machine scope pins the definition/schema; mismatched genesis or scope is refused, and replay requires the pinned model/codec. No automatic state/history migration service exists: authenticated transformation and executable availability remain explicit host obligations before changing interpretation.',
866:'Machine wire has an independent tag and tables. Strict mutation decoding refuses unsupported bytes; the retained old-binary upgrade/rollback experiment refuses schema9 without changing it. The deployment guide forbids mixed adapters and requires quiesced rollout. No capability negotiation service is promised.',
867:'Compatibility and operations guides require a quiesced schema6 backup, pinned old deployment, isolated validation and separate restore. They explicitly refuse automatic downgrade or manual user_version changes; external work requires reconciliation. This is a documented operating procedure, not proof that a production operator performed it.'}
assert set(reviews)=={861,862,863,864,865,866,867}
# The earlier old-binary refusal/restore experiment remains independently scoped.
rollback_path=directory/'../sqlite-upgrade/manifest.json';rollback=json.loads(rollback_path.read_text());evidence['../sqlite-upgrade/manifest.json']=sha(rollback_path.read_bytes())
for row in rollback['checks']:
 path=rollback_path.parent/row['log'];data=path.read_bytes();assert sha(data)==row['gzip_sha256'];assert sha(gzip.decompress(data))==row['raw_sha256']
assert any('Original baseline sqlite-upgrade read/refuse' in row['command'] and row['exit_code']==0 for row in rollback['checks'])
evidence['../qualification/current-package-checkpoint.json']=sha((directory/'../qualification/current-package-checkpoint.json').read_bytes())
for b in blocks:
 if b['line'] in reviews:
  assert b['section'].startswith('12.2 ') and b['kind']=='item'
  b['assessment']=reviews[b['line']];b['review_state']='individually_reviewed_scoped_support'
  b['evidence']+=[{'file':'../qualification/current-package-checkpoint.json','pointer':'/ci','scope_status':'current_ci_observations_checked'},{'file':'../sqlite-upgrade/manifest.json','pointer':'/rollback_steps','scope_status':'original_binary_refusal_and_separate_restore_experiment'}]
assert sum(b['review_state']=='individually_reviewed_scoped_support' for b in blocks)==7
# A later local ergonomic example is scoped separately from the c8 deployment review.
door_path=directory/'../qualification/door-ergonomics.json'
door=json.loads(door_path.read_text())
for name,digest in door['source_sha256'].items():assert sha((root/name).read_bytes())==digest
assert all(c['exit_code']==0 for c in door['checks'])
assert len(door['negative_controls'])==4 and all(c['compiled_and_rejected_by_runtime_oracle'] for c in door['negative_controls'])
evidence['../qualification/door-ergonomics.json']=sha(door_path.read_bytes())
door_package=directory/'../qualification/door-package-checkpoint.json'
evidence['../qualification/door-package-checkpoint.json']=sha(door_package.read_bytes())
for b in blocks:
 if b['section'].startswith('9.1 '):
  b['evidence'].append({'file':'../qualification/door-ergonomics.json','pointer':'/scope','scope_status':'local_example_followup_separately_reconciled_at_c0e9997'})
  b['evidence'].append({'file':'../qualification/door-package-checkpoint.json','pointer':'/ci','scope_status':'all_ten_archives_and_seven_CI_jobs_at_c0e9997'})
  b['assessment']='The runnable door example uses the actual API and covers enum-local data, accepted edges, guard refusals and unhandled decisions. It retains explicit local fixture metadata and stages no effects. The separate counter/durable examples cover effects; this link does not certify every clause in this block. The separate c0e9997 checkpoint qualifies all ten archives and source CI; later signature changes retain a separate scope.'
result={'scope':'Full source-plan block inventory for remaining review. Includes prose, every list/table row and all13 fenced examples/diagrams. Blocks are not atomic semantic requirements: one paragraph can impose several obligations. Indexed evidence retains its own revision and limits; no block is certified complete by matching text.','plan':'../../plan.md','plan_sha256':sha(raw),'line_count':len(lines),'manual_source_commit':source,'manual_source_sha256':manual_hashes,'manual_ci_named_tests':observed,'counts':{'blocks':len(blocks),'by_kind':dict(collections.Counter(b['kind'] for b in blocks)),'by_review_state':dict(collections.Counter(b['review_state'] for b in blocks))},'evidence_sha256':evidence,'blocks':blocks,'limits':['This is a navigation/review inventory, not a new test, guarantee, semantic completeness proof or release qualification.','Every remaining normative clause must still be assessed against current source and adequately scoped evidence; a link or matching heading does not establish completion.','Historical references and advisory PR breakdown remain present and distinct from release deliverables.','Existing audit statuses are preserved, including performance, campaign, historical sequencing and publication obligations.','Plan examples marked as illustrative/pseudocode need semantic review; they are not silently treated as literal public signatures.'],'generator':'plan-review-index.py.gz'}
(directory/'plan-review-index.json').write_text(json.dumps(result,indent=2)+'\n');(directory/'plan-review-index.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print(json.dumps(result['counts']))
