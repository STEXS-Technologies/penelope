import json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/.penelope-inherited-probe');out=Path('/tmp/penelope-inherited-v2-qualification-followup');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/ac/projects/penelope/target/inherited-probe','PROPTEST_CASES':'10000','PROPTEST_RNG_SEED':'2'};checks=[]
commands=[('msrv-tests',['cargo','+1.89.0','test','-p','penelope-timeline','--all-features','--lib','--tests','--locked']),('clippy',['cargo','+1.100.0','clippy','-p','penelope-timeline','--all-targets','--all-features','--locked','--','-D','warnings']),('format',['cargo','+1.100.0','fmt','--all','--','--check']),('diff',['git','diff','--check'])]
for v in ['1.100.0','1.89.0']:
 for f in [None,'alloc']:
  a=['cargo','+'+v,'check','-p','penelope-timeline','--no-default-features','--target','riscv32imafc-unknown-none-elf','--locked'];a+=['--features',f] if f else [];commands.append(('portable-'+v+'-'+str(f),a))
commands=[(label,args) for label,args in commands if label not in ['msrv-tests','clippy']]
for label,args in commands:
 print(label,flush=True);start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(label+'.'+suffix)).write_text(text)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');r.check_returncode()
print('completed',flush=True)
