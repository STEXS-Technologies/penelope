import hashlib,io,json,os,runpy,shutil,subprocess,tarfile,time
from pathlib import Path
repo=Path('/home/ac/projects/penelope');probe=Path('/home/ac/projects/.penelope-inherited-probe');out=Path('/tmp/penelope-inherited-v2-perf');out.mkdir(exist_ok=False)
builds=repo/'target/inherited-v2-builds';builds.mkdir(exist_ok=False)
module=runpy.run_path(str(repo/'scripts/benchmark-decision-comparison.py'))
source='be774e678e7d982b337bf3925b4f88632c90103b';path='crates/penelope-timeline/src/history.rs'
selected={'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','PENELOPE_TIMELINE_SAMPLES':'1000'};os.environ.update(selected)
meta={'base_revision':source,'environment_overrides':selected,'cases':{},'runs':12,'warmups_per_case':1,'order':'rotate original/retained/previous/probe by one position each round','cpu':4,'toolchain':'1.100.0','scope':'Diagnostic full frozen timeline fixture, 640 profiles, all raw records retained; no equivalence or acceptance claim.'}
(out/'source.patch').write_text(subprocess.check_output(['git','diff','--',path],cwd=probe,text=True));(out/'history-probe.rs').write_bytes((probe/path).read_bytes())
binaries={name:Path('/tmp/penelope-050-legacy-paired/binaries')/label/'timeline_operations' for name,label in [('original','before'),('retained','after')]}
binaries['previous']=Path('/tmp/penelope-inherited-probe-perf/probe.bin')
for label in ['probe']:
 snapshot=builds/label;snapshot.mkdir();archive=subprocess.check_output(['git','archive',source],cwd=repo)
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter='data')
 if label=='probe':shutil.copy2(probe/path,snapshot/path)
 print('build-'+label,flush=True);start=time.monotonic();r=subprocess.run(['cargo','+1.100.0','bench','-p','penelope-timeline','--bench','timeline_operations','--no-run','--locked','--message-format=json','--target-dir',str(snapshot/'target')],cwd=snapshot,capture_output=True,text=True)
 (out/('build-'+label+'.stdout')).write_text(r.stdout);(out/('build-'+label+'.stderr')).write_text(r.stderr);r.check_returncode();records=[json.loads(l) for l in r.stdout.splitlines()];artifacts=[a for a in records if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='timeline_operations' and a.get('executable')];assert len(artifacts)==1
 binaries[label]=Path(artifacts[0]['executable']);meta['cases'][label]={'build_seconds':time.monotonic()-start,'history_sha256':hashlib.sha256((snapshot/path).read_bytes()).hexdigest()}
 fixture=[snapshot/'crates/penelope-timeline/benches/timeline_operations.rs',*sorted((snapshot/'crates/penelope-timeline/benches/support').glob('*.rs'))]
 meta['cases'][label]['fixture_sha256']={str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in fixture}
reference=json.loads(Path('/tmp/penelope-inherited-probe-perf/metadata.json').read_text())
assert reference['cases']['rebuilt']['fixture_sha256']==meta['cases']['probe']['fixture_sha256']
for label,binary in list(binaries.items()):
 destination=out/(label+'.bin');shutil.copy2(binary,destination);binaries[label]=destination;meta['cases'].setdefault(label,{})['binary_sha256']=hashlib.sha256(destination.read_bytes()).hexdigest()
meta['cases']['original']['revision']='42ec187c9adfc7403b06215f405f2575f53c35c2';meta['cases']['retained']['revision']=source
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
order=list(binaries)
for index in range(13):
 rotated=order[index%4:]+order[:index%4]
 for label in rotated:
  start=time.monotonic();r=subprocess.run(['taskset','-c','4',str(binaries[label])],cwd=out,capture_output=True,text=True);(out/f'run-{index}-{label}.stdout').write_text(r.stdout);(out/f'run-{index}-{label}.stderr').write_text(r.stderr);r.check_returncode();observations=module['timeline_observations'](r.stdout);assert len(observations)==640
  (out/f'run-{index}-{label}.json').write_text(json.dumps({'label':label,'round':index,'warmup':index==0,'seconds':time.monotonic()-start,'observations':observations},indent=2)+'\n');print(index,label,flush=True)
print('completed',flush=True)
