import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/penelope/target/050-public-api-audit/after');out=Path('/tmp/penelope-050-public-api-audit');source=root/'crates/penelope/src/lib.rs';original=source.read_text();needle='pub use task::TaskSupervisor;';assert original.count(needle)==1
checks=[];env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root.parent/'target-after')}
args=['taskset','-c','24-27','cargo','+1.100.0','check','--manifest-path',str(root/'ci/compat-0.4/Cargo.toml'),'--all-features','--lib','--locked']
def run(label):
 start=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(label+'.'+suffix)).write_text(text)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'legacy-import-control-checks.json').write_text(json.dumps(checks,indent=2)+'\n');return r
try:
 source.write_text(original.replace(needle,'// Negative control: remove the legacy root TaskSupervisor reexport.'));(out/'negative-facade-lib.rs').write_text(source.read_text());r=run('negative-legacy-import');assert r.returncode==101 and 'TaskSupervisor' in r.stderr and 'unresolved import' in r.stderr
finally:
 source.write_text(original)
r=run('restored-legacy-import');assert r.returncode==0
(out/'legacy-import-control.json').write_text(json.dumps({'mutation_caught_by_unchanged_consumer':True,'restored_positive_pass':True,'restored_facade_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n');print('frozen legacy import fixture catches removed root reexport; restored source passes',flush=True)
