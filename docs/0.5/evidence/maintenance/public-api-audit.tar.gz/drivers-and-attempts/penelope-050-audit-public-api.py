import concurrent.futures,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/penelope/target/050-public-api-audit');out=Path('/tmp/penelope-050-public-api-audit');out.mkdir(exist_ok=False)
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTC_BOOTSTRAP':'1','CARGO_BUILD_JOBS':'2'}
checks=[];lock_hashes={label:{str(p.relative_to(root/label)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/label).rglob('Cargo.lock')} for label in ['before','after']}
packages=['penelope-core','penelope-domain','penelope-intent','penelope-ports','penelope-executor','penelope-statechronicle','penelope-sqlite','penelope-process-runtime','penelope-timeline','penelope']
profiles=[(p,'default',[]) for p in packages]+[('penelope-core','serde',['--features','serde']),('penelope-timeline','alloc',['--features','alloc']),('penelope-timeline','std',['--all-features']),('penelope','timeline',['--features','timeline'])]
metadata={'before':'42ec187c9adfc7403b06215f405f2575f53c35c2','after':subprocess.check_output(['git','rev-parse','0f01d24'],cwd='/home/ac/projects/penelope',text=True).strip(),'toolchain':'1.100.0','target':'x86_64-unknown-linux-gnu','environment_overrides':{k:env[k] for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC_BOOTSTRAP','CARGO_BUILD_JOBS']},'tool_version':subprocess.check_output(['cargo','semver-checks','--version'],text=True).strip(),'release_type_override':'patch, so a0.4→0.5 version change cannot suppress breaking-change diagnostics','lock_hashes_before':lock_hashes,'profiles':[]}
def command(label,args,cwd,environment):
 start=time.monotonic();r=subprocess.run(args,cwd=cwd,env=environment,capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(label+'.'+suffix)).write_text(text)
 return {'label':label,'args':args,'cwd':str(cwd),'exit_code':r.returncode,'seconds':time.monotonic()-start}
def save():
 (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
def document(label,package,profile,features):
 target=root/('target-'+label);environment={**env,'CARGO_TARGET_DIR':str(target)}
 args=['taskset','-c','24-27' if label=='before' else '28-31','cargo','+1.100.0','rustdoc','-p',package,'--lib','--locked',*features,'--','-Z','unstable-options','--output-format','json']
 result=command(label+'-'+package+'-'+profile,args,root/label,environment)
 if result['exit_code']==0:
  source=target/'doc'/(package.replace('-','_')+'.json');destination=out/(label+'-'+package+'-'+profile+'.json');shutil.copyfile(source,destination);result['rustdoc_sha256']=hashlib.sha256(destination.read_bytes()).hexdigest();result['rustdoc_format_version']=json.loads(destination.read_text())['format_version']
 return result
for package,profile,features in profiles:
 print(package,profile,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  results=list(pool.map(lambda label:document(label,package,profile,features),['before','after']))
 checks.extend(results);save();assert all(r['exit_code']==0 for r in results),results
 args=['taskset','-c','24-27','cargo','semver-checks','check-release','--manifest-path',str(root/'after/Cargo.toml'),'-p',package,'--current-rustdoc',str(out/('after-'+package+'-'+profile+'.json')),'--baseline-rustdoc',str(out/('before-'+package+'-'+profile+'.json')),'--release-type','patch']
 r=command('compare-'+package+'-'+profile,args,root/'after',env);checks.append(r);metadata['profiles'].append({'package':package,'profile':profile,'features':features,'compare_exit_code':r['exit_code']});save()
 # Retain violations without stopping other independent package profiles.
source=root/'after/crates/penelope/src/lib.rs';original=source.read_text();needle='pub use task::TaskSupervisor;';assert original.count(needle)==1
try:
 source.write_text(original.replace(needle,'// Negative control: remove the legacy root TaskSupervisor reexport.'))
 r=document('after','penelope','removed-root-export',[]);checks.append(r);save();assert r['exit_code']==0
 args=['taskset','-c','24-27','cargo','semver-checks','check-release','--manifest-path',str(root/'after/Cargo.toml'),'-p','penelope','--current-rustdoc',str(out/'after-penelope-removed-root-export.json'),'--baseline-rustdoc',str(out/'before-penelope-default.json'),'--release-type','patch']
 r=command('negative-removed-root-export',args,root/'after',env);checks.append(r);save();text=(out/'negative-removed-root-export.stdout').read_text()+(out/'negative-removed-root-export.stderr').read_text();assert r['exit_code']!=0 and 'TaskSupervisor' in text and ('FAIL' in text or 'semver' in text)
finally:
 source.write_text(original);metadata['restored_facade_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();save()
metadata['lock_hashes_after']={label:{str(p.relative_to(root/label)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/label).rglob('Cargo.lock')} for label in ['before','after']};assert metadata['lock_hashes_after']==lock_hashes
metadata['complete']=True;metadata['all_positive_profiles_pass']=all(p['compare_exit_code']==0 for p in metadata['profiles']);save();print('completed; positive_profiles_pass='+str(metadata['all_positive_profiles_pass']),flush=True)
