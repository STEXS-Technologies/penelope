import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/penelope/target/050-public-api-audit');out=Path('/tmp/penelope-050-public-api-audit');env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTC_BOOTSTRAP':'1','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target-after')};checks=[]
def run(label,args):
 start=time.monotonic();r=subprocess.run(args,cwd=root/'after',env=env,capture_output=True,text=True)
 for suffix,text in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(label+'.'+suffix)).write_text(text)
 checks.append({'label':label,'args':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'controls-checks.json').write_text(json.dumps(checks,indent=2)+'\n');return r
source=root/'after/crates/penelope-core/src/task/contracts.rs';original=source.read_text();needle='    pub task: TaskId,';assert original.count(needle)==1
try:
 source.write_text(original.replace(needle,'    pub(crate) task: TaskId,'));(out/'negative-core-task-scope.rs').write_text(source.read_text())
 r=run('negative-core-document',['taskset','-c','24-27','cargo','+1.100.0','rustdoc','-p','penelope-core','--lib','--locked','--','-Z','unstable-options','--output-format','json']);assert r.returncode==0
 shutil.copyfile(root/'target-after/doc/penelope_core.json',out/'after-core-private-task-field.json')
 r=run('negative-core-compare',['taskset','-c','24-27','cargo','semver-checks','check-release','--manifest-path',str(root/'after/Cargo.toml'),'-p','penelope-core','--current-rustdoc',str(out/'after-core-private-task-field.json'),'--baseline-rustdoc',str(out/'before-penelope-core-default.json'),'--release-type','patch'])
 (out/'negative-core-control.json').write_text(json.dumps({'semver_checks_detected':r.returncode!=0,'exit_code':r.returncode,'expected_broken_path':'penelope_core::task::TaskScope::task'},indent=2)+'\n')
 assert r.returncode!=0 and 'TaskScope' in r.stdout+r.stderr
finally:
 source.write_text(original);(out/'restored-core-sha256.txt').write_text(hashlib.sha256(source.read_bytes()).hexdigest()+'\n')
metadata=json.loads((out/'metadata.json').read_text());locks={label:{str(p.relative_to(root/label)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/label).rglob('Cargo.lock')} for label in ['before','after']};assert locks==metadata['lock_hashes_before']
followup={'lock_hashes_after':locks,'all_locks_unchanged':True,'all14_positive_comparisons_pass':all(x['compare_exit_code']==0 for x in metadata['profiles']),'initial_driver_exit_code':1,'initial_failure':'Negative control removing root TaskSupervisor reexport was missed by semver-checks; original failure retained. Independent binding inventory diagnoses this coverage limit.','restored_core_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'restored_facade_sha256':hashlib.sha256((root/'after/crates/penelope/src/lib.rs').read_bytes()).hexdigest()}
(out/'followup.json').write_text(json.dumps(followup,indent=2)+'\n');print('local public field removal caught; sources restored; locks unchanged',flush=True)
