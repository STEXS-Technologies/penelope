"""Compare resolved public Penelope export bindings using locked rustdoc snapshots.

This supplements semver-checks' local-item/signature analysis. It does not compare
signatures or expand third-party crates. Any unresolved Penelope binding or cycle
is reported, never silently accepted as complete coverage.
"""
import hashlib,json
from pathlib import Path
out=Path('/tmp/penelope-050-public-api-audit')
packages=['penelope-core','penelope-domain','penelope-intent','penelope-ports','penelope-executor','penelope-statechronicle','penelope-sqlite','penelope-process-runtime','penelope-timeline','penelope']

def inventory(label,package,profile='default'):
 docs={p.replace('-','_'):json.loads((out/(label+'-'+p+'-default.json')).read_text()) for p in packages}
 doc=json.loads((out/(label+'-'+package+'-'+profile+'.json')).read_text());docs[package.replace('-','_')]=doc
 indices={name:{tuple(v['path']):str(k) for k,v in d['paths'].items() if v['path'][0]==name and str(k) in d['index']} for name,d in docs.items()}
 result={};unresolved=[];cycles=[]
 def resolve(name,identifier):
  identifier=str(identifier);d=docs[name];canonical=d['paths'].get(identifier)
  if canonical and canonical['path'][0] in docs:
   target=canonical['path'][0];found=indices[target].get(tuple(canonical['path']))
   if found is not None:return target,found,canonical
  if identifier in d['index'] and d['index'][identifier]['crate_id']==0:return name,identifier,canonical
  return None,None,canonical
 def visit(name,identifier,path,active=(),force=False,container=True):
  identifier=str(identifier);identity=(name,identifier)
  if identity in active:
   cycles.append({'path':path,'target':identity});return
  if len(path)>32:raise ValueError('unexpected export depth')
  d=docs[name];item=d['index'].get(identifier)
  if item is None:
   unresolved.append({'path':path,'crate':name,'id':identifier});return
  if item['visibility']!='public' and identifier!=str(d['root']) and not force:return
  kind,value=next(iter(item['inner'].items()))
  if kind=='use':
   target= value['id'];n,i,c=resolve(name,target)
   if value['is_glob']:
    if n is None:
     unresolved.append({'path':path,'source':value['source'],'canonical':c});return
    visit(n,i,path,active+(identity,),force=True,container=False);return
   path=path+[value['name']]
   if n is not None:
    visit(n,i,path,active+(identity,),force=True);return
   if c is not None and c['path'][0] not in docs:
    result['::'.join(path)]={'kind':c['kind'],'definition':'::'.join(c['path']),'third_party_opaque':True};return
   unresolved.append({'path':path,'source':value['source'],'canonical':c});return
  c=d['paths'].get(identifier)
  definition='::'.join(c['path']) if c else name+'::'+str(item['name'])
  if container:result['::'.join(path)]={'kind':kind,'definition':definition}
  if kind=='module':
   for child in value['items']:
    child= str(child);v=d['index'].get(child)
    if v is None:
     unresolved.append({'path':path,'crate':name,'id':child});continue
    subkind=next(iter(v['inner']))
    visit(name,child,path if subkind=='use' else path+[v['name']],active+(identity,))
 visit(package.replace('-','_'),doc['root'],[package.replace('-','_')])
 return {'bindings':result,'unresolved':unresolved,'cycles':cycles}

profiles=[(p,'default') for p in packages]+[('penelope-core','serde'),('penelope-timeline','alloc'),('penelope-timeline','std'),('penelope','timeline')]
records=[]
for package,profile in profiles:
 before=inventory('before',package,profile);after=inventory('after',package,profile)
 changes={key:{'before':v,'after':after['bindings'].get(key)} for key,v in before['bindings'].items() if after['bindings'].get(key)!=v and not (v['kind']=='module' and after['bindings'].get(key,{}).get('kind')=='module')}
 module_moves={key:{'before':v,'after':after['bindings'][key]} for key,v in before['bindings'].items() if v['kind']=='module' and after['bindings'].get(key,{}).get('kind')=='module' and after['bindings'][key]!=v}
 r={'package':package,'profile':profile,'before':before,'after':after,'removed_or_rebound':changes,'module_owner_changes':module_moves};records.append(r)
 print(package,profile,'bindings',len(before['bindings']),len(after['bindings']),'changes',len(changes),'unresolved',len(before['unresolved']),len(after['unresolved']),'cycles',len(before['cycles']),len(after['cycles']),flush=True)
negative=inventory('after','penelope','removed-root-export');baseline=inventory('before','penelope');missing=set(baseline['bindings'])-set(negative['bindings']);assert 'penelope::TaskSupervisor' in missing
summary={'scope':'Resolved public module/item export bindings in the ten Penelope crates under14 profiles. Does not expand type members, signatures, trait impls or third-party modules; semver-checks supplies its separately documented local-item checks.','profiles':records,'negative_control':{'mutation':'Remove only legacy pub use task::TaskSupervisor from the facade snapshot.','semver_checks_detected':False,'export_inventory_detected':True,'missing_bindings':sorted(missing),'inventory':negative},'all_positive_bindings_preserved':all(not r['removed_or_rebound'] for r in records),'all_penelope_bindings_resolved':all(not x['unresolved'] and not x['cycles'] for r in records for x in [r['before'],r['after']])}
(out/'reexports.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['profiles','negative_control']})
