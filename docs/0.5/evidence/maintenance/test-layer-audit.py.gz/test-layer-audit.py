import hashlib,json,re,subprocess,collections,tarfile
from pathlib import Path
root=Path('/home/ac/projects/.penelope-050-candidate');plan=root/'docs/0.5/plan.md';text=plan.read_text();sha=lambda b:hashlib.sha256(b).hexdigest();records={}
def test(path,name):
 key=name;p=root/path;s=p.read_text();assert re.search(r'\bfn\s+'+re.escape(name)+r'\s*\(',s),(path,name)
 scope='repeated-kill' if path.endswith('/src/machine/tests.rs') else 'extracted-ce93ff8';logs=[]
 for version in ['1.100.0','1.89.0']:
  log=(Path('/tmp/penelope-050-repeated-kill-qualified')/('machine-tests-'+version+'.stdout')) if scope=='repeated-kill' else (Path('/tmp/penelope-050-history-partition-packaged-workspace-followup')/('tests-'+version+'.stdout'))
  content=log.read_text();assert re.search(r'\btest (?:[A-Za-z_0-9]+::)*'+re.escape(name)+r' \.\.\. ok',content),(path,name,version)
  logs.append({'compiler':version,'sha256':sha(log.read_bytes()),'checkpoint':'../qualification/repeated-machine-kill.json' if scope=='repeated-kill' else '../qualification/history-partition-checkpoint.json'})
 if scope=='extracted-ce93ff8':assert subprocess.check_output(['git','show','ce93ff8:'+path],cwd=root)==p.read_bytes(),path
 records[key]={'source':path,'source_sha256':sha(p.read_bytes()),'function':name,'passing_observations':logs};return key
core='crates/penelope-core/tests/';ports='crates/penelope-ports/tests/';sqlite='crates/penelope-sqlite/tests/';executor='crates/penelope-executor/tests/';timeline='crates/penelope-timeline/tests/'
def t(prefix,file,name):return test(prefix+file+'.rs',name)
refs={
 'flat':t(core,'machine','decisions_prepare_without_publishing_and_drop_aborts'),
 'bounds':t(core,'machine','scope_model_stale_head_pending_duplicates_and_budgets_fail_closed'),
 'faults':t(core,'machine','ignored_staging_errors_validation_and_panics_preserve_the_entire_publication'),
 'destructor':t(core,'machine','superseded_state_drop_panics_only_after_all_published_values_agree'),
 'provenance':t(core,'machine','publication_retains_prior_intents_and_their_exact_origins_until_taken'),
 'hsm':t(core,'machine_hierarchy','leaf_to_parent_selection_and_lca_exit_action_entry_order_are_exact'),
 'hsmrefusal':t(core,'machine_hierarchy','rejection_and_fault_are_terminal_but_unhandled_walks_the_entire_path'),
 'self':t(core,'machine_hierarchy','internal_and_external_self_transitions_are_distinct'),
 'paths':t(core,'machine_hierarchy','malformed_or_exhausted_paths_fail_before_any_handler'),
 'generated':t(core,'generated_machines','generated_tables_and_hierarchies_match_reference_and_single_level_flat_dispatch'),
 'wire':t(core,'machine_wire','independent_goldens_bind_endianness_causation_order_and_full_width_counters'),
 'wiremut':t(core,'machine_wire','every_truncation_mutation_and_trailing_byte_fails_closed'),
 'nonclone':t(ports,'machine_preparation','accepted_non_clone_state_retains_exact_bytes_and_only_publishes_after_matching_receipt'),
 'receipt':t(ports,'machine_preparation','drop_and_every_receipt_coordinate_substitution_abort_local_publication'),
 'restore':t(ports,'machine_preparation','snapshot_restore_refuses_scope_codec_lossy_decoding_and_model_invariant_substitution'),
 'payload':t(ports,'machine_preparation','recovery_refuses_every_payload_byte_substitution_and_all_payload_count_errors'),
 'cas':t(sqlite,'machines','competing_heads_conflicting_event_and_wrong_predecessor_leave_exact_state'),
 'writers':t(sqlite,'machines','simultaneous_independent_workers_admit_one_competing_head'),
 'readers':t(sqlite,'machines','concurrent_reader_sees_one_coherent_state_head_receipt_tuple'),
 'pages':t(sqlite,'machines','every_small_history_partition_recovers_exact_records_across_reopens_and_refuses_a_gap'),
 'ack':t(sqlite,'machines','lost_ack_reopen_exact_duplicate_and_pending_payload_recovery'),
 'uncertain':t(sqlite,'machine_outbox','claim_is_source_bound_and_reopen_preserves_uncertainty_and_fencing'),
 'killedchain':test('crates/penelope-sqlite/src/machine/tests.rs','repeated_sigkill_on_a_growing_journal_preserves_every_prefix_and_exact_retry'),
 'result':t(executor,'task_verified_result','effectful_completion_requires_matching_independent_evidence'),
 'poison':t(executor,'task_control','ambiguous_commit_poisoning_matches_hosted_profile'),
 'reconcile':t(executor,'task_control_failures','invalid_reconciliation_preserves_state_and_unknown_cannot_dispatch'),
 'taskprepare':test('crates/penelope/tests/prepared_lifecycles.rs','task_prepared_history_is_not_applied_until_the_native_owner_admits_it'),
 'timeline':t(timeline,'machine','corrected_replay_uses_captured_context_and_existing_finality_and_handoff'),
 'signed':test('crates/penelope-statechronicle/tests/task_checkpoint.rs','returned_evidence_must_match_every_scope_generation_and_blob_coordinate')}
# List every clause in section13.1 in order. Passing names prove only the stated fixture scope.
review=[
('named_checks','flat bounds','Flat accepted/rejected/unhandled and terminal revision behavior are checked; application predicates remain consumer code.'),
('named_checks','hsm hsmrefusal self paths','Explicit tree-model tests cover selection/hook/depth semantics; generated tables add varied bounded forests.'),
('named_checks','nonclone flat','Typed non-Clone state and exclusive consuming owner are checked. Core compile-fail doctests separately cover identity/borrow misuse; arbitrary interior aliases remain unsupported.'),
('named_checks','faults destructor bounds','Failure, byte/count/revision bounds, poison and destructor-unwind publication are checked with typed state/head/intent assertions.'),
('named_checks','provenance generated','Typed exact record/origin comparisons do not depend on diagnostic formatting.'),
('named_checks','generated','512 deterministic generated streams and varied table/parent inputs compare to a separate oracle; augmented fuzz varies those inputs further.'),
('named_checks','generated provenance','Generated accepted-sequence replay compares exact states/revisions/records/intents under pinned tables and contexts; callback determinism is not enforced by Rust.'),
('named_checks','cas ack bounds','Historical deduplication is a journal guarantee. MemoryMachine intentionally does not retain a durable event-ID index.'),
('named_checks','generated','The generated fixture compares one-level Hierarchical dispatch directly against its flat table model.'),
('named_checks','pages','All256 small-history partitions under both count/byte limits, reopened readers and a missing revision are checked. This is exhaustive for nine captured records, not arbitrary-length histories.'),
('campaign_open','wire wiremut payload','Wire raw/structured mutation and preparation fuzz targets exist; independent fixtures and unit substitution checks pass. Full current-production fuzz campaign is live.'),
('supplementary_fuzz_pass_full_campaign_open','generated faults paths','Augmented fuzz_machine completes three100k rounds with generated guards/paths/capacities; full multi-target campaign remains separate and live.'),
('partial_fuzz_replay_review_required','cas restore receipt payload generated','Unit checks cover scope/definition/digest substitution, ordering and exact recovery. Existing fuzz receipt substitutions and raw parser mutation do not establish a targeted replay oracle for every listed field/order combination; inspect and strengthen that harness before closure.'),
('campaign_open','receipt result','Typed receipt/result/source substitution checks pass; machine task/saga/outbox fuzz targets exist. Full current-production target campaign remains open.'),
('seeded_crash_model_pass_fuzz_scope_distinct','killedchain','Three seeded growing journals undergo48 real kills per compiler, checked against arithmetic/payload/prefix expectations. libFuzzer SQLite target exercises clean reopens; this seeded process-death model is a separate fixture and not a claim of kill-guided fuzz coverage.'),
('named_checks','writers cas ack','Independent workers race the same expected head; conflicting IDs refuse and exact retained retries return matching receipts.'),
('named_checks','ack uncertain','Committed record/pending source survives lost acknowledgement; receiver admission and source acknowledgement remain separately fenced.'),
('named_checks','uncertain result reconcile','Delivery uncertainty remains unresolved until native/independent evidence; effectful result relay and unknown reconciliation checks retain execution authority. This does not establish exactly-once external effects.'),
('named_checks','readers timeline','Concurrent journal snapshot checks bind state/head/receipt; timeline replay/finality checks have independent semantics. Neither implies general concurrent application-state alias safety.'),
('named_checks','poison reconcile taskprepare','Poison/reconciliation tests and inspection-only task preparation retain native admission authority; no generic commit/dispatch method is provided by PreparedDecision.'),
('external_gates','taskprepare timeline','The compatibility checkpoint records exactly33278 task/timeline and3136 saga observations plus source bindings. Review remains bounded to those corpora.'),
('approved_msrv_amendment','nonclone','Original clause says Rust1.85. User-approved architecture amendment raises supported MSRV to1.89 for patched SQLite. External consumers pass on1.89/1.100; no1.85 candidate compatibility is claimed.'),
('external_gates','cas','Actual old-writer populated database upgrade and old-adapter refusal/backup-only rollback are recorded by the upgrade checkpoint, rather than inferred from new empty databases.'),
('external_gates','signed','Pinned StateChronicle conformance and native checkpoint substitution tests cover signed-source trust boundary; no unpinned sibling checkout is substituted.'),
('external_gates','paths','Archived RISC-V core bare/serde and timeline bare/alloc builds plus allocation probes cover supported fixed-profile consumer types; no physical hardware guarantee.'),
('external_gates','','Metadata, allowlisted layer checks, external consumers and14-profile source API review cover the declared graph/profiles; feature combinations outside those profiles are not inferred.'),
('external_gates','','Portable manifest/layer checks retain core no_std and no mandatory database/runtime/broker imports; hosted facade remains separate.'),
('external_gates','taskprepare','Canonical namespace map and unchanged old consumer retain selected legacy imports. Static export binding review supplements local-item signatures; no all-downstream proof is inferred.')]
assert len(review)==28
section=text.split('### 13.1 Required test layers\n',1)[1].split('\n### 13.2 ',1)[0];clauses=[];group=None
for line in section.splitlines():
 if line.startswith('**'):group=line.strip('*')
 if line.startswith('- '):clauses.append((group,line[2:]))
assert len(clauses)==len(review)
items=[]
for i,((group,requirement),(status,keys,assessment)) in enumerate(zip(clauses,review),1):
 items.append({'id':'13.1.'+str(i),'group':group,'requirement':requirement,'status':status,'assessment':assessment,'named_checks':[refs[k] for k in keys.split()]})
# Verify concrete archived non-test gates rather than counting nearby green CI badges.
checkpoint=json.loads((root/'docs/0.5/evidence/packaging/qpsg-candidate-checkpoint.json').read_text());gates={c['label']:c for c in checkpoint['checks'] if c['group'] in ['candidate','public']};required=['metadata-workspace','metadata-compat','metadata-consumer','layers','parity-1.100.0','parity-1.89.0','upgrade-1.100.0','upgrade-1.89.0','compat-tests-1.100.0','compat-tests-1.89.0','conformance','doctests']
required += ['portable-'+profile+'-'+version for profile in ['penelope-core-None','penelope-core-serde','penelope-timeline-None','penelope-timeline-alloc'] for version in ['1.100.0','1.89.0']]
assert all(gates[g]['exit_code']==0 for g in required)
archive=checkpoint['archive'];archive_path=root/'docs/0.5/evidence/packaging'/archive['file']
assert sha(archive_path.read_bytes())==archive['sha256']
with tarfile.open(archive_path) as tar:
 for name,digest in archive['members_sha256'].items():assert sha(tar.extractfile(name).read())==digest
 assert 'test result: ok. 7 passed; 0 failed; 0 ignored;' in tar.extractfile('candidate/conformance.stdout').read().decode()

paths=['fuzz/fuzz_targets/'+name+'.rs' for name in ['fuzz_machine','fuzz_machine_commit','fuzz_sqlite_machine','fuzz_sqlite_machine_outbox','fuzz_sqlite_machine_task','fuzz_sqlite_machine_saga']]+['crates/penelope-core/src/machine/memory.rs','crates/penelope-core/src/machine/identities.rs','docs/0.5/architecture.md','docs/0.5/compatibility-matrix.md']
source_hashes={p:sha((root/p).read_bytes()) for p in paths}
for p in paths:assert subprocess.check_output(['git','show','HEAD:'+p],cwd=root)==(root/p).read_bytes()
result={'scope':'Every one of28 required-test clauses in plan13.1, mapped to29 named tests with observed passes on stable/MSRV plus20 archived external gates. This audits fixture evidence, not full release completion or every normative requirement elsewhere in the plan.','review_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'plan_sha256':sha(plan.read_bytes()),'counts':{'clauses':len(items),'named_tests':len(records),'external_gates':len(required),'statuses':dict(collections.Counter(i['status'] for i in items))},'items':items,'named_tests':records,'external_gates':{'checkpoint':'../packaging/qpsg-candidate-checkpoint.json','checks':[gates[g] for g in required]},'verified_production_checkpoint_archive':{'sha256':archive['sha256'],'members':len(archive['members_sha256']),'pinned_conformance_passes':7},'reviewed_sources_sha256':source_hashes,'open':['Full current-production multi-target fuzz/chaos campaign remains live; shorter CI and supplementary single-target fuzz are not replacements.','Targeted replay mutation coverage for all scope/definition/digest/order roles remains only partially supported. Receipt mutation is not automatically replay mutation.','Process-kill oracle is a seeded test supplement; clean-reopen libFuzzer target does not itself kill child processes. Preserve that distinction in release claims.','Final source/harness/package/coverage reconciliation, performance findings and detailed normative review outside13.1 remain open.']}
p=root/'docs/0.5/evidence/maintenance/test-layer-audit.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts'],indent=2))
