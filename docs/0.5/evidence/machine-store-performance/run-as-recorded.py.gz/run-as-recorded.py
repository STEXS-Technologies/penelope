import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/ac/projects/penelope');out=Path('/tmp/penelope-machine-store-qualification');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{4,5,6,7})
env={**os.environ,'RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'target/sqlite-performance-after'),'PENELOPE_BENCH_DIR':str(root/'target/perf-data')}
files=['Cargo.lock','crates/penelope-sqlite/Cargo.toml','crates/penelope-sqlite/benches/machine_store.rs','crates/penelope-sqlite/tests/support/machines.rs','scripts/benchmark-durable-store.py']
metadata={'parent_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},'tracked_diff':subprocess.check_output(['git','diff','HEAD'],text=True),'benchmark_source':(root/files[2]).read_text(),'checks':[]}
def run(name,args):
 print('Starting '+name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 metadata['checks'].append({'name':name,'command':args,'exit_code':0,'elapsed_seconds':time.monotonic()-start});(out/'qualification.json').write_text(json.dumps(metadata,indent=2)+'\n');print('Completed '+name,flush=True)
for compiler,runs in [('1.100.0',3),('1.89.0',1)]:
 run('measure-'+compiler,['python3',str(root/'scripts/benchmark-durable-store.py'),str(out/('measure-'+compiler)),'--benchmark','machine_store','--data-parent',str(root/'target/perf-data'),'--cpu','4','--parallel-cpus','4,5,6,7','--runs',str(runs),'--toolchain',compiler])
run('legacy-runner-default',['python3',str(root/'scripts/benchmark-durable-store.py'),str(out/'legacy-default'),'--data-parent',str(root/'target/perf-data'),'--cpu','4','--runs','1','--toolchain','1.100.0'])
for compiler in ['1.100.0','1.89.0']:
 for name,args in [('sqlite',['-p','penelope-sqlite','--test','machines','--test','machine_outbox']),('native',['-p','penelope-executor','--test','machine_task','--test','machine_saga']),('debug-entry',['-p','penelope-sqlite','--bench','machine_store'])]:
  run(name+'-'+compiler,['cargo','+'+compiler,'test','--locked',*args])
